<?php 

	//----------------- PieChart ----------------

	$options_panel = '';
	$options_panel[] = array('type' => 'div_start');	
	//----------------- General settings ----------------
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	$options_panel[] = array('title'=> 'Title settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Show title', 
							 'name' => 'show_title',
							 'type' => 'checkbox');
							 
	$options_panel[] = array('title'=> 'Title Position',
							 'name' => 'titlePosition',
							 'type' => 'dropdown', 
							 'list' =>  array('out'=>'Out','in'=>'In', 'none'=>'None'),
							 'help' => __('Where to place the chart titles, compared to the chart area. Supported values:<br><br><b>in<b/> - Draw the axis titles inside the the chart area.<br><b>out</b> - Draw the axis titles outside the chart area.<br><b>none</b> - Omit the axis titles.','evt'));
							 
	$options_panel[] = array('title'=> 'Title Size',
							 'name' => 'titleTextStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the title text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Title Font',
							 'name' => 'titleTextStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the title text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Title Color',
							 'name' => 'titleTextStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the title text style color. For example: red or #00cc00','evt'));
	
	
	$options_panel[] = array('title'=> 'General settings',
								'type' => 'title');
	
	$options_panel[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));
														
	$options_panel[] = array('title'=> 'Font Size',
								'name' => 'fontSize',
								'type' => 'number',
								'help' => __('The default font size, in pixels, of all text in the chart. You can override this using properties for specific chart elements.','evt'));	
								
	$options_panel[] = array('title'=> 'Font Name',
								'name' => 'fontName',
								'type' => 'string',
								'help' => __('The default font face for all text in the chart. You can override this using properties for specific chart elements.','dgs'));
								
								
	$options_panel[] = array('title'=> 'Show 3D',
								'name' => 'is3D',
								'type' => 'boolean',
								'help' => __('If set to true, displays a three-dimensional chart.','evt'));
								
	$options_panel[] = array('title'=> 'Reverse Categories',
								'name' => 'reverseCategories',
								'type' => 'boolean',
								'help'=> __('If set to true, will draw slices counterclockwise. The default is to draw clockwise.','evt'));
								
	$options_panel[] = array('title'=> 'Pie Slice settings',
								'type' => 'title');			
								
	$options_panel[] = array('title'=> 'Pie Slice Colors',
							 'name' => 'colors',
							 'type' => 'colors',
							 'help' => __('The colors to use for the chart elements. An array of strings, where each element is an HTML color string, for example:<br><br><b>[red,#004411]</b>','evt'));
																
	$options_panel[] = array('title'=> 'Pie Slice Text',
								'name' => 'pieSliceText',
								'type' => 'dropdown',
								'list' =>  array('percentage'=>'Percentage','value'=>'Value','label'=>'Label','none'=>'None'),
								'help' => __('The content of the text displayed on the slice. Can be one of the following:<br><br><b>percentage</b> - The percentage of the slice size out of the total.<br><b>value</b> - The quantitative value of the slice.<br><b>label</b> - The name of the slice.<br><b>none</b> - No text is displayed.<br>','evt'));		
								
	$options_panel[] = array('title'=> 'Pie Slice Text Size',
							 'name' => 'pieSliceTextStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the title text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Pie Slice Text Font',
							 'name' => 'pieSliceTextStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the title text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Pie Slice Text Color',
							 'name' => 'pieSliceTextStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the title text style color. For example: red or #00cc00','evt'));									
	
	$options_panel[] = array('type' => 'div_break',
								'extra_td'=>array('width'=>'50%'));
								
	//----------------- Charts settings ----------------
	$options_panel[] = array('title'=> 'Charts settings',
								'type' => 'title');
								
	$options_panel[] = array('title'=> 'Chart Area Left',
								'name' => 'chartArea__left',
								'type' => 'number',
								'help' => __('How far to draw the chart from the left border.','evt'));
								
	$options_panel[] = array('title'=> 'Chart Area Top',
								'name' => 'chartArea__top',
								'type' => 'number',
								'help'=> __('How far to draw the chart from the top border.','evt'));
								
	$options_panel[] = array('title'=> 'Chart Area Width',
								'name' => 'chartArea__width',
								'type' => 'number',
								'help' => __('Chart area width.','evt'));
								
	$options_panel[] = array('title'=> 'Chart Area Height',
								'name' => 'chartArea__height',
								'type' => 'number',
								'help'=> __('Chart area height.','evt'));
								
	//----------------- Background settings ----------------
	$options_panel[] = array('title'=> 'Background settings',
								'type' => 'title');	
								
	$options_panel[] = array('title'=> 'Transparent Background', 
							 'name' => 'backgroundColor__fill',
							 'value' => 'transparent',
							 'type' => 'checkbox');
								
	$options_panel[] = array('title'=> 'Background Color',
								'name' => 'backgroundColor',
								'type' => 'color',
								'help' => __('The background color for the main area of the chart. Can be either a simple HTML color string, for example: red or #00cc00, or an object with the following properties.','evt'));
								
	$options_panel[] = array('title'=> 'Background Color Stroke' ,
								'name' => 'backgroundColor__stroke',
								'type' => 'color',
								'help' => __('The color of the chart border, as an HTML color string.','evt'));
								
	$options_panel[] = array('title'=> 'Background Color Stroke Width',
								'name' => 'backgroundColor__strokeWidth',
								'type' => 'number',
								'help' => __('The border width, in pixels.','evt'));

	$options_panel[] = array('title'=> 'Legend settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Legend Position',
							 'name' => 'legend__position',
							 'type' => 'dropdown', 
							 'list' =>  array('right'=>'Right','right'=>'Right','left'=>'Left','top'=>'Top','bottom'=>'Bottom','none'=>'None'),
							 'help' => __('Position of the legend. Can be one of the following:<br><br><b>right</b> - To the right of the chart.<br><b>left</b> - To the left of the chart.<br><b>top</b> - Above the chart.<br><b>bottom</b> - Below the chart.<br><b>none</b> - No legend is displayed.<br>','evt'));
							 
	$options_panel[] = array('title'=> 'Legend Text Size',
							 'name' => 'legend__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the legend text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Legend Text Font',
							 'name' => 'legend__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the legend text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Legend Text Color',
							 'name' => 'legend__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the legend text style color. For example: red or #00cc00','evt'));
	
	$options_panel[] = array('title'=> 'Tooltip settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Tooltip Show Color Code',
							 'name' => 'tooltip__showColorCode',
							 'type' => 'boolean',
							 'help' => __('If true, show colored squares next to the series information in the tooltip. The default is true when focusTarget is set to category, otherwise the default is false.','evt'));	
							 
	$options_panel[] = array('title'=> 'Tooltip Text Size',
							 'name' => 'tooltip__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the tooltip text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Tooltip Text Font',
							 'name' => 'tooltip__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the tooltip text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Tooltip Text Color',
							 'name' => 'tooltip__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the tooltip text style color. For example: red or #00cc00','evt'));	
							 
	$options_panel[] = array('title'=> 'Tooltip Trigger',
							 'name' => 'tooltip__trigger',
							 'type' => 'dropdown', 
							 'list' =>  array('hover'=>'Hover','none'=>'None'),
							 'help' => __('The user interaction that causes the tooltip to be displayed:<br><br><b>hover</b> - The tooltip will be displayed when the user hovers over an element.<br><b>none</b> - The tooltip will not be displayed.','evt'));
								
	$options_panel[] = array('type' => 'div_end');

    $tmp_col = '';
	$tmp_col = array(array('string','Task'),
				array('number','Hours per Day'),
				array('string','URL'));
	
	$tmp_row = '';
	$tmp_row =   array(array('Work',71,'https://www.google.dk/'),
				  array('Eat',32,'https://www.google.dk/imghp?hl=da&tab=wi'),
				  array('Commute',12,'http://maps.google.dk/maps?hl=da&tab=wl'),
				  array('Watch TV',62,'https://www.google.com/calendar/render?tab=wc'),
				  array('Sleep',57,'http://translate.google.dk/?hl=da&tab=wT'),
				  array('Life',100,'https://accounts.google.com/ServiceLogin?service=blogger'));

	global $easy_visualization_tools_display;
	$easy_visualization_tools_display['PieChart'] = array('type'=>'PieChart',
										 'title'=>'Pie Chart',
										 'packages' => 'corechart',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
?>