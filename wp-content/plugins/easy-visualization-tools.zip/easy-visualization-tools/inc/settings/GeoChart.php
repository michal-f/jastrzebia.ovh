<?php
 	global $easy_visualization_tools_display;
 	
	// ------------------- GeoChart -------------------

	$_countries = array(
  	"---" => "----- Region-----",
	'' => 'World',
'005' => 'South America',
'013' => 'Central America',
'021' => 'North America',
'002' => 'All of Africa',
'017' => 'Central Africa',
'015' => 'Northern Africa',
'018' => 'Southern Africa',
'030' => 'Eastern Asia',
'034' => 'Southern Asia',
'035' => 'Asia/Pacific region',
'143' => 'Central Asia',
'145' => 'Middle East',
'150' => 'Europe',
'151' => 'Northern Asia',
'154' => 'Northern Europe',
'155' => 'Western Europe',
'039' => 'Southern Europe',
  "----" => "----- Countries-----",	
  "GB" => "United Kingdom",
  "US" => "United States",
  "AF" => "Afghanistan",
  "AL" => "Albania",
  "DZ" => "Algeria",
  "AS" => "American Samoa",
  "AD" => "Andorra",
  "AO" => "Angola",
  "AI" => "Anguilla",
  "AQ" => "Antarctica",
  "AG" => "Antigua And Barbuda",
  "AR" => "Argentina",
  "AM" => "Armenia",
  "AW" => "Aruba",
  "AU" => "Australia",
  "AT" => "Austria",
  "AZ" => "Azerbaijan",
  "BS" => "Bahamas",
  "BH" => "Bahrain",
  "BD" => "Bangladesh",
  "BB" => "Barbados",
  "BY" => "Belarus",
  "BE" => "Belgium",
  "BZ" => "Belize",
  "BJ" => "Benin",
  "BM" => "Bermuda",
  "BT" => "Bhutan",
  "BO" => "Bolivia",
  "BA" => "Bosnia And Herzegowina",
  "BW" => "Botswana",
  "BV" => "Bouvet Island",
  "BR" => "Brazil",
  "IO" => "British Indian Ocean Territory",
  "BN" => "Brunei Darussalam",
  "BG" => "Bulgaria",
  "BF" => "Burkina Faso",
  "BI" => "Burundi",
  "KH" => "Cambodia",
  "CM" => "Cameroon",
  "CA" => "Canada",
  "CV" => "Cape Verde",
  "KY" => "Cayman Islands",
  "CF" => "Central African Republic",
  "TD" => "Chad",
  "CL" => "Chile",
  "CN" => "China",
  "CX" => "Christmas Island",
  "CC" => "Cocos (Keeling) Islands",
  "CO" => "Colombia",
  "KM" => "Comoros",
  "CG" => "Congo",
  "CD" => "Congo, The Democratic Republic Of The",
  "CK" => "Cook Islands",
  "CR" => "Costa Rica",
  "CI" => "Cote D'Ivoire",
  "HR" => "Croatia (Local Name: Hrvatska)",
  "CU" => "Cuba",
  "CY" => "Cyprus",
  "CZ" => "Czech Republic",
  "DK" => "Denmark",
  "DJ" => "Djibouti",
  "DM" => "Dominica",
  "DO" => "Dominican Republic",
  "TP" => "East Timor",
  "EC" => "Ecuador",
  "EG" => "Egypt",
  "SV" => "El Salvador",
  "GQ" => "Equatorial Guinea",
  "ER" => "Eritrea",
  "EE" => "Estonia",
  "ET" => "Ethiopia",
  "FK" => "Falkland Islands (Malvinas)",
  "FO" => "Faroe Islands",
  "FJ" => "Fiji",
  "FI" => "Finland",
  "FR" => "France",
  "FX" => "France, Metropolitan",
  "GF" => "French Guiana",
  "PF" => "French Polynesia",
  "TF" => "French Southern Territories",
  "GA" => "Gabon",
  "GM" => "Gambia",
  "GE" => "Georgia",
  "DE" => "Germany",
  "GH" => "Ghana",
  "GI" => "Gibraltar",
  "GR" => "Greece",
  "GL" => "Greenland",
  "GD" => "Grenada",
  "GP" => "Guadeloupe",
  "GU" => "Guam",
  "GT" => "Guatemala",
  "GN" => "Guinea",
  "GW" => "Guinea-Bissau",
  "GY" => "Guyana",
  "HT" => "Haiti",
  "HM" => "Heard And Mc Donald Islands",
  "VA" => "Holy See (Vatican City State)",
  "HN" => "Honduras",
  "HK" => "Hong Kong",
  "HU" => "Hungary",
  "IS" => "Iceland",
  "IN" => "India",
  "ID" => "Indonesia",
  "IR" => "Iran (Islamic Republic Of)",
  "IQ" => "Iraq",
  "IE" => "Ireland",
  "IL" => "Israel",
  "IT" => "Italy",
  "JM" => "Jamaica",
  "JP" => "Japan",
  "JO" => "Jordan",
  "KZ" => "Kazakhstan",
  "KE" => "Kenya",
  "KI" => "Kiribati",
  "KP" => "Korea, Democratic People's Republic Of",
  "KR" => "Korea, Republic Of",
  "KW" => "Kuwait",
  "KG" => "Kyrgyzstan",
  "LA" => "Lao People's Democratic Republic",
  "LV" => "Latvia",
  "LB" => "Lebanon",
  "LS" => "Lesotho",
  "LR" => "Liberia",
  "LY" => "Libyan Arab Jamahiriya",
  "LI" => "Liechtenstein",
  "LT" => "Lithuania",
  "LU" => "Luxembourg",
  "MO" => "Macau",
  "MK" => "Macedonia, Former Yugoslav Republic Of",
  "MG" => "Madagascar",
  "MW" => "Malawi",
  "MY" => "Malaysia",
  "MV" => "Maldives",
  "ML" => "Mali",
  "MT" => "Malta",
  "MH" => "Marshall Islands",
  "MQ" => "Martinique",
  "MR" => "Mauritania",
  "MU" => "Mauritius",
  "YT" => "Mayotte",
  "MX" => "Mexico",
  "FM" => "Micronesia, Federated States Of",
  "MD" => "Moldova, Republic Of",
  "MC" => "Monaco",
  "MN" => "Mongolia",
  "MS" => "Montserrat",
  "MA" => "Morocco",
  "MZ" => "Mozambique",
  "MM" => "Myanmar",
  "NA" => "Namibia",
  "NR" => "Nauru",
  "NP" => "Nepal",
  "NL" => "Netherlands",
  "AN" => "Netherlands Antilles",
  "NC" => "New Caledonia",
  "NZ" => "New Zealand",
  "NI" => "Nicaragua",
  "NE" => "Niger",
  "NG" => "Nigeria",
  "NU" => "Niue",
  "NF" => "Norfolk Island",
  "MP" => "Northern Mariana Islands",
  "NO" => "Norway",
  "OM" => "Oman",
  "PK" => "Pakistan",
  "PW" => "Palau",
  "PA" => "Panama",
  "PG" => "Papua New Guinea",
  "PY" => "Paraguay",
  "PE" => "Peru",
  "PH" => "Philippines",
  "PN" => "Pitcairn",
  "PL" => "Poland",
  "PT" => "Portugal",
  "PR" => "Puerto Rico",
  "QA" => "Qatar",
  "RE" => "Reunion",
  "RO" => "Romania",
  "RU" => "Russian Federation",
  "RW" => "Rwanda",
  "KN" => "Saint Kitts And Nevis",
  "LC" => "Saint Lucia",
  "VC" => "Saint Vincent And The Grenadines",
  "WS" => "Samoa",
  "SM" => "San Marino",
  "ST" => "Sao Tome And Principe",
  "SA" => "Saudi Arabia",
  "SN" => "Senegal",
  "SC" => "Seychelles",
  "SL" => "Sierra Leone",
  "SG" => "Singapore",
  "SK" => "Slovakia (Slovak Republic)",
  "SI" => "Slovenia",
  "SB" => "Solomon Islands",
  "SO" => "Somalia",
  "ZA" => "South Africa",
  "GS" => "South Georgia, South Sandwich Islands",
  "ES" => "Spain",
  "LK" => "Sri Lanka",
  "SH" => "St. Helena",
  "PM" => "St. Pierre And Miquelon",
  "SD" => "Sudan",
  "SR" => "Suriname",
  "SJ" => "Svalbard And Jan Mayen Islands",
  "SZ" => "Swaziland",
  "SE" => "Sweden",
  "CH" => "Switzerland",
  "SY" => "Syrian Arab Republic",
  "TW" => "Taiwan",
  "TJ" => "Tajikistan",
  "TZ" => "Tanzania, United Republic Of",
  "TH" => "Thailand",
  "TG" => "Togo",
  "TK" => "Tokelau",
  "TO" => "Tonga",
  "TT" => "Trinidad And Tobago",
  "TN" => "Tunisia",
  "TR" => "Turkey",
  "TM" => "Turkmenistan",
  "TC" => "Turks And Caicos Islands",
  "TV" => "Tuvalu",
  "UG" => "Uganda",
  "UA" => "Ukraine",
  "AE" => "United Arab Emirates",
  "UM" => "United States Minor Outlying Islands",
  "UY" => "Uruguay",
  "UZ" => "Uzbekistan",
  "VU" => "Vanuatu",
  "VE" => "Venezuela",
  "VN" => "Viet Nam",
  "VG" => "Virgin Islands (British)",
  "VI" => "Virgin Islands (U.S.)",
  "WF" => "Wallis And Futuna Islands",
  "EH" => "Western Sahara",
  "YE" => "Yemen",
  "YU" => "Yugoslavia",
  "ZM" => "Zambia",
  "ZW" => "Zimbabwe"
);			

	$options_panel = '';
	$options_panel[] = array('type' => 'div_start');	
	// ------------------- General settings -------------------
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	
	$options_panel[] = array('title'=> 'General settings',
							 'type' => 'title');
	
	$options_piechart[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));
	
    $options_panel[] = array('title'=> 'Dataless Region Color',
						 	 'name' => 'datalessRegionColor',
						 	 'type' =>'color',
						 	 'help' => __('Colors to assign to regions with no associated data.','evt'));
						 
	
	$options_panel[] = array('title'=> 'displayMode',
							 'name' => 'displayMode',
							 'type' => 'dropdown',
							 'list' =>  array('auto'=>'Auto','regions'=>'Regions','markers'=>'Markers'),
							 'help' => __('Which type of map this is. The DataTable format must match the value specified. The following values are supported:<br><br><b>auto</b> - Choose based on the format of the DataTable.<br><b>regions</b> - This is a region map<br><b>markers</b> - This is a marker map.','evt'));	
	
	$options_panel[] = array('title'=> 'Region',
							 'name' => 'region',
							 'type' => 'dropdown',
							 'list' =>  $_countries,
							 'help' => __('The area to display on the map.Surrounding areas will be displayed as well.','evt'));

	// ------------------- Legend settings -------------------
	$options_panel[] = array('title'=> 'Legend',
							 'type' => 'title');	
							 
	$options_panel[] = array('title'=> 'Legend NumberFormat', 
							 'name' => 'legend__numberFormat',
							 'type' => 'string',
							 'help' => __('A format string for numeric axis labels. This is a subset of the ICU pattern set. For instance,<br><br><b>.##</b><br> will display values 10.66, 10.6, and 10.0 for values 10.666, 10.6, and 10.','evt'));
							 
	$options_panel[] = array('title'=> 'Legend Text Size',
							 'name' => 'legend__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the legend text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Legend Text Font',
							 'name' => 'legend__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the legend text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Legend Text Color',
							 'name' => 'legend__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the legend text style color. For example: red or #00cc00','evt'));
	
	// ------------------- Background settings -------------------
	$options_panel[] = array('title'=> 'Background settings',
							 'type' => 'title');	
							 
	$options_panel[] = array('title'=> 'Transparent Background', 
							 'name' => 'backgroundColor__fill',
							 'value' => 'transparent',
							 'type' => 'checkbox');
							 
	$options_panel[] = array('title'=> 'Background Color', 
							 'name' => 'backgroundColor',
							 'type' =>'color',
							 'help' => __('The background color for the main area of the chart. Can be either a simple HTML color string, for example: red or #00cc00, or an object with the following properties.','evt'));
							 
	$options_panel[] = array('title'=> 'Background Color Stroke' ,
							 'name' => 'backgroundColor__stroke',
							 'type' => 'color',
							 'help' => __('The color of the chart border, as an HTML color string.','evt'));
							 
	$options_panel[] = array('title'=> 'Background Color Stroke Width' ,
							 'name' => 'backgroundColor__strokeWidth',
							 'type' => 'number',
							 'help' => __('The border width, in pixels.','evt'));	



	$options_panel[] = array('type' => 'div_break',
							 'extra_td'=>array('width'=>'50%'));
							 
	// ------------------- Color Axis settings -------------------
	$options_panel[] = array('title'=> 'Color Axis',
							 'type' => 'title');
							 	
	$options_panel[] = array('title'=> 'Color Axis Min Value', 
						 	 'name' => 'colorAxis__minValue',
						 	 'type' => 'number',
						 	 'help' => __('If present, specifies a minimum value for chart color data. Color data values of this value and lower will be rendered as the first color in the colorAxis.colors range.','evt'));
						 	
	$options_panel[] = array('title'=> 'Color Axis Max Value', 
							 'name' => 'colorAxis__maxValue',
							 'type' => 'number',
							 'help' => __('If present, specifies a maximum value for chart color data. Color data values of this value and higher will be rendered as the last color in the colorAxis.colors range.','evt'));
							 
	$options_panel[] = array('title'=> 'Color Axis Colors',
							 'name' => 'colorAxis__colors',
							 'type' => 'colors',
							 'help' => __('Colors to assign to values in the visualization. An array of strings, where each element is an HTML color string, for example:<br><br><b>[red,#004411]</b>','evt'));	
							 		
	// ------------------- Size Axis settings -------------------				
	$options_panel[] = array('title'=> 'Size Axis',
							 'type' => 'title');	
							 						
	$options_panel[] = array('title'=> 'Size Axis Min Size', 
							 'name' => 'sizeAxis__minSize',
							 'type' => 'number',
							 'help' => __('Mininum size of the smallest marker, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Size Axis Max Size', 
							 'name' => 'sizeAxis__maxSize',
							 'type' => 'number',
							 'help' => __('Maximum size of the largest marker, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Size Axis Min Value', 
							 'name' => 'sizeAxis__minValue',
							 'type' => 'number',
							 'help' => __('Minimum size column value. Smaller values will be clamped to this value.','evt'));
							 
	$options_panel[] = array('title'=> 'Size Axis Max Value', 
							 'name' => 'sizeAxis__maxValue',
							 'type' => 'number',
							 'help' => __('Maximum size column value. Larger values will be cropped to this value.','evt'));				
	
	// ------------------- Tooltip settings -------------------
	$options_panel[] = array('title'=> 'Tooltip settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Tooltip Text Size',
							 'name' => 'tooltip__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the tooltip text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Tooltip Text Font',
							 'name' => 'tooltip__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the tooltip text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Tooltip Text Color',
							 'name' => 'tooltip__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the tooltip text style color. For example: red or #00cc00','evt'));
							 
	$options_panel[] = array('type' => 'div_end'); 									 

	$tmp_col = '';	
	$tmp_col = array(array('string','Country'),
				array('number','Popularity'));
	$tmp_row = '';
    $tmp_row = array(array('Germany', 200),
				array('United States', 300),
				array('Brazil', 400),
				array('Canada', 500),
				array('France', 600),
				array('RU', 700));

	$easy_visualization_tools_display['GeoChart'] = array('type'=>'GeoChart',
										 'title'=>'Geo Chart',
										 'packages' => 'geochart',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );



?>