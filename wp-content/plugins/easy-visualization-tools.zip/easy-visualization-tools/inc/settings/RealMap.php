<?php 
 	global $easy_visualization_tools_display;
	//----------------- Map ----------------

	$options_panel = '';
	// ------------------- General settings -------------------
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	$options_panel[] = array('title'=> 'General settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));
							 
	$options_panel[] = array('title'=> 'Enable Scroll Wheel',
							 'name' => 'enableScrollWheel',
							 'type' => 'boolean',
							 'help' => __('If set to true, enables zooming in and out using the mouse scroll wheel.','evt'));
							 
	$options_panel[] = array('title'=> 'Show Tip',
							 'name' => 'showTip',
							 'type' => 'boolean',
							 'help' => __('If set to true, shows the location description as a tooltip when the mouse is positioned above a point marker.','evt'));
	$options_panel[] = array('title'=> 'Show Line',
							 'name' => 'showLine',
							 'type' => 'boolean',
							 'help' => __('If set to true, shows a Google Maps polyline through all the points.','evt'));
							 		 
	$options_panel[] = array('title'=> 'Line Color', 
							 'name' => 'lineColor',
							 'type' => 'color',
							 'help' => __('If showLine is true, defines the line color. For example: #800000.','evt'));
							 
	$options_panel[] = array('title'=> 'Line Width', 
							 'name' => 'lineWidth',
							 'type' => 'number',
							 'help' => __('If showLine is true, defines the line width (in pixels).','evt'));
							 
	$options_panel[] = array('title'=> 'Map Type',
							 'name' => 'mapType',
							 'type' => 'dropdown', 
							 'list' =>  array('normal'=>'Normal','terrain'=>'Terrain', 'satellite'=>'Satellite', 'hybrid'=>'Hybrid'),
							 'help' => __('The type of map to show. Possible values are normal, terrain, satellite or hybrid.','evt'));
							 
	$options_panel[] = array('title'=> 'Use Map Type Control',
							 'name' => 'useMapTypeControl',
							 'type' => 'boolean',
							 'help' => __('Show a map type selector that enables the viewer to switch between [map, satellite, hybrid, terrain]. When useMapTypeControl is false (default) no selector is presented and the type is determined by the mapType option.','evt'));
							 
	$options_panel[] = array('title'=> 'Zoom Level', 
							 'name' => 'zoomLevel',
							 'type' => 'number',
							 'help' => __('An integer indicating the initial zoom level of the map, where 0 is completely zoomed out (whole world) and 19 is the maximum zoom level. (See "Zoom Levels" in the Google Maps API.)','evt'));
			 
			 
    $tmp_col = '';
	$tmp_col = array(array('number', 'Lat'),
          		array('number', 'Lon'),
          		array('string', 'Name'),
          		array('string', 'URL'));

	
	$tmp_row = '';
	$tmp_row = array(array(37.4232,-122.0853,'Work','https://www.google.dk/'),
      			array(37.4289,-122.1697,'University','https://www.google.dk/imghp?hl=da&tab=wi'),
      			array(37.6153,-122.3900,'Airport','http://maps.google.dk/maps?hl=da&tab=wl'),
      			array(37.4422,-122.1731,'Shopping','https://www.google.com/calendar/render?tab=wc')); 

	$easy_visualization_tools_display['Map'] = array('type'=>'Map',
										 'title'=>'Real Map',
										 'packages' => 'map',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
?>