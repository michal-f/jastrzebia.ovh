<?php 
 	global $easy_visualization_tools_display;
	$options_panel = '';
	
	// -------------------- Table  -----------------
	
	$options_panel = '';
	$options_panel[] = array('type' => 'div_start');
	
	// -------------------- General settings  -----------------	
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	$options_panel[] = array('title'=> 'General settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));

	$options_panel[] = array('title'=> 'Allow Html',
							 'name' => 'allowHtml',
							 'type' => 'boolean',
							 'help' => __('If set to true, formatted values of cells that include HTML tags will be rendered as HTML. If set to false, most custom formatters will not work properly.','evt'));
	
	$options_panel[] = array('title'=> 'Alternating Row Style',
							 'name' => 'alternatingRowStyle',
							 'type' => 'boolean',
							 'help' => __('Determines if alternating color style will be assigned to odd and even rows.','evt'));
	
	
	$options_panel[] = array('title'=> 'CSS Class Names',
							 'name' => 'cssClassNames',
							 'type' => 'textarea',
							 'help' => __('An object in which each property name describes a table element, and the property value is a string, defining a class to assign to that table element. Use this property to assign custom CSS to specific elements of your table. To use this property, assign an object, where the property name specifies the table element, and the property value is a string, specifying a class name to assign to that element. You must then define a CSS style for that class on your page. The following property names are supported:<br><br><b>headerRow<b> - Assigns a class name to the table header row.<br><b>tableRow</b> - Assigns a class name to the non-header rows (<tr> elements).<br><b>oddTableRow</b> - Assigns a class name to odd table rows (<tr> elements). Note: the alternatingRowStyle option must be set to true.<br><b>selectedTableRow</b> - Assigns a class name to the selected table row.<br><b>hoverTableRow</b> - Assigns a class name to the hovered table row.<br><b>headerCell</b> - Assigns a class name to all cells in the header row.<br><b>tableCell</b> - Assigns a class name to all non-header table cells.<br><b>rowNumberCell</b> - Assigns a class name to the cells in the row number column (<td> element). Note: the showRowNumber option must be set to true.<br><br><b>{headerRow: bigAndBoldClass, hoverTableRow: highlightClass}</b>','evt'));
	
	$options_panel[] = array('title'=> 'First Row Number', 
							 'name' => 'firstRowNumber',
							 'type' => 'number',
							 'help' => __('The row number for the first row in the dataTable. Used only if showRowNumber is true. ','evt'));
	
	$options_panel[] = array('title'=> 'Show Row Number',
							 'name' => 'showRowNumber',
							 'type' => 'boolean',
							 'help' => __('If set to true, shows the row number as the first column of the table.','evt'));	
	
	$options_panel[] = array('title'=> 'RTL Table',
							 'name' => 'rtlTable',
							 'type' => 'boolean',
							 'help' => __('Adds basic support for right-to-left languages (such as Arabic or Hebrew) by reversing the column order of the table, so that column zero is the rightmost column, and the last column is the leftmost column. This does not affect the column index in the underlying data, only the order of display. Full bi-directional BiDi language display is not supported by the table visualization even with this option. This option will be ignored if you enable paging (using the page option), or if the table has scroll bars because you have specified height and width options smaller than the required table size.','evt'));	
	
	$options_panel[] = array('title'=> 'Scroll Left Start Position', 
							 'name' => 'scrollLeftStartPosition',
							 'type' => 'number',
							 'help' => __('Sets the horizontal scrolling position, in pixels, if the table has horizontal scroll bars because you have set the width property. The table will open scrolled that many pixels past the leftmost column. T','evt'));
	
	$options_panel[] = array('type' => 'div_break',
							 'extra_td'=>array('width'=>'50%'));
	
	// -------------------- Sort settings  -----------------	
	$options_panel[] = array('title'=> 'Sort',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Sort',
							 'name' => 'sort',
							 'type' => 'dropdown', 
							 'list' => array('enable'=>'Enable','disable'=>'Disable'),
							 'help' => __('If and how to sort columns when the user clicks a column heading. If sorting is enabled, consider setting the sortAscending and sortColumn properties as well. Choose one of the following string values:<br<<br><b>enable</b> - Users can click on column headers to sort by the clicked column. When users click on the column header, the rows will be automatically sorted, and a sort event will be triggered.<br><b>disable</b> - Clicking a column header has no effect.','evt'));
	
	$options_panel[] = array('title'=> 'Sort Ascending',
						 	 'name' => 'sortAscending',
						 	 'type' => 'boolean',
						 	 'help' => __('The order in which the initial sort column is sorted. True for ascending, false for descending. Ignored if sortColumn is not specified. ','evt'));
	
	$options_panel[] = array('title'=> 'Sort Column', 
						 	 'name' => 'sortColumn',
						 	 'type' => 'number',
						 	 'help' => __('An index of a column in the data table, by which the table is initially sorted. The column will be marked with a small arrow indicating the sort order. ','evt'));	
	
	// -------------------- Pages settings  -----------------	
	$options_panel[] = array('title'=> 'Pages',
							 'type' => 'title');	
	
	$options_panel[] = array('title'=> 'Page',
							 'name' => 'page',
							 'type' => 'dropdown', 
							 'list' =>  array('enable'=>'Enable','disable'=>'Disable'),
							 'help' => __('If and how to enable paging through the data. Choose one of the following string values:<br<<br><b>enable</b> - The table will include page-forward and page-back buttons. Clicking on these buttons will perform the paging operation and change the displayed page. You might want to also set the pageSize option.<br><b>disable</b> - [Default] Paging is not supported.','evt'));
	
	$options_panel[] = array('title'=> 'Start page', 
							 'name' => 'startPage',
							 'type' => 'number',
							 'help' => __('The first table page to display. Used only if page is in mode enable/event.','evt'));	
							 
	$options_panel[] = array('title'=> 'Page Size', 
							 'name' => 'pageSize',
							 'type' => 'number',
							 'help' => __('The number of rows in each page, when paging is enabled with the page option.','evt'));
	
	$options_panel[] = array('type' => 'div_end'); 	
	
	
	$tmp_col = '';	
	$tmp_col = array(array('string','Name'),
				array('number','Salary'),
				array('boolean','Full Time Employee'),
				array('string','URL'));
	$tmp_row = '';
    $tmp_row = array(array('Mike', 10000, true,'https://www.google.dk/'),
				array('Jim', 8000 , false,'https://www.google.dk/imghp?hl=da&tab=wi'),
				array('Alice', 12500, true,'http://maps.google.dk/maps?hl=da&tab=wl'),
				array('Bob', 7000 , true,'https://www.google.com/calendar/render?tab=wc'));
	
	$easy_visualization_tools_display['Table'] = array('type'=>'Table',
										 'title'=>'Table',
										 'packages' => 'table',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
										 
										 
?>