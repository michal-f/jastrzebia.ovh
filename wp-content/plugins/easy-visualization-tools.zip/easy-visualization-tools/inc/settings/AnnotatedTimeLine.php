<?php 
 	global $easy_visualization_tools_display;
	$options_panel = '';
	
	//----------------- AnnotatedTimeLine ----------------
	$options_panel[] = array('type' => 'div_start');
//----------------- General settings ----------------

	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');

	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));


	$options_panel[] = array('title'=>'General settings',
							 'type' => 'title');

	$options_piechart[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));

	$options_panel[] = array('title'=> 'Min', 
							 'name' => 'min',
							 'type' => 'number',
							 'help' => __('The minimum value to show on the Y axis. If the minimum data point is less than this value, this setting will be ignored, and the chart will be adjusted to show the next major tick mark below the minimum data point. This will take precedence over the Y axis minimum determined by scaleType.','evt'));
							 
	$options_panel[] = array('title'=> 'Max', 
							 'name' => 'max',
							 'type' => 'number',
							 'help' => __('The maximum value to show on the Y axis. If the maximum data point exceeds this value, this setting will be ignored, and the chart will be adjusted to show the next major tick mark above the maximum data point. This will take precedence over the Y axis maximum determined by scaleType.','evt'));	
							 
	$options_panel[] = array('title'=> 'Allow Html', 
							 'name' => 'allowHtml',
							 'type' => 'boolean',
							 'help' => __('If set to true, any annotation text that includes HTML tags will be rendered as HTML.','evt'));	
	
	$options_panel[] = array('title'=> 'Allow Redraw', 
							 'name' => 'allowRedraw',
							 'type' => 'boolean',
							 'help' => __('Enables a more efficient redrawing technique for the second and later calls to draw() on this visualization. It only redraws the chart area. To use this option, you must fulfill the following requirements:<br><br>allowRedraw must be true<br>displayAnnotations must be false (that is, you cannot show annotations)<br>you must pass in the same options and values (except for the allowRedraw and displayAnnotations) as in your first call to draw().','evt'));	
		
	$options_panel[] = array('title'=> 'All Values Suffix', 
							 'name' => 'allValuesSuffix',
							 'type' => 'string',
							 'help' => __('A suffix to be added to all values in the scales and the legend. ','evt'));	

	$options_panel[] = array('title'=> 'Annotations Width', 
							 'name' => 'annotationsWidth',
							 'type' => 'number',
							 'help' => __('The width (in percent) of the annotations area, out of the entire chart area. Must be a number in the range 5-80. ','evt'));	
							 
	$options_panel[] = array('title'=> 'Colors',
							 'name' => 'colors',
							 'type' => 'colors',
							 'help' => __('The colors to use for the chart elements. An array of strings, where each element is an HTML color string, for example:<br><br><b>[red,#004411]</b>','evt'));

	$options_panel[] = array('title'=> 'Date Format', 
							 'name' => 'dateFormat',
							 'type' => 'string',
							 'help' => __('The format used to display the date information in the top right corner. The format of this field is as specified by the java SimpleDateFormat class.<br><br>Either MMMM dd, yyyy or HH:mm MMMM dd, yyyy, depending on the type of the first column date, or datetime, respectively.','evt'));	
	
	$options_panel[] = array('title'=> 'Fill', 
							 'name' => 'fill',
							 'type' => 'number',
							 'help' => __('A number from 0—100 (inclusive) specifying the alpha of the fill below each line in the line graph. 100 means 100% opaque fill, 0 means no fill at all. The fill color is the same color as the line above it.','evt'));	
	
	$options_panel[] = array('title'=>'Highlight Dot',
							 'name'=>'highlightDot',
							 'type' => 'dropdown', 
							 'list'=>  array('nearest'=>'Nearest','last'=>'Last'),
							 'help'=> __('Which dot on the series to highlight, and corresponding values to show in the legend. Select from one of these values:<br><br><b>nearest</b> - The values closest along the X axis to the mouse.<br><b>last</b> - The next set of values to the left of the mouse.','evt'));
	
	$options_panel[] = array('title'=>'Legend Position',
							 'name'=>'legendPosition',
							 'type' => 'dropdown', 
							 'list'=>  array('sameRow'=>'Same Row','newRow'=>'New Row'),
							 'help'=> __('Whether to put the colored legend on the same row with the zoom buttons and the date (sameRow), or on a new row (newRow).','evt'));
	
	$options_panel[] = array('title'=> 'Scale Columns', 
							 'name' => 'scaleColumns',
							 'type' => 'string',
							 'help' => __('Specifies which values to show on the Y axis tick marks in the graph. The default is to have a single scale on the right side, which applies to both series; but you can have different sides of the graph scaled to different series values.<br><br>This option takes an array of zero to three numbers specifying the (zero-based) index of the series to use as the scale value. Where these values are shown depends on how many values you include in your array:<br><br>If you specify an empty array, the chart will not show Y values next to the tick marks.<br>If you specify one value, the scale of the indicated series will be displayed on the right side of the chart only.<br>If you specify two values, a the scale for the second series will be added to the right of the chart.<br>If you specify three values, a scale for the third series will be added to the middle of the chart.<br>Any values after the third in the array will be ignored.<br><br>When displaying more than one scale, it is advisable to set the scaleType option to either allfixed or allmaximized. ','evt'));	
	
	$options_panel[] = array('title'=>'Scale Type',
							 'name'=>'scaleType',
							 'type' => 'dropdown', 
							 'list'=>  array('fixed'=>'Fixed','maximized'=>'Maximized','allmaximized'=>'All Maximized','allfixed'=>'All Fixed'),
							 'help'=> __('Sets the maximum and minimum values shown on the Y axis. The following options are available:<br><br><b>maximized</b> - The Y axis will span the minimum to the maximum values of the series. If you have more than one series, use allmaximized.<br><b>fixed</b> - The Y axis varies, depending on the data values.<br><b>allmaximized</b> - Same as maximized, but used when multiple scales are displayed. Both charts will be maximized within the same scale, which means that one will be misrepresented against the Y axis, but hovering over each series will display its true value.<br><b>allfixed</b> - Same as fixed, but used when multiple scales are displayed. This setting adjusts each scale to the series to which it applies.<br><br>If you specify the min and/or max options, they will take precedence over the minimum and maximum values determined by your scale type.','evt'));

	$options_panel[] = array('title'=> 'Thickness', 
							 'name' => 'thickness',
							 'type' => 'number',
							 'help' => __('A number from 0—10 (inclusive) specifying the thickness of the lines, where 0 is the thinnest.','evt'));	
							 
							 
	$options_panel[] = array('title'=>'Wmode',
							 'name'=>'wmode',
							 'type' => 'dropdown', 
							 'list'=>  array('window'=>'Window','opaque'=>'Opaque','transparent'=>'Transparent'),
							 'help'=> __('The Window Mode (wmode) parameter for the Flash chart. Available values are: opaque, window or transparent.','evt'));
	
	$options_panel[] = array('type' => 'div_break','extra_td'=>array('width'=>'50%'));
	
	//----------------- Displays ----------------
	$options_panel[] = array('title'=> 'Displays',
							 'type' => 'title');
							 	
	$options_panel[] = array('title'=> 'Display Annotations', 
							 'name' => 'displayAnnotations',
							 'type' => 'boolean',
							 'help' => __('If set to true, the chart will show annotations on top of selected values. When this option is set to true, after every numeric column, two optional annotation string columns can be added, one for the annotation title and one for the annotation text. ','evt'));
							 
	$options_panel[] = array('title'=> 'Display Annotations Filter', 
							 'name' => 'displayAnnotationsFilter',
							 'type' => 'boolean',
							 'help' => __('If set to true, the chart will display a filter contol to filter annotations. Use this option when there are many annotations. ','evt'));
							 
	$options_panel[] = array('title'=> 'Display Date Bar Separator', 
							 'name' => 'displayDateBarSeparator',
							 'type' => 'boolean',
							 'help' => __('Whether to display a small bar separator ( | ) between the series values and the date in the legend, where true means yes.','evt'));
							 
	$options_panel[] = array('title'=> 'Display Exact Values', 
							 'name' => 'displayExactValues',
							 'type' => 'boolean',
							 'help' => __('Whether to display a shortened, rounded version of the values on the top of the graph, to save space; false indicates that it may. For example, if set to false, 56123.45 might be displayed as 56.12k.','evt'));

	$options_panel[] = array('title'=> 'Display Legend Dots', 
							 'name' => 'displayLegendDots',
							 'type' => 'boolean',
							 'help' => __('Whether to display dots next to the values in the legend text, where true means yes.','evt'));
							 
	$options_panel[] = array('title'=> 'Display Legend Values', 
							 'name' => 'displayLegendValues',
							 'type' => 'boolean',
							 'help' => __('Whether to display the highlighted values in the legend, where true means yes.','evt'));

	$options_panel[] = array('title'=> 'Display Range Selector', 
							 'name' => 'displayRangeSelector',
							 'type' => 'boolean',
							 'help' => __('Whether to show the zoom range selection area (the area at the bottom of the chart), where false means no.<br>The outline in the zoom selector is a log scale version of the last series in the chart, scaled to fit the height of the zoom selector.','evt'));
							 
	$options_panel[] = array('title'=> 'Display Zoom Buttons', 
							 'name' => 'displayZoomButtons',
							 'type' => 'boolean',
							 'help' => __('Whether to show the zoom links ("1d 5d 1m" and so on), where false means no.','evt'));
					 	
	$options_panel[] = array('type' => 'div_end'); 
		
	$tmp_col = '';	
	$tmp_col = array(array('date','Date'),
						  array('number','Sold Pencils'),
						  array('string','title1'),
						  array('string','text1'),
						  array('number','Sold Pens'),
						  array('string','title2'),
						  array('string','text2'),
						  array('string','URL'));
	$tmp_row = '';
    $tmp_row = array(array('Fri Feb 01 2008 00:00:00', 30000, 'undefined', 'undefined', 40645, 'undefined', 'undefined','https://www.google.dk/'),
          		array('Sat Feb 02 2008 00:00:00', 14045, 'undefined', 'undefined', 20374,'undefined', 'undefined','https://www.google.dk/imghp?hl=da&tab=wi'),
          		array('Sun Feb 03 2008 00:00:00', 55022, 'undefined', 'undefined', 50766, 'undefined', 'undefined','http://maps.google.dk/maps?hl=da&tab=wl'),
          	    array('Mon Feb 04 2008 00:00:00', 75284, 'undefined', 'undefined', 14334, 'Out of Stock','Ran out of stock','https://www.google.com/calendar/render?tab=wc'),
          		array('Tue Feb 05 2008 00:00:00', 41476, 'Bought Pens','Bought 200k pens', 66467, 'undefined', 'undefined','http://translate.google.dk/?hl=da&tab=wT'),
          		array('Wed Feb 06 2008 00:00:00', 33322, 'undefined', 'undefined', 39463, 'undefined', 'undefined','https://accounts.google.com/ServiceLogin?service=blogger'	));
		
				 





		
	$easy_visualization_tools_display['AnnotatedTimeLine'] = array('type'=>'AnnotatedTimeLine',
										 'title'=>'Annotated Time Line',
										 'packages' => 'annotatedtimeline',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
?>