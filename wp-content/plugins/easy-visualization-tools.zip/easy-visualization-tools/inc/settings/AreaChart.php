<?php 
 	global $easy_visualization_tools_display;
	$options_panel = '';
//--------------------- AreaChart --------------

	$options_panel = '';
	$options_panel[] = array('type' => 'div_start');	
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	$options_panel[] = array('title'=> 'Title settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Show title', 
							 'name' => 'show_title',
							 'type' => 'checkbox');
							 
	$options_panel[] = array('title'=> 'Title Position',
							 'name' => 'titlePosition',
							 'type' => 'dropdown', 
							 'list' =>  array('out'=>'Out','in'=>'In', 'none'=>'None'),
							 'help' => __('Where to place the chart titles, compared to the chart area. Supported values:<br><br><b>in<b/> - Draw the axis titles inside the the chart area.<br><b>out</b> - Draw the axis titles outside the chart area.<br><b>none</b> - Omit the axis titles.','evt'));
							 
	$options_panel[] = array('title'=> 'Title Size',
							 'name' => 'titleTextStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the title text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Title Font',
							 'name' => 'titleTextStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the title text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Title Color',
							 'name' => 'titleTextStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the title text style color. For example: red or #00cc00','evt'));
							 
							 
							 
	$options_panel[] = array('title'=> 'General settings',
							 'type' => 'title');				 					 
							 
	$options_panel[] = array('title'=> 'Reverse Categories',
							 'name' => 'reverseCategories',
							 'type' => 'boolean',
							 'help' => __('If set to true, will draw slices counterclockwise. The default is to draw clockwise.','evt'));
							 
	$options_panel[] = array('title'=> 'Go To URL By Click',
								'name' => 'gotoUrl',
								'type' => 'dropdown', 'list'=> array('1'=>'Off','2'=>'Open in same window','3'=>'Open in new window'),
								'default' => 2,
								'help' => __('If you have a url in your colomn','evt'));
							 
	$options_panel[] = array('title'=> 'Line Width', 
							 'name' => 'lineWidth',
							 'type' => 'number',
							 'help' => __('Line width in pixels. Use zero to hide all lines and show only the points.','evt'));
							 
	$options_panel[] = array('title'=> 'Point Size', 
							 'name' => 'pointSize',
							 'type' => 'number',
							 'help' => __('Diameter of data points, in pixels. Use zero to hide all points.','evt'));
							 
	$options_panel[] = array('title'=> 'Line Colors',
							 'name' => 'colors',
							 'type' => 'colors',
							 'help' => __('The colors to use for the chart elements. An array of strings, where each element is an HTML color string, for example:<br><br><b>[red,#004411]</b>','evt'));
	
							 
	$options_panel[] = array('title'=> 'Font Size',
							 'name' => 'fontSize',
							 'type' => 'number',
							 'help' => __('The default font size, in pixels, of all text in the chart. You can override this using properties for specific chart elements.','evt'));	
							 
	$options_panel[] = array('title'=> 'Font Name',
							 'name' => 'fontName',
							 'type' => 'string', 
							 'help' => __('The default font face for all text in the chart. You can override this using properties for specific chart elements.','dgs'));
							 
	$options_panel[] = array('title'=> 'Series',
							 'name' => 'series',
							 'type' => 'list_data',
							 'content_data' => array('pointSize'=>'Point Size','lineWidth'=>'Line Width','areaOpacity'=>'Area Opacity'),
							 'help' => __('Add pointSize,lineWidth,areaOpacity for each area','evt'));
							 
	$options_panel[] = array('title'=> 'Focus Target',
							 'name' => 'focusTarget',
							 'type' => 'dropdown',
							 'list' =>  array('datum'=>'Datum','category'=>'Category'),
							 'help' => __('The type of the entity that receives focus on mouse hover. Also affects which entity is selected by mouse click, and which data table element is associated with events. Can be one of the following:<br><br><b>datum</b> - Focus on a single data point. Correlates to a cell in the data table.<br><b>category</b> - Focus on a grouping of all data points along the major axis. Correlates to a row in the data table.<br><br>In focusTarget category the tooltip displays all the category values. This may be useful for comparing values of different series.','evt'));
							 	
	$options_panel[] = array('title'=> 'Interpolate Nulls',
							 'name' => 'interpolateNulls',
							 'type' => 'boolean',
							 'help' => __('Whether to guess the value of missing points. If true, it will guess the value of any missing data based on neighboring points. If false, it will leave a break in the line at the unknown point.','evt'));
							 
	$options_panel[] = array('title'=> 'isStacked',
							 'name' => 'isStacked',
							 'type' => 'boolean',
							 'help' => __('If set to true, series elements of the same type are stacked. Affects bar, column and area series only.','evt'));
	
	$options_panel[] = array('title'=> 'Axis Titles Position',
							 'name' => 'axisTitlesPosition',
							 'type' => 'dropdown', 
							 'list' =>  array('out'=>'Out','in'=>'In', 'none'=>'None'),
							 'help' => __('Where to place the axis titles, compared to the chart area. Supported values:<br><br><b>in<b/> - Draw the axis titles inside the the chart area.<br><b>out</b> - Draw the axis titles outside the chart area.<br><b>none</b> - Omit the axis titles.','evt'));
							 
	$options_panel[] = array('title'=> 'Curve type',
							 'name' => 'curveType',
							 'type' => 'dropdown', 
							 'list' =>  array('none'=>'None','function'=>'Function'),
							 'help' => __('Controls the curve of the lines when the line width is not zero. Can be one of the following:<br><br><b>none</b> - Straight lines without curve.<br><b>function</b> - The angles of the line will be smoothed.','evt'));

	$options_panel[] = array('title'=> 'Background settings',
							 'type' => 'title');
							 	
	$options_panel[] = array('title'=> 'Transparent Background', 
							 'name' => 'backgroundColor__fill',
							 'value' => 'transparent',
							 'type' => 'checkbox');

	$options_panel[] = array('title'=> 'Background Color', 
							 'name' => 'backgroundColor',
							 'type' => 'color',
							 'help' => __('The background color for the main area of the chart. Can be either a simple HTML color string, for example: red or #00cc00, or an object with the following properties.','evt'));
							 
	$options_panel[] = array('title'=> 'Background Color Stroke' ,
							 'name' => 'backgroundColor__stroke',
							 'type' => 'color',
							 'help' => __('The color of the chart border, as an HTML color string.','evt'));
							 
	$options_panel[] = array('title'=> 'Background Color Stroke Width' ,
							 'name' => 'backgroundColor__strokeWidth',
							 'type' => 'number',
							 'help' => __('The border width, in pixels.','evt'));	

	$options_panel[] = array('title'=> 'Charts settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Chart Area Left',
							 'name' => 'chartArea__left',
							 'type' => 'number',
							 'help' => __('How far to draw the chart from the left border.','evt'));
							 
	$options_panel[] = array('title'=> 'Chart Area Top',
							 'name' => 'chartArea__top',
							 'type' => 'number',
							 'help' => __('How far to draw the chart from the top border.','evt'));
							 
	$options_panel[] = array('title'=> 'Chart Area Width',
							 'name' => 'chartArea__width',
							 'type' => 'number',
							 'help' => __('Chart area width.','evt'));
							 
	$options_panel[] = array('title'=> 'Chart Area Height',
							 'name' => 'chartArea__height',
							 'type' => 'number',
							 'help' => __('Chart area height.','evt'));
	
	$options_panel[] = array('title'=> 'Legend settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Legend Position',
							 'name' => 'legend__position',
							 'type' => 'dropdown', 
							 'list' =>  array('right'=>'Right','right'=>'Right','left'=>'Left','top'=>'Top','bottom'=>'Bottom','none'=>'None'),
							 'help' => __('Position of the legend. Can be one of the following:<br><br><b>right</b> - To the right of the chart.<br><b>left</b> - To the left of the chart.<br><b>top</b> - Above the chart.<br><b>bottom</b> - Below the chart.<br><b>none</b> - No legend is displayed.<br>','evt'));

	$options_panel[] = array('title'=> 'Legend Text Size',
							 'name' => 'legend__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the legend text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Legend Text Font',
							 'name' => 'legend__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the legend text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Legend Text Color',
							 'name' => 'legend__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the legend text style color. For example: red or #00cc00','evt'));
	
	
	
	$options_panel[] = array('title'=> 'Tooltip settings',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'Tooltip Show Color Code',
							 'name' => 'tooltip__showColorCode',
							 'type' => 'boolean',
							 'help' => __('If true, show colored squares next to the series information in the tooltip. The default is true when focusTarget is set to category, otherwise the default is false.','evt'));	
							 
	$options_panel[] = array('title'=> 'Tooltip Text Size',
							 'name' => 'tooltip__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the tooltip text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'Tooltip Text Font',
							 'name' => 'tooltip__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the tooltip text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'Tooltip Text Color',
							 'name' => 'tooltip__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the tooltip text style color. For example: red or #00cc00','evt'));					 
							 
							 
	$options_panel[] = array('title'=> 'Tooltip Trigger',
							 'name' => 'tooltip__trigger',
							 'type' => 'dropdown', 
							 'list' =>  array('hover'=>'Hover','none'=>'None'),
							 'help' => __('The user interaction that causes the tooltip to be displayed:<br><br><b>hover</b> - The tooltip will be displayed when the user hovers over an element.<br><b>none</b> - The tooltip will not be displayed.','evt'));
			
	$options_panel[] = array('type' => 'div_break',
							 'extra_td'=>array('width'=>'50%'));
	
	$options_panel[] = array('title'=> 'Horizontal axis title',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'hAxis Title', 
							 'name' => 'hAxis__title',
							 'type' => 'string',
							 'help' => __('hAxis property that specifies the title of the horizontal axis.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Title Text Size',
							 'name' => 'hAxis__titleTextStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the hAxis text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'hAxis Title Text Font',
							 'name' => 'hAxis__titleTextStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the hAxis text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'hAxis Title Text Color',
							 'name' => 'hAxis__titleTextStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the hAxis text style color. For example: red or #00cc00','evt'));			 
		
	$options_panel[] = array('title'=> 'Horizontal axis text',
							 'type' => 'title');
		
	$options_panel[] = array('title'=> 'hAxis Text Position',
							 'name' => 'hAxis__textPosition',
							 'type' => 'dropdown', 
							 'list' =>  array('out'=>'Out','in'=>'In','none'=>'None'),
							 'help' => __('Position of the horizontal axis text, relative to the chart area. Supported values: out, in, none.','evt'));	
							 
	$options_panel[] = array('title'=> 'hAxis Text Size',
							 'name' => 'hAxis__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the hAxis Text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'hAxis Text Font',
							 'name' => 'hAxis__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the hAxis Text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'hAxis Text Color',
							 'name' => 'hAxis__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the hAxis Text style color. For example: red or #00cc00','evt'));
		
		
		
$options_panel[] = array('title'=> 'hAxis Slanted Texts',
							 'name' => 'hAxis__slantedText',
							 'type' => 'boolean',
							 'help' => __('If true, draw the horizontal axis text at an angle, to help fit more text along the axis; if false, draw horizontal axis text upright. Default behavior is to slant text if it cannot all fit when drawn upright. Notice that this option is available only when the hAxis.textPosition is set to out (which is the default).<br><br>This option is only supported for a discrete axis.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Slanted Text Angle', 
							 'name' => 'hAxis__slantedTextAngle',
							 'type' => 'number',
							 'help' => __('The angle of the horizontal axis text, if its drawn slanted. Ignored if hAxis.slantedText is false, or is in auto mode, and the chart decided to draw the text horizontally.<br><br>This option is only supported for a discrete axis.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Max Alternation', 
							 'name' => 'hAxis__maxAlternation',
							 'type' => 'number',
							 'help' => __('Maximum number of levels of horizontal axis text. If axis text labels become too crowded, the server might shift neighboring labels up or down in order to fit labels closer together. This value specifies the most number of levels to use; the server can use fewer levels, if labels can fit without overlapping.<br><br>This option is only supported for a discrete axis.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Show Text Every', 
							 'name' => 'hAxis__showTextEvery',
							 'type' => 'number',
							 'help' => __('How many horizontal axis labels to show, where 1 means show every label, 2 means show every other label, and so on. Default is to try to show as many labels as possible without overlapping.<br><br>This option is only supported for a discrete axis.','evt'));	
	
	
							 
	$options_panel[] = array('title'=> 'Horizontal axis general',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'hAxis Min Value', 
							 'name' => 'hAxis__minValue',
							 'type' => 'number',
							 'help' => __('hAxis property that specifies the lowest horizontal axis grid line. The actual grid line will be the lower of two values: the minValue option value, or the lowest data value, rounded down to the next lower grid mark.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Max Value', 
							 'name' => 'hAxis__maxValue',
							 'type' => 'number',
							 'help' => __('hAxis property that specifies the highest horizontal axis grid line. The actual grid line will be the greater of two values: the maxValue option value, or the highest data value, rounded up to the next higher grid mark.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Baseline', 
							 'name' => 'hAxis__baseline',
							 'type' => 'number',
							 'help' => __('The baseline for the horizontal axis.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Base Line Color', 
							 'name' => 'hAxis__baselineColor',
							 'type' => 'color',
							 'help' => __('The color of the baseline for the horizontal axis. Can be any HTML color string, for example: #00cc00.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Direction', 
							 'name' => 'hAxis__direction',
							 'type' => 'number',
							 'help' => __('The direction in which the values along the horizontal axis grow. Specify -1 to reverse the order of the values.','evt'));
							 
							 
	$options_panel[] = array('title'=> 'hAxis Gridlines Color', 
							 'name' => 'hAxis__gridlines__color',
							 'type' => 'color',
							 'help' => __('The color of the horizontal gridlines inside the chart area. Specify a valid HTML color string.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Gridlines Count', 
							 'name' => 'hAxis__gridlines__count',
							 'type' => 'number',
							 'help' => __('The number of horizontal gridlines inside the chart area. Minimum value is 2.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis Log Scale',
							 'name' => 'hAxis__logScale',
							 'type' => 'boolean',
							 'help' => __('hAxis property that makes the horizontal axis a logarithmic scale (requires all values to be positive). Set to true for yes.','evt'));
	
					 			 
	$options_panel[] = array('title'=> 'hAxis View Window Mode',
							 'name' => 'hAxis__viewWindowMode',
							 'type' => 'dropdown', 
							 'list' =>  array('pretty'=>'Pretty','maximized'=>'Maximized','explicit'=>'Explicit'),
							 'help' => __('Specifies how to scale the horizontal axis to render the values within the chart area. The following string values are supported:<br><br><b>pretty</b> - Scale the horizontal values so that the maximum and minimum data values are rendered a bit inside the left and right of the chart area.<br><b>maximized</b> - Scale the horizontal values so that the maximum and minimum data values touch the left and right of the chart area.<br><b>explicit</b> - Specify the left and right scale values of the chart area. Data values outside these values will be cropped. You must specify an hAxis.viewWindow object describing the maximum and minimum values to show.','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis View Window Min', 
							 'name' => 'hAxis__viewWindow__min',
							 'type' => 'number',
							 'help' => __('The minimum horizontal data value to render. Has an effect only if ','evt'));
							 
	$options_panel[] = array('title'=> 'hAxis View Window max', 
							 'name' => 'hAxis__viewWindow__max',
							 'type' => 'number',
							 'help' => __('The maximum horizontal data value to render. Has an effect only if hAxis.viewWindowMode=explicit.','evt'));
	
	$options_panel[] = array('title'=> 'Vertical axis title',
							 'type' => 'title');
							 
	$options_panel[] = array('title'=> 'vAxis Title', 
							 'name' => 'vAxis__title',
							 'type' => 'string',
							 'help' => __('vAxis property that specifies a title for the vertical axis.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Title Text Size',
							 'name' => 'vAxis__titleTextStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the vAxis text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'vAxis Title Text Font',
							 'name' => 'vAxis__titleTextStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the vAxis text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'vAxis Title Text Color',
							 'name' => 'vAxis__titleTextStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the vAxis text style color. For example: red or #00cc00','evt'));			 
							 
							 
	$options_panel[] = array('title'=> 'Vertical axis text',
							 'type' => 'title');
							 
$options_panel[] = array('title'=> 'vAxis Text Position',
							 'name' => 'vAxis__textPosition',
							 'type' => 'dropdown', 
							 'list' =>  array('out'=>'Out','in'=>'In','none'=>'None'),
							 'help' => __('Position of the vertical axis text, relative to the chart area. Supported values: out, in, none.','evt'));
							 					 
	$options_panel[] = array('title'=> 'vAxis Text Size',
							 'name' => 'vAxis__textStyle__fontSize',
							 'type' => 'number',
							 'help' => __('An object that specifies the vAxis Text style size. For example: 22 or 45','evt'));
				
	$options_panel[] = array('title'=> 'vAxis Text Font',
							 'name' => 'vAxis__textStyle__fontName',
							 'type' => 'string',
							 'help' => __('An object that specifies the vAxis Text style font name. For example: arial','evt'));		
							
	$options_panel[] = array('title'=> 'vAxis Text Color',
							 'name' => 'vAxis__textStyle__color',
							 'type' => 'color',
							 'help' => __('An object that specifies the vAxis Text style color. For example: red or #00cc00','evt'));				 
							 
							 				 
	$options_panel[] = array('title'=> 'Vertical axis general',
							 'type' => 'title');	
							 
	$options_panel[] = array('title'=> 'vAxis.minValue', 
							 'name' => 'vAxis__minValue',
							 'type' => 'number',
							 'help' => __('vAxis property that specifies the lowest vertical axis grid line. The actual grid line will be the lower of two values: the minValue option value, or the lowest data value, rounded down to the next lower grid mark.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis.maxValue', 
							 'name' => 'vAxis__maxValue',
							 'type' => 'number',
							 'help' => __('vAxis property that specifies the highest vertical axis grid line. The actual grid line will be the greater of two values: the maxValue option value, or the highest data value, rounded up to the next higher grid mark.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Baseline', 
							 'name' => 'vAxis__baseline',
							 'type' => 'number',
							 'help' => __('vAxis property that specifies the baseline for the vertical axis. If the baseline is smaller than the highest grid line or smaller than the lowest grid line, it will be rounded to the closest gridline.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Base Line Color', 
							 'name' => 'hAxis__baselineColor',
							 'type' =>'color',
							 'help' => __('Specifies the color of the baseline for the vertical axis. Can be any HTML color string, for example: #00cc00.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Direction', 
							 'name' => 'vAxis__direction',
							 'type' => 'number',
							 'help' => __('The direction in which the values along the vertical axis grow. Specify -1 to reverse the order of the values.','evt'));
					 
	$options_panel[] = array('title'=> 'vAxis Gridlines Color', 
							 'name' => 'vAxis__gridlines__color',
							 'type' => 'color',
							 'help' => __('The color of the vertical gridlines inside the chart area. Specify a valid HTML color string.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Gridlines Count', 
							 'name' => 'vAxis__gridlines__count',
							 'type' => 'number',
							 'help' => __('The number of vertical gridlines inside the chart area. Minimum value is 2.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis Log Scale',
							 'name' => 'vAxis__logScale',
							 'type' => 'boolean',
							 'help' => __('If true, makes the vertical axis a logarithmic scale Note: All values must be positive.','evt'));
							 		 
	$options_panel[] = array('title'=> 'vAxis View Window Mode',
							 'name' => 'vAxis__viewWindowMode',
							 'type' => 'dropdown', 
							 'list' =>  array('pretty'=>'Pretty','maximized'=>'Maximized','explicit'=>'Explicit'),
							 'help' => __('Specifies how to scale the vertical axis to render the values within the chart area. The following string values are supported:<br><br><b>pretty</b> - Scale the vertical values so that the maximum and minimum data values are rendered a bit inside the left and right of the chart area.<br><b>maximized</b> - Scale the vertical values so that the maximum and minimum data values touch the left and right of the chart area.<br><b>explicit</b> - Specify the left and right scale values of the chart area. Data values outside these values will be cropped. You must specify an hAxis.viewWindow object describing the maximum and minimum values to show.','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis View Window Min', 
							 'name' => 'vAxis__viewWindow__min',
							 'type' => 'number',
							 'help' => __('The minimum vertical data value to render. Has an effect only if ','evt'));
							 
	$options_panel[] = array('title'=> 'vAxis View Window max', 
							 'name' => 'vAxis__viewWindow__max',
							 'type' => 'number',
							 'help' => __('The maximum vertical data value to render. Has an effect only if vAxis.viewWindowMode=explicit.','evt'));
							 
	$options_panel[] = array('type' => 'div_end'); 
	
	

    $tmp_col = '';
	$tmp_col = array(array('string','Task'),
				array('number','Hours per Day'),
				array('string','URL'));
	
	$tmp_row = '';
	$tmp_row =   array(array('Work',71,'https://www.google.dk/'),
				  array('Eat',32,'https://www.google.dk/imghp?hl=da&tab=wi'),
				  array('Commute',12,'http://maps.google.dk/maps?hl=da&tab=wl'),
				  array('Watch TV',62,'https://www.google.com/calendar/render?tab=wc'),
				  array('Sleep',57,'http://translate.google.dk/?hl=da&tab=wT'),
				  array('Life',100,'https://accounts.google.com/ServiceLogin?service=blogger'));
				 

	$easy_visualization_tools_display['AreaChart'] = array('type'=>'AreaChart',
										 'title'=>'Area Chart',
										 'packages' => 'corechart',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
?>