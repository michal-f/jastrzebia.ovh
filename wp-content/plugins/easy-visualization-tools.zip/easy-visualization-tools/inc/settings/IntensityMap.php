<?php 
 	global $easy_visualization_tools_display;
	$options_panel = '';
	
	
	//----------------- IntensityMap ----------------
	$_countries = array(
	'world' => 'World',
'africa' => 'Africa',
'asia' => 'Asia',
'europe' => 'Europe',
'middle_east' => 'Middle East',
'south_america' => 'South America',
'usa' => 'Usa');			

	// ------------------- General settings -------------------
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the map in pixels. The maximum height of the visualization is 220.<br><br>Note that this height assumes a one-row tab. If your tab text is long, it will wrap the tab to multiple lines, and the extra lines will exceed the specified height.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the map in pixels. <br><br>Note: The maximum width of the visualization is 440. ','evt'));
	
	$options_panel[] = array('title'=> 'General settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Region',
							 'name' => 'region',
							 'type' => 'dropdown',
							 'list' =>  $_countries,
							 'help' => __('The required region. Possible values are: world, africa, asia, europe, middle_east, south_america, and usa. ','evt'));

	$options_panel[] = array('title'=> 'Colors',
							 'name' => 'colors',
							 'type' => 'colors',
							 'help' => __('The colors to use for the chart elements. An array of strings, where each element is an HTML color string, for example:<br><br><b>[red,#004411]</b>','evt'));


    $tmp_col = '';
	$tmp_col = array(array('string','Country'),
				array('number','Populat. (mil)'),
				array('number', 'Area (km2)'));

	
	$tmp_row = '';
	$tmp_row = array(array('CN',1324,9640821),
				array('IN',1133,3287263),
          		array('US',304,9629091),
          		array('ID',232,1904569),
          		array('BR',187,8514877));



	$easy_visualization_tools_display['IntensityMap'] = array('type'=>'IntensityMap',
										 'title'=>'Intensity Map',
										 'packages' => 'intensitymap',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );	
										 
										 
?>