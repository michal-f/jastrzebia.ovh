<?php 
 	global $easy_visualization_tools_display;
 	
	//----------------- Gauge ----------------
				
										 
	$options_panel = '';
	$options_panel[] = array('type' => 'div_start');	
	
	//----------------- General settings ----------------
	
	$options_panel[] = array('title'=>'Size Settings',
							 'type' => 'title');
	
	$options_panel[] = array('title'=> 'Height', 
							 'name' => 'height',
							 'type' => 'number',
							 'help' => __('Height of the chart, in pixels.','evt'));
							 
	$options_panel[] = array('title'=> 'Width', 
							 'name' => 'width',
							 'type' => 'number',
							 'help' => __('Width of the chart, in pixels.','evt'));
	
	$options_panel[] = array('title'=>'General settings',
							 'type' => 'title');
		 
	$options_panel[] = array('title'=> 'Min', 
							 'name' => 'min',
							 'type' => 'number',
							 'help' => __('The minimal value of a gauge.','evt'));
							 
	$options_panel[] = array('title'=> 'Max', 
							 'name' => 'max',
							 'type' => 'number',
							 'help' => __('The maximal value of a gauge.','evt'));	
							 
							 
	$options_panel[] = array('title'=> 'Minor Ticks', 
							 'name' => 'minorTicks',
							 'type' => 'number',
							 'help' => __('The number of minor tick section in each major tick section. ','evt'));	
	
	$options_panel[] = array('title'=> 'majorTicks',
							 'name' => 'majorTicks',
							 'type' => 'string',
							 'help' => __('TLabels for major tick marks. The number of labels define the number of major ticks in all gauges. The default is five major ticks, with the labels of the minimal and maximal gauge value.<br><br><b>[10,75,140]</b>','evt'));		
	
	$options_panel[] = array('type' => 'div_break','extra_td'=>array('width'=>'50%'));
	
	//----------------- Green field ----------------
	$options_panel[] = array('title'=> 'Green field',
							 'type' => 'title');
							 	
	$options_panel[] = array('title'=> 'Green Color', 
							 'name' => 'greenColor',
							 'type' => 'color',
							 'help' => __('The color to use for the green section, in HTML color notation.','evt'));
							 
	$options_panel[] = array('title'=> 'Green From', 
							 'name' => 'greenFrom',
							 'type' => 'number',
							 'help' => __('The lowest value for a range marked by a green color. ','evt'));
							 
	$options_panel[] = array('title'=> 'Green To', 
							 'name' => 'greenTo',
							 'type' => 'number',
							 'help' => __('The highest value for a range marked by a green color.','evt'));

	//----------------- Yellow field ----------------
	$options_panel[] = array('title'=>'Yellow field',
							 'type' => 'title');	
							 
	$options_panel[] = array('title'=> 'Yellow Color', 
							 'name' => 'yellowColor',
							 'type' => 'color',
							 'help' => __('The color to use for the yellow section, in HTML color notation.','evt'));
							 
	$options_panel[] = array('title'=> 'Yellow From', 
							 'name' => 'yellowFrom',
							 'type' => 'number',
							 'help' => __('The lowest value for a range marked by a yellow color. ','evt'));
							 
	$options_panel[] = array('title'=> 'Yellow To', 
							 'name' => 'yellowTo',
							 'type' => 'number',
							 'help' => __('The highest value for a range marked by a yellow color.','evt'));

	//----------------- Red field ----------------
	$options_panel[] = array('title'=> 'Red field',
							 'type' => 'title');
							 	
	$options_panel[] = array('title'=> 'Red Color', 
							 'name' => 'redColor',
							 'type' => 'color',
							 'help' => __('The color to use for the red section, in HTML color notation.','evt'));
							 
	$options_panel[] = array('title'=> 'Red From', 
							 'name' => 'redFrom',
							 'type' => 'number',
							 'help' => __('The lowest value for a range marked by a red color. ','evt'));
							 
	$options_panel[] = array('title'=> 'Red To', 
							 'name' => 'redTo',
							 'type' => 'number',
							 'help' => __('The highest value for a range marked by a red color.','evt'));
	
	$options_panel[] = array('type' => 'div_end'); 
 
    $tmp_col = '';
	$tmp_col = array(array('string','Task'),
				array('number','Hours per Day'));

	
	$tmp_row = '';
	$tmp_row = array(array('Work',71),
				array('Eat',32),
				array('Commute',12),
				array('Watch TV',62),
				array('Sleep',57),
				array('Life',100));
 
 
	$easy_visualization_tools_display['Gauge'] = array('type'=>'Gauge',
										 'title'=>'Gauge',
										 'packages' => 'gauge',
										 'option'=>$options_panel,
										 'test_col' => $tmp_col,
										 'test_row' => $tmp_row,
										 'call_js_func' => 'evt_drawChart'
										 );
						


?>