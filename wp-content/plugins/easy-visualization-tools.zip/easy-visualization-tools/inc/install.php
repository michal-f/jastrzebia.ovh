<?php
function display_statistics_graphs_install(){
    global $wpdb; 

	return true;
}
?>