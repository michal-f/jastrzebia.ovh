<?php
	function evt_create_form($data,$key,$saved_data,$saved_data2 = ''){
	

	
	if(!empty($data['help'])){
		if(empty($data['extra']['onMouseOver'])){
			$data['extra']['onMouseOver'] = 'evt_activate_help(this,\''.$data['title'].'\',\''.$data['help'].'\')';
		}
		
		if(empty($data['extra']['onMouseOut'])){
			$data['extra']['onMouseOut'] = 'evt_hide_help(this)';
		}
	}	
	
	if(empty($data['extra']['onChange'])){
		$data['extra']['onChange'] = 'evt_previewDrawChart()';
	}	


		switch ($data['type']) {
    		case 'title':
        		return evt_create_form_title($data,$key,$saved_data);
        		break;
    		case 'number':
       			return evt_create_form_start($data).evt_create_form_number($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;
    		case 'dropdown':
       			return evt_create_form_start($data).evt_create_form_dropdown($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;
    		case 'string':
       			return evt_create_form_start($data).evt_create_form_string($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;
    		case 'latlng':
       			return evt_create_form_start($data).evt_create_form_latlng($data,$key,$saved_data,$saved_data2).evt_create_help($data).evt_create_form_end();
       			break;
    		case 'checkbox':
       			return evt_create_form_start($data).evt_create_form_checkbox($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;
     		case 'textarea':
       			return evt_create_form_start($data).evt_create_form_textarea($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;
    		case 'boolean':
       			return evt_create_form_start($data).evt_create_form_boolean($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;	
    		case 'color':
       			return evt_create_form_start($data).evt_create_form_color($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;	
    		case 'colors':
       			return evt_create_form_start($data).evt_create_form_colors($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
    		case 'list_data':
       			return evt_create_form_start($data).evt_create_form_list_data($data,$key,$saved_data).evt_create_help($data).evt_create_form_end();
       			break;	
    		case 'div_start':
       			return evt_create_form_div_start($data,$key,$saved_data);
       			break;	
    		case 'div_break':
       			return evt_create_form_div_break($data,$key,$saved_data);
       			break;	
    		case 'div_end':
       			return evt_create_form_div_end($data,$key,$saved_data);
       			break;
    		case 'preview':
       			return evt_create_form_table_preview($data,$key,$saved_data);
       			break;		
       		default:
      			return '';
		}
	}
	
	function evt_create_form_title($data,$key,$saved_data){
		$tmp = '<div class="evt_post_div">';
		$tmp .= '<h4>'.$data['title'].'</h4>';
		$tmp .= '</div>';
		return $tmp;
	}
	
	
	function evt_create_form_latlng($data,$key,$saved_data,$saved_data2){
		$tmp .= '<table width="100%"><tr><td width="50%"><div class="evt_post_input_latlng_lable">Latitude : </div><input type="text" onKeyPress="return numbersonly(this, event)" class="evt_post_input_latlng" id="evt_'.$data['name'].'_lat" name="evt_'.$data['name'].'_lat" value="'.$saved_data.'" ';
		$tmp .=' >';
		$tmp .= '</td><td width="50%"><div class="evt_post_input_latlng_lable">Longitude : </div><input type="text" onKeyPress="return numbersonly(this, event)" class="evt_post_input_latlng" id="evt_'.$data['name'].'_lng" name="evt_'.$data['name'].'_lng" value="'.$saved_data2.'" ';
		$tmp .=' ></td><td width="13%">';
		$tmp .= '<input class="button-secondary" type="submit" style="font-size:12px;height:14px;margin-left:0;margin-right:0;margin-top:13px;padding-left:6px;padding-right:6px;" onClick="evt_get_map_lng_lat(\'evt_'.$data['name'].'\');return false;" value="Geocode" >';
		
		$tmp .='</td>';
		
		
		$tmp .=' </tr></table>';
		
		$tmp .= '<table width="100%"><tr><td width="100%"><div class="evt_post_input_latlng_lable">Address : </div><input type="text" class="evt_post_input" id="evt_'.$data['name'].'_address" name="evt_'.$data['name'].'_address" value="'.$saved_data.'" ';
		$tmp .=' >';

		$tmp .='</td><td  width="10%">';
		$tmp .= '<input class="button-secondary" type="submit" style="font-size:12px;height:14px;margin-left:0;margin-right:0;margin-top:13px;padding-left:6px;padding-right:6px;" onClick="evt_get_address_lng_lat(\'evt_'.$data['name'].'\');return false;" value="Address" >';
		
		$tmp .='</td>';
		
		
		$tmp .=' </tr></table>';
		return $tmp;
	}	

	function evt_create_form_string($data,$key,$saved_data){
		$tmp .= '<input type="text" class="evt_post_input" name="evt_'.$data['name'].'" value="'.$saved_data.'" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >';
		return $tmp;
	}
	
	function evt_create_form_checkbox($data,$key,$saved_data){
	
		if(empty($data['value'])){
			$data['value'] = 'true';
		
		}
	
		$tmp .= '<input type="checkbox" class="evt_post_checkbox" name="evt_'.$data['name'].'" value="'.$data['value'].'" ';
		
		if($saved_data == 'true'){
			$tmp .= ' checked = "checked" '; 
		}
		
		
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >';
		return $tmp;
	}	
	
	function evt_create_form_textarea($data,$key,$saved_data){
		$tmp .= '<textarea class="evt_post_textarea" name="evt_'.$data['name'].'" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >'.$saved_data.'</textarea>';
		return $tmp;
	}
	
	

	function evt_create_form_number($data,$key,$saved_data){
		$tmp .= '<input type="text" onKeyPress="return numbersonly(this, event)" class="evt_post_input_numbers" name="evt_'.$data['name'].'" value="'.$saved_data.'" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >';		
		
		return $tmp;
	}

	function evt_create_form_dropdown($data,$key,$saved_data){
		if(empty($saved_data)){
			if(!empty($data['default'])){
				$saved_data = $data['default'];
			}			
		}
		$tmp .= '<select  id="evt_'.$data['name'].'" name="evt_'.$data['name'].'" class="evt_post_dropdown" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .= ' >';
		
		foreach($data['list'] as  $key => $list_tmp){
			$tmp 	.='<option value="'.$key.'" ';
			
			if($key == $saved_data && $key != '---' && $key != '----'){
				$tmp 	.= ' selected="selected" ';
			}
			
			if( ($key == '---' || $key == '----') && !empty($key)){
			$tmp 	.= ' disabled="disabled" ';
			}
			$tmp 	.='>'.__($list_tmp,"evt").'</option>';
		}

		
		$tmp .='</select>';
		return $tmp;
		
	}
	
	function evt_create_form_boolean($data,$key,$saved_data){
		
		$data['extra2']['onChange'] = $data['extra']['onChange'];
		$data['extra']['onChange'] = '';
	
		if(!empty($data['default']) && empty($saved_data) ){
			$saved_data = $data['default'];
		}		
	
		$tmp .= '<div';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .= '>';
		$tmp .= '<input type="radio" class="evt_post_radio" name="evt_'.$data['name'].'" value="true" ';
		$tmp .= evt_create_form_extra($data['extra2']);
		if($saved_data == 'true'){
			$tmp .= ' checked="checked" ';
		}
		$tmp .= ' > <lable>'.__('Yes','evt').'</lable> ';
		$tmp .= '<input type="radio" class="evt_post_radio" name="evt_'.$data['name'].'" value="false" ';
		$tmp .= evt_create_form_extra($data['extra2']);
		
		if($saved_data == 'false' || empty($saved_data)){
			$tmp .= ' checked="checked" ';
		}
		$tmp .= ' > <lable>'.__('No','evt').'</lable></div>';
		return $tmp;
	}
	
	function evt_create_form_color($data,$key,$saved_data){
		if(empty($saved_data)){
			if(!empty($data['default'])){
				$saved_data = $data['default'];
			} else {
				$saved_data = "#";
			}
		}
	
		$tmp = 	 '<div class="farbtastic-holder">';
		$tmp .= 		'<input type="text" value="'.$saved_data.'" class="evt_post_color show-colorpicker" name="evt_'.$data['name'].'" id="cs_menu_current_font_color'.$key.'" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >';		
		$tmp .= 		'<div class="pop-farbtastic" rel="#cs_menu_current_font_color'.$key.'" id="pop-farbtastic-'.$key.'" style="float:left;display: block;">';
		$tmp .= 			'<div class="farbtastic">';
		$tmp .=					'<div class="color" style="background-color: rgb(255, 0, 0);"></div>';
		$tmp .=					'<div class="wheel"></div>';
		$tmp .=					'<div class="overlay"></div>';
		$tmp .=					'<div class="h-marker marker" style="left: 97px; top: 13px;"></div>';
		$tmp .=					'<div class="sl-marker marker" style="left: 147px; top: 147px;"></div>';
		$tmp .=				'</div>';
		$tmp .=			'</div>';
		$tmp .=		'</div>';
		return $tmp;
	}

	function evt_create_form_colors($data,$key,$saved_data){
	
		$tmp = 	 '<div class="farbtastic-holder">';
		$tmp .= 		'<table width="100%" cellspacing="0"><tr><td width="100%"><input type="text" value="#" class="evt_post_color show-colorpicker" name="tmp_'.$data['name'].'" id="cs_menu_current_font_color'.$key.'" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .=' >';		
		$tmp .= 		'<div class="pop-farbtastic" rel="#cs_menu_current_font_color'.$key.'" id="pop-farbtastic-'.$key.'" style="float:left;display: block;">';
		$tmp .= 			'<div class="farbtastic">';
		$tmp .=					'<div class="color" style="background-color: rgb(255, 0, 0);"></div>';
		$tmp .=					'<div class="wheel"></div>';
		$tmp .=					'<div class="overlay"></div>';
		$tmp .=					'<div class="h-marker marker" style="left: 97px; top: 13px;"></div>';
		$tmp .=					'<div class="sl-marker marker" style="left: 147px; top: 147px;"></div>';
		$tmp .=				'</div>';
		$tmp .=			'</div>';
		$tmp .=			'<div id="evt_post_colors_list'.$key.'" class="evt_post_colors_list">';
		
		$tmp_saved_data = str_replace(array('[',']'),array('',''),$saved_data);
		
		$tmp_pieces = explode(",", $tmp_saved_data);
		
		if(!empty($tmp_saved_data)){
		foreach($tmp_pieces as $tmp_piece){
			$tmp .= '<div class="clear"><div class="evt_post_colors_list_image" style="background-color: '.$tmp_piece.';"></div><span style="float:left;min-width:45px">'.$tmp_piece.'</span><div style="float:left"><a href="#" onclick="evt_remove_colors(this,\'#evt_post_colors_list'.$key.'\',\'#evt_'.$data['name'].'\');return false;">(remove)</a></div></div>';
		}
		}
		$tmp .=	'</div>';
		$tmp .=		'</div>';	
		
		$tmp .= 		'</td><td valign="top"><input class="button-secondary" type="submit" style="font-size:12px;height:14px;margin-left:5px;margin-right:0;padding-left:6px;padding-right:6px;z-index:30000" onClick="evt_add_colors(\'#cs_menu_current_font_color'.$key.'\',\'#evt_post_colors_list'.$key.'\',\'#evt_'.$data['name'].'\');return false;" value="Add" ></td></tr></table>';
		
		$tmp .=		'</div>';

		$tmp .= 	'<input style="display:none;" type="text" value="'.$saved_data.'" id="evt_'.$data['name'].'" name="evt_'.$data['name'].'" >';
		
		return $tmp;
	}

	function evt_create_form_list_data($data,$key,$saved_data){
		$tmp .= '<div id="evt_current_data_list_info'.$key.'"><table width="100%" cellspacing="0"><tr><td width="95%"><table width="100%" cellspacing="0"><tr>';
		$count = 0;
		
		
		if(!empty($data['content_data'])){
		
			$tmp_procent = 95/count($data['content_data']);
		
			foreach($data['content_data'] as $tmp_key => $tmp_data){
			
				if($count> 2){
					$tmp .= '</tr><tr>';
					$count = 0;	
				}
			
				$tmp .= '<td width="'.$tmp_procent.'%">';
				
				if($tmp_key == 'pointSize' || $tmp_key == 'lineWidth'){
					$tmp .= '<select id="'.$tmp_key.'" class="evt_post_dropdown">';		
					$tmp .= '<option value="" selected="selected">'.$tmp_data.'</option>';	
					for($xx = 0;$xx<101;$xx++){
						$tmp .= '<option value="'.$xx.'">'.$xx.'</option>';	
					}
					$tmp .='</select>';	
				}
				
				if($tmp_key == 'areaOpacity'){
					$tmp .= '<select id="'.$tmp_key.'" class="evt_post_dropdown">';		
					$tmp .= '<option value="" selected="selected">'.$tmp_data.'</option>';
					$tmp .= '<option value="0.0">0.0</option>';	
					for($xx = 0.1;$xx<0.9;$xx+=0.1){
						$tmp .= '<option value="'.$xx.'">'.$xx.'</option>';	
					}
					$tmp .= '<option value="1.0">1.0</option>';	
					$tmp .='</select>';	
				}
				
				if($tmp_key == 'type'){
					$tmp .= '<select id="'.$tmp_key.'" class="evt_post_dropdown">';		
					$tmp .= '<option value="" selected="selected">'.$tmp_data.'</option>';	
					$tmp .= '<option value="line">Line</option>';
					$tmp .= '<option value="bars">Bars</option>';
					$tmp .= '<option value="area">Area</option>';
					$tmp .='</select>';	
				}		
				
				if($tmp_key == 'curveType'){
					$tmp .= '<select id="'.$tmp_key.'" class="evt_post_dropdown">';		
					$tmp .= '<option value="" selected="selected">'.$tmp_data.'</option>';	
					$tmp .= '<option value="function">Function</option>';
					$tmp .='</select>';	
				}	
				$tmp .= '</td>';
				$count++;	
			}
		}
		
		$tmp .= '</tr></table></td><td valign="top"><input class="button-secondary" type="submit" style="font-size:12px;height:14px;margin-left:5px;margin-right:0;padding-left:6px;padding-right:6px;z-index:30000" onClick="evt_add_data_list(\'#evt_current_data_list_info'.$key.'\',\'#evt_post_data_list'.$key.'\',\'#evt_'.$data['name'].'\');return false;" value="Add" ></td>';
		
		$tmp .= '</tr></table></div>';
		$tmp .= 	'<input style="display:none;" type="text" value="'.$saved_data.'" id="evt_'.$data['name'].'" name="evt_'.$data['name'].'" >';
		$tmp .=		'<ul id="evt_post_data_list'.$key.'" style="margin-left:5px" class="evt_post_data_list">';	
		
		if(!empty($saved_data)){
			$saved_data_collections = array();
			
			$saved_data = substr($saved_data,1); 
			$saved_data = str_replace('}','',$saved_data);
			$saved_data = explode('{', $saved_data);
			
			foreach($saved_data as $temp_key1 => $temp_level1){
				$temp_level1 = str_replace('{','',$temp_level1);
				$temp_level2 = explode(',', $temp_level1);
				
				foreach($temp_level2 as $temp_key2 => $temp_level3){
					$temp_level4 = explode(':', $temp_level3);
					if(!is_numeric($temp_level4[0])){
						$saved_data_collections[$temp_key1][$temp_level4[0]] = $temp_level4[1];
					}
				}
			}
			
			if(count($saved_data_collections) > 0){
				foreach($saved_data_collections as $saved_data_collection){
					if(count($saved_data_collection)>0){
						$tmp .=	'<li class="evt_form_list_data_item clear">';
					}
					if(count($saved_data_collection)>0){
						foreach($saved_data_collection as $saved_data_key => $saved_data_item){
							$tmp .=	'<span id="'.$saved_data_key.'">'.$saved_data_key.': '.$saved_data_item.'</span>';
						}	
					}
					if(count($saved_data_collection)>0){
						$tmp .=	'<span><a href="#" onclick="evt_remove_data_list(this,\'#evt_post_data_list'.$key.'\',\'#evt_'.$data['name'].'\');return false;">(remove)</a></span>';
						$tmp .=	'</li>';
					}
					
				}
			}
			
		}
		
		$tmp .=		'</ul>';
		return $tmp;
	}





	function evt_create_form_start($data){
		$tmp = '<div class="evt_post_div">';
		$tmp .= '<table width=100%><tr><td valign="middle">';
		$tmp .= '<lable class="evt_post_lable" ';
		$tmp .= evt_create_form_extra($data['extra_lable']);
		$tmp .= ' >'.$data['title'].' :</lable>';
		$tmp .= '</td><td valign="top">';
		$tmp .= '</td><td valign="top" width="100%">';
		return $tmp;
	}
	function evt_create_form_end(){
		$tmp = '</td></tr></table>';
		$tmp .='</div>';
		return $tmp;
	}

	function evt_create_form_extra($extra){
		$tmp = '';
		if(!empty($extra)){
			foreach($extra as $key_tmp => $data_tmp){
				$tmp .= ' '.$key_tmp.'="'.$data_tmp.'" ';
			}
		}
		return $tmp;
	}
	
	function evt_create_form_div_start($data,$key,$saved_data){
		$tmp = '<div class="evt_post_div_col" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .= ' >';
		return $tmp;
	}
	
	function evt_create_form_div_break($data,$key,$saved_data){
		$tmp = '</div><div class="evt_post_div_col" ';
		$tmp .= evt_create_form_extra($data['extra']);
		$tmp .= ' >';
		return $tmp;
	}
	
	function evt_create_form_div_end($data,$key,$saved_data){

		$tmp = '</div><div class="evt_post_div_clear"></div>';
		return $tmp;
	}
	
	function evt_create_help($data){
		$tmp = '';
		return $tmp;
	}		
	
	
	function evt_create_form_table_preview($data,$key,$saved_data){
    	$tmp .= '<div id="chart_div"></div>';
    
		return $tmp;
	}
	
?>
