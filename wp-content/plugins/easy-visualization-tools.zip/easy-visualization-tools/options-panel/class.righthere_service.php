<?php

/**
 * 
 *
 * @version $Id$
 * @copyright 2003 
 **/

class righthere_service {
	function righthere_service(){
	
	}
	
	function rh_service($url){
		$request = wp_remote_post( $url );
		if ( is_wp_error($request) ){
			return false;
		}else{
			$r = json_decode($request['body']);
			if(is_object($r)&&property_exists($r,'R')){
				return $r;
			}else{
				return false;
			}	
		}
		return false;
	}
}
?>