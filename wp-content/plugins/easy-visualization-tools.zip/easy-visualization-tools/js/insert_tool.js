jQuery(document).ready(function($){
	if( $('#evt-insert-tool-trigger').length > 0 && $('#evt-insert-tool').length > 0){
		$('#evt-insert-tool-trigger').click(function(e){
			$('#evt-insert-tool').css('top', $(document).scrollTop() );
			$('#evt_chart_selected').val('').change();	
			$('#evt-insert-tool').fadeIn();		
		});
		
		$('#evt-insert-tool').find('.evt-close-icon-a').click(function(e){
			$('#evt-insert-tool').fadeOut();	
		});
	}
});

/* CSSEditor */
jQuery(document).ready(function($){
	$('#evt_chart_selected').change(function(){
		var html_backup;
		if($('#evt_chart_selected').val()){
			jQuery('#preview_chart_evt').fadeTo('fast', 0.0);
			jQuery('#data_loaded_evt').fadeTo('fast', 0.0, function() {
				html_backup = jQuery('#data_loaded_evt').html();
				
				jQuery('#preview_chart_evt').html('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'images/loader.gif">');
				jQuery('#data_loaded_evt').html('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'images/loader.gif">');
				
				jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
				jQuery('#data_loaded_evt').fadeTo('fast', 1.0, function() {
					_url = EASY_VISUALIZATION_TOOLS_CHART_URL+'frames/load_tinmce_button_data.php';	  

					jQuery.post(_url,{post_id:$('#evt_chart_selected').val()},function(data){
						jQuery('#preview_chart_evt').fadeTo('fast', 0.0);
						jQuery('#data_loaded_evt').fadeTo('fast', 0.0, function() {
							if(data.R == 'OK'){
								jQuery('#data_loaded_evt').html(html_backup);
								if(data.SHORTCODE){
									jQuery('#evt_shortcode').html(data.SHORTCODE);
								} else {
									jQuery('#evt_shortcode').html('');
								}
								if(data.COMMENTS){
									jQuery('#evt_comments').html(data.COMMENTS);
								} else {
									jQuery('#evt_comments').html('');
								}
								
								if(data.FLAG){
									var evt_setting_object = JSON.parse(decodeURI(data.SETTINGS));
										evt_setting_object['width'] = 330;
										evt_setting_object['height'] = 270;
								
									if(data.TYPEDATA == 0){
										var evt_row_object = JSON.parse(decodeURI(data.ROW));
										var evt_collum_object = JSON.parse(decodeURI(data.COL));
										if(data.CALLJSFUNC != '')
										{	
										
										window[data.CALLJSFUNC](data.PACKAGES,data.FLAG,'preview_chart_evt',evt_collum_object,evt_row_object,evt_setting_object);
										
											jQuery('#data_loaded_evt').fadeTo('fast', 1.0);
											jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
										} else {
											_url = data.CALLPHPFILE;
											jQuery.post(_url,{COL:evt_collum_object,ROW:evt_row_object,SETTINGS:evt_setting_object},function(data){
												document.getElementById('preview_chart_evt').innerHTML = data.PREV;
												jQuery('#data_loaded_evt').fadeTo('fast', 1.0);
												jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
											},'json');
										}		
									} else if(data.TYPEDATA > 0){
										var _url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/excel_converter_to_data.php';
										var _url_excel = '';
										
										if(data.TYPEDATA == 1){
											_url_excel = data.MEDIAFILE;
										} else if(data.TYPEDATA == 2){
											_url_excel = data.URLDATA;
										} else if(data.TYPEDATA == 3){
											_url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/get_google_analytics.php';
											_url_excel = '';
										}

										jQuery.post(_url,{_url_excel:_url_excel,loading:true,post_id:$('#evt_chart_selected').val()},function(data2){
											if(data2){
												if(data2.ROW){
													var evt_row_object = data2.ROW;
												}
	
												if(data2.COL){
													var evt_collum_object = data2.COL;
												}	

												if(data.CALLJSFUNC != ''){
												window[data.CALLJSFUNC](data.PACKAGES,data.FLAG,'preview_chart_evt',evt_collum_object,evt_row_object,evt_setting_object);
													jQuery('#data_loaded_evt').fadeTo('fast', 1.0);
													jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
												} else {
													jQuery.post(data.CALLPHPFILE,{COL:evt_collum_object,ROW:evt_row_object,SETTINGS:evt_setting_object},function(data){
														document.getElementById('preview_chart_evt').innerHTML = data.PREV;
														jQuery('#data_loaded_evt').fadeTo('fast', 1.0);
														jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
													},'json');
												}
													
	
											}
										},'json').error(function() { alert("Error No data found"); })
									}
								}
								
								jQuery('#data_loaded_evt').fadeTo('fast', 1.0);
								jQuery('#preview_chart_evt').fadeTo('fast', 1.0);
							} else {
								alert(data.MSG);
							}
						});	
					},"json");
				});
			});	
		} else {
			jQuery('#preview_chart_evt').fadeTo('fast', 0.0);
			jQuery('#data_loaded_evt').fadeTo('fast', 0.0);
		}

	});
	$('#evt_chart_selected').val('').change();	
});

function evt_input_change_value(){
	jQuery(document).ready(function($){
		var evt_border = jQuery('#evt_border').val();
		var evt_vspace = jQuery('#evt_vspace').val();
		var evt_hspace = jQuery('#evt_hspace').val();
		var str = '';
	
		if(evt_border != '' && !isNaN(evt_border)){
			str += 'border: '+evt_border+'px solid black;';
		}	
		if(evt_vspace != '' && evt_hspace == '' && !isNaN(evt_vspace)){
			str += 'margin-top: '+evt_vspace+'px; margin-bottom: '+evt_vspace+'px;';
		} else if(evt_vspace == '' && evt_hspace != '' && !isNaN(evt_hspace)){
			str += 'margin-right: '+evt_hspace+'px; margin-left: '+evt_hspace+'px;';
		} else if(evt_vspace != '' && evt_hspace != '' && !isNaN(evt_hspace) && !isNaN(evt_vspace)){
			if(evt_vspace == evt_hspace){
				str += 'margin: '+evt_hspace+'px;';
			} else {
				str += 'margin: '+evt_vspace+'px '+evt_hspace+'px;';
			}
		}
	
		jQuery('#evt_style').val(str);
	
	});
}


function insert_evt_shortcode(){
	jQuery(document).ready(function($){
    	var str = '';
		var str_class = '';
		var str_style = '';
		var str_radio_class = ''; 
		
		str = jQuery('#evt_shortcode').html();
		str = str.replace(']','');
		
		str_class = jQuery('#evt_class').val();
		str_style = jQuery('#evt_style').val();
		
		str_radio_class = jQuery("#evt_radio_list input[@name=evt_align]:checked").val();

		if(str_class != ''){
			str_class = str_class + ' ';
		}
		
		str += ' class="evt_cdiv '+str_class+str_radio_class+ '" ';

		if(str_style != ''){
			str += ' style="' +str_style+'" ';
		}	
		
		str += ']';

		if(str){
			send_to_editor(str);
			var ed;
			if ( typeof tinyMCE != 'undefined' && ( ed = tinyMCE.activeEditor ) && !ed.isHidden() ) {
				ed.setContent(ed.getContent());
			}
			$('#evt-insert-tool').fadeOut();
		} else {
			alert('Pleas chose a chart');
		}
	});
}
