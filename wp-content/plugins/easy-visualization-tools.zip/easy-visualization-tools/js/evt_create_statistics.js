var evt_list_charts = new Array();
var evt_list_charts_timeoutHandle;

var evt_preview_new_window = false;
var evt_preview_lock_down = false;

function evt_drawChart(evt_packages,evt_flag,div_tmp,evt_col,evt_row,evt_settings,preview_version){
	if(preview_version == 'true'){
		evt_list_charts = new Array();
	}
	
	
	
	if(typeof(evt_col)=='string'){
		evt_col = JSON.parse(decodeURI(evt_col));
	}
	
	if(typeof(evt_row)=='string'){
		evt_row = JSON.parse(decodeURI(evt_row));
	}	
	
	if(typeof(evt_settings)=='string'){
		evt_settings = JSON.parse(decodeURI(evt_settings));
	}
	
	var tmp = new Array();
	tmp['div'] = div_tmp;
	tmp['flag'] = evt_flag;
	tmp['packages'] = evt_packages;
	tmp['settings'] = evt_settings;	
	tmp['col'] = evt_col;	
	tmp['row'] = evt_row;
	tmp['row_selected'] = '';
	tmp['url'] = new Array();	
	tmp['main'] = '';

	evt_list_charts.push(tmp);
	
	window.clearTimeout(evt_list_charts_timeoutHandle);
	evt_list_charts_timeoutHandle = window.setTimeout(evt_create_charts,34);
}

function evt_create_charts(){
	var load_array = new Array(); 
	var check_if_exist = false;
	

	for( xx in evt_list_charts ){
		check_if_exist = false;
		for( yy in load_array ){
			if(evt_list_charts[xx]['packages'] == load_array[yy]){
				check_if_exist = true;
			}
		}
		
		if(!check_if_exist){
			load_array.push(evt_list_charts[xx]['packages']);
		}
	}

	if(load_array.length > 0){
			google.load("visualization", "1", {"callback": evt_drawChart_multi, "packages":load_array});
	}
}


function evt_drawChart_multi(){
	for( xx in evt_list_charts ){
		evt_drawChart_With_Date(xx);	
	}
}

function evt_drawChart_With_Date (chart_id){
	var data = new google.visualization.DataTable();
    var letter_array =  new Array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p');
    var check_type = 0;
    var error = false;
    
    var temp_remove_array = '';
    
	for(var jx in evt_list_charts[chart_id]['row'])
	{
		for(var ix in evt_list_charts[chart_id]['col'])
		{
		
			if(evt_list_charts[chart_id]['col'][ix][0] == 'string'){
				evt_list_charts[chart_id]['row'][jx][ix] = evt_list_charts[chart_id]['row'][jx][ix].toString();
			} else if(evt_list_charts[chart_id]['col'][ix][0] == 'number'){
				evt_list_charts[chart_id]['row'][jx][ix] = parseFloat(evt_list_charts[chart_id]['row'][jx][ix]);
			} else if(evt_list_charts[chart_id]['col'][ix][0] == 'boolean'){
				if(evt_list_charts[chart_id]['row'][jx][ix] == "true"){
					evt_list_charts[chart_id]['row'][jx][ix] = true;
				} else if(evt_list_charts[chart_id]['row'][jx][ix] == "false"){
					evt_list_charts[chart_id]['row'][jx][ix] = false;
				}
			} else if(evt_list_charts[chart_id]['col'][ix][0] == 'date'){
				evt_list_charts[chart_id]['row'][jx][ix] = new Date(evt_list_charts[chart_id]['row'][jx][ix]);
			}
				
			if(evt_list_charts[chart_id]['flag'] == 'IntensityMap'){
				if(ix == 0){
					evt_list_charts[chart_id]['col'][ix][2] = 'Country';
				} else {
					evt_list_charts[chart_id]['col'][ix][2] = letter_array[(ix-1)];
				}
			}
			
			if(evt_list_charts[chart_id]['col'][ix][1].toLowerCase()  == 'url'){
				temp_remove_array = ix;
				evt_list_charts[chart_id]['url'].push(evt_list_charts[chart_id]['row'][jx][ix]);
				evt_list_charts[chart_id]['row'][jx].splice(ix, 1);
			}
			
				
		}
	}
		
	if(temp_remove_array != ''){
		evt_list_charts[chart_id]['col'].splice(temp_remove_array, 1);
	}

	if(evt_list_charts[chart_id]['flag'] == 'PieChart' || 
		evt_list_charts[chart_id]['flag'] == 'ComboChart' || 
		evt_list_charts[chart_id]['flag'] == 'LineChart' || 
		evt_list_charts[chart_id]['flag'] == 'BarChart' || 
		evt_list_charts[chart_id]['flag'] == 'ColumnChart' || 
		evt_list_charts[chart_id]['flag'] == 'AreaChart'){
		   
		check_type = 1;
	} else if(evt_list_charts[chart_id]['flag'] == 'AnnotatedTimeLine'){
		check_type = 2;
		if(evt_list_charts[chart_id]['col'][0][0] != 'date' || evt_list_charts[chart_id]['col'][1][0] != 'number'){
			error = true;
		}
	}
		
		
	for(var i in evt_list_charts[chart_id]['col'])
	{	
		if(check_type == 1){
			if(evt_list_charts[chart_id]['col'][i][0] != 'number' && i > 0 && evt_list_charts[chart_id]['col'][i][1].toLowerCase()  != 'url'){
				error = true;
			}
		} 
		
		data.addColumn(evt_list_charts[chart_id]['col'][i][0], 
					   evt_list_charts[chart_id]['col'][i][1], 
					   evt_list_charts[chart_id]['col'][i][2]);
	}



	var evt_preview_tmp1 = document.getElementById(evt_list_charts[chart_id]['div']);
		

	data.addRows(evt_list_charts[chart_id]['row']);
	if(evt_preview_new_window){
		var evt_preview_tmp2 = evt_popup.document.getElementById('preview');
				
		evt_preview_tmp1.style.width = "100%";
		evt_preview_tmp1.style.height = "30px";
				
		if(!error){
			evt_preview_tmp1.style.backgroundColor = '';
			evt_popup.window.resizeTo(evt_list_charts[chart_id]['settings'].width,evt_list_charts[chart_id]['settings'].height+75)
			evt_preview_tmp2.style.width = evt_list_charts[chart_id]['settings'].width+"px";
			evt_preview_tmp2.style.height = evt_list_charts[chart_id]['settings'].height+"px";
			
			
			
			evt_list_charts[chart_id]['main'] = new google.visualization[evt_list_charts[chart_id]['flag']](evt_preview_tmp2);
			evt_list_charts[chart_id]['main'].draw(data, evt_list_charts[chart_id]['settings']);
			if(evt_list_charts[chart_id]['settings'].gotoUrl > 1 && evt_list_charts[chart_id]['url'] != ''){
				google.visualization.events.addListener(evt_list_charts[chart_id]['main'], 'select', function (){
					
					if( evt_list_charts[chart_id]['main'].getSelection()[0]){
						var row = evt_list_charts[chart_id]['main'].getSelection()[0].row;
					} else {
						var row = evt_list_charts[chart_id]['row_selected'];
					}
					
					evt_list_charts[chart_id]['row_selected'] = row;
					
    				var tmp_data = '',
					
					tmp_data = evt_list_charts[chart_id]['url'][row];
				
					if(evt_list_charts[chart_id]['settings'].gotoUrl == 2 && tmp_data != '' ){
						location=tmp_data;
					
					} else if(evt_list_charts[chart_id]['settings'].gotoUrl == 3 && tmp_data != ''){
						window.open(tmp_data, '_blank');
					}
				});
			}
			
			
			
			evt_preview_tmp1.innerHTML = 'The chart is shown in a new window. Close the window to return chart to this location.';
		} else {
			evt_preview_tmp1.style.backgroundColor = '';
			evt_preview_tmp2.style.width = "400px";
			evt_popup.window.resizeTo(400,105)
			evt_preview_tmp2.style.height = "30px";
			evt_preview_tmp2.innerHTML = evt_error_message(check_type,'preview');
			evt_preview_tmp1.innerHTML = evt_error_message(check_type,evt_list_charts[chart_id]['div']);
		}
	} else {
		if(!error){
			evt_preview_tmp1.style.backgroundColor = '';
		
			evt_preview_tmp1.style.width = evt_list_charts[chart_id]['settings'].width+"px";
			evt_preview_tmp1.style.height = evt_list_charts[chart_id]['settings'].height+"px";			
			
			evt_list_charts[chart_id]['main'] = new google.visualization[evt_list_charts[chart_id]['flag']](evt_preview_tmp1);
			evt_list_charts[chart_id]['main'].draw(data, evt_list_charts[chart_id]['settings']);
	
		
			if(evt_list_charts[chart_id]['settings'].gotoUrl > 1 && evt_list_charts[chart_id]['url'] != ''){
				google.visualization.events.addListener(evt_list_charts[chart_id]['main'], 'select', function (){

					if( evt_list_charts[chart_id]['main'].getSelection()[0]){
						var row = evt_list_charts[chart_id]['main'].getSelection()[0].row;
					} else {
						var row = evt_list_charts[chart_id]['row_selected'];
					}
					
					evt_list_charts[chart_id]['row_selected'] = row;
					
    				var tmp_data = '',
					
					tmp_data = evt_list_charts[chart_id]['url'][row];
				
	
				
					if(evt_list_charts[chart_id]['settings'].gotoUrl == 2 && tmp_data != '' ){
						location=tmp_data;
					
					} else if(evt_list_charts[chart_id]['settings'].gotoUrl == 3 && tmp_data != ''){
						window.open(tmp_data, '_blank');
					}
				});
			}

	
		
		} else {
			evt_preview_tmp1.style.backgroundColor = '';
			evt_preview_tmp1.style.width = "100%";
			evt_preview_tmp1.style.height = "30px";
			evt_preview_tmp1.innerHTML = evt_error_message(check_type,evt_list_charts[chart_id]['div']);
		}
	}
}

function evt_error_message(check_type,div_id){
	if(div_id == 'preview' || div_id == 'chart_div'){
		if(check_type == 1){
			return 'Error in data : 2. column and after has to be numbers';
		} else if(check_type == 2){
			return 'Error in data : 1. column has to be date and 2, column has to be numbers';
		}
	}
	
	return '';
}