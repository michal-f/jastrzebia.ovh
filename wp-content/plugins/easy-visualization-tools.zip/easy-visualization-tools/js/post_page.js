// Current global variables
var evt_global_dataRows;
var evt_global_Column;
var evt_global_test_dataRows;
var evt_global_test_Column;

var evt_save_resize_value = 0;
var evt_current; 
var evt_popup;
var evt_empty_array = new Array();
var evt_manaul_change = false;
var evt_chart_type;
var evt_chart_core;
var evt_chartSettings;
var evt_timer_chekker;


var evt_call_js_file = '';
var evt_call_js_func = '';
var evt_call_php_file = '';
var evt_call_php_func = '';

// Start up functions
jQuery(document).ready(function($){
	// start loading on page open
	evt_getData('#evt_flag');
	
	
	// Add show/hide/resize functions
	var evt_width_icons = jQuery('#evt-settings-preview h3 span').width();
	evt_width_icons += 7;
	jQuery('#evt-settings-preview').prepend('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'/images/reload.png" id="evt_select_image_preview" style="margin-left:'+(evt_width_icons+15)+'px"><img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'/images/window-manager.png" style="margin-left:'+(evt_width_icons+40)+'px" id="evt_select_image_preview_manager">' );
	
	jQuery('#advanced-sortables,#side-sortables,#normal-sortables').children().each(function(i,o){
		if(!check_and_remove_meta_boxes(jQuery(this).attr('id'))){
			jQuery(this).hide();
		};
	});
	jQuery(window).resize(evt_resize_metaboxes);


	// Click functions 
	// On the loading of each button
	jQuery("#evt_loading_data input:submit").click(function() {
		var value = jQuery("#evt_loading_data input[@name=evt_type_of_loaded_data]:checked").val();

		if(value == 0){
			evt_create_table(false);
		} else {
			evt_current = jQuery(this);
			jQuery(this).fadeTo('fast', 0.0, function() {
				jQuery(this).hide();
				jQuery(this).next('div').fadeTo('fast', 1.0, function() {
					var _url_excel;
					var _url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/excel_converter_to_data.php';
					var google_a_email = jQuery("#evt_analytics_email").val();
					var google_a_code = jQuery("#evt_analytics_code").val();					
					var google_a_profile_id = jQuery("#evt_analytics_profile_id").val();
					var google_a_metrics_show = [];
					var google_a_dimensions  = jQuery("#evt_analytics_dimensions").val();
					var google_a_dimensions_max  = jQuery("#evt_analytics_dimensions_max").val();                                                                                                                                                                                                                                                                                                                                                                                         
					var google_a_dimensions_show = jQuery("#evt_analytics_dimensions_show").val();
					var google_a_date_show = 0;
					var google_a_date_to = jQuery("#evt_analytics_date_to").val();
					var google_a_date_from = jQuery("#evt_analytics_date_from").val();
					var google_a_dimensions_show_dir = jQuery('#evt_analytics_dimensions_show_dir').val();
					var google_a_piechart = false;	
							
										
					if(value == 1){
						_url_excel = jQuery("#evt_mediefile").val();
					} else if(value == 2){
						if(evt_check_filetype(jQuery("#evt_get_url_data").val()) == 'php'){
							_url = jQuery("#evt_get_url_data").val();
						} else {
							_url_excel = jQuery("#evt_get_url_data").val();
						}
					} else if(value == 3){
						_url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/get_google_analytics.php';
						jQuery(".evt_analytics_metrics_show").each(function(i,o) {
							if(jQuery(this).attr('checked')){
								google_a_metrics_show.push(jQuery(this).val()); 
							}
						})
						if(jQuery("#evt_analytics_date_show").attr('checked')){
							google_a_date_show = 1;
						}

						if(jQuery('#evt_flag option:selected').val() == 'BarChart' || jQuery('#evt_flag option:selected').val() == 'ColumnChart'){
							google_a_piechart = true;
						}
						
					}
					
					jQuery.post(_url,{_url_excel:_url_excel,post_id:post_id,evt_analytics_email:google_a_email,evt_analytics_code:google_a_code,evt_analytics_profile_id:google_a_profile_id,evt_analytics_metrics_show:google_a_metrics_show,evt_analytics_dimensions:google_a_dimensions,evt_analytics_dimensions_show:google_a_dimensions_show,evt_analytics_date_show:google_a_date_show,evt_analytics_date_to:google_a_date_to,evt_analytics_date_from:google_a_date_from,evt_analytics_dimensions_show_dir:google_a_dimensions_show_dir,evt_analytics_dimensions_max:google_a_dimensions_max,evt_analytics_piechart:google_a_piechart},function(data){
						jQuery(evt_current).next('div').fadeTo('fast', 0.0, function() {
							jQuery(evt_current).fadeTo('fast', 1.0);
						
							if(data){
								if(data.R == 'OK'){
									if(data.TITLE){
										if(jQuery("#title").val() == ''){
											jQuery("#title-prompt-text").css('visibility','hidden');
											jQuery("#title").val(data.TITLE);
										};
									}
					
									if(data.ROW){
											evt_global_dataRows = data.ROW;
									}
					
									if(data.COL){
											evt_global_Column = data.COL;
									}
									
									evt_previewDrawChart();
								} else {
									alert('Error loading the data. Try again');
								}
							} else {
								alert('Error loading data try agin');
							}
						});
					},'json').error(function() { 
						jQuery(evt_current).next('div').fadeTo('fast', 0.0, function() {
							jQuery(evt_current).fadeTo('fast', 1.0);
						});
						alert("Error No data found"); 
					});	
				});
			});
		}
	});
	
	// Open new windows preview 
	jQuery("#evt_select_image_preview_manager").click(function() {
		if(evt_preview_new_window){
			evt_popup.focus();
		} else {
			evt_popup = window.open(EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/sec_window.php',999 ,'toolbar=0,scrollbars=0,location=0,statusbar=0,menubar=0,resizable=0,width=100,height=100,left = 300,top = 300');
			evt_popup.onload = function() { 
				evt_preview_new_window = true;
				evt_previewDrawChart();
				evt_popup.onunload =  function () {
                	evt_previewDrawChart();
                	evt_preview_new_window = false;
            	};
			};
		}
	});

	// Update button
	jQuery("#evt_select_image_preview").click(function() {
		evt_previewDrawChart();
	});
	
	// Changes of title activate
	$('#title').change(function() {
  		evt_previewDrawChart();
	});
	
	var google_analytics_dates = jQuery( "#evt_analytics_date_from, #evt_analytics_date_to" ).datepicker({
			defaultDate: "+1w",
			changeMonth: true,
			dateFormat: 'yy-mm-dd',
			numberOfMonths: 1,
			onSelect: function( selectedDate ) {
				var option = this.id == "evt_analytics_date_from" ? "minDate" : "maxDate",
					instance = $( this ).data( "datepicker" ),
					date = $.datepicker.parseDate(
						instance.settings.dateFormat ||
						$.datepicker._defaults.dateFormat,
						selectedDate, instance.settings );
				google_analytics_dates.not( this ).datepicker( "option", option, date );
		}	
	});
	
	// change different input types
	jQuery("#evt_loading_data input:radio").click(function() {
		if(jQuery(this).val() == 0){
			_url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/load_manualt_data.php';
			jQuery.post(_url,{post_id:post_id},function(data){
				if(data){
					if(data.R == 'OK'){
						if(data.ROW){
							evt_global_dataRows = data.ROW;
						}
					
						if(data.COL){
							evt_global_Column = data.COL;
						}
								
						evt_create_table();
								
					}
				}
			},'json');
		}
	
		for(var i=0;i<4;i++){
			if(i == jQuery(this).val()){
				jQuery("#evt_loading_data"+i).show('fast');
			} else {
				jQuery("#evt_loading_data"+i).hide('fast');
			}
		}
	});
});

// check if this functions metabox
function check_and_remove_meta_boxes(tmp_value){
	if(tmp_value != null && (tmp_value.substr(0,4) == 'evt-' || tmp_value == 'submitdiv')){
		return true;
	} else {
		return false;
	}
}

// check if this functions metabox
function check_and_remove_meta_boxes_tools(tmp_value,check_data){
	if(tmp_value != null && tmp_value.substr(0,23) == 'evt-visualization-tool-'){
		if(tmp_value.substr(23) == check_data+'-meta'){
			return 'true';
		} else {
			return 'false';
		}
	} else {
		return '';
	}
}

// Check file type
function evt_check_filetype(filename){
	return (/[.]/.exec(filename)) ? /[^.]+$/.exec(filename) : undefined;
}

//resizes one two column
function evt_resize_metaboxes() {
	if(jQuery('#evt_data_set').width() > 740){
 		if(evt_save_resize_value != 1){
 			jQuery('.evt_post_div_col').each(function(index) {
  				jQuery(this).animate({
    				width: "49%"
  				}, 500 );
  			});
 		}
 		evt_save_resize_value = 1;	
 	} else {
 		if(evt_save_resize_value != 2){
  			jQuery('.evt_post_div_col').animate({
    			width: "100%"
  			}, 500 );
 		}
 		evt_save_resize_value = 2;
 	};
}


//Start loading data
function evt_getData(get_object){
	jQuery(document).ready(function($){
	
	
		jQuery('#advanced-sortables,#side-sortables,#normal-sortables').children().each(function(i,o){
			var temp_check = check_and_remove_meta_boxes_tools(jQuery(this).attr('id'),jQuery(get_object).val());
			
			
			if(temp_check == 'true'){
				jQuery(this).show();
			} else if(temp_check == 'false'){
				jQuery(this).hide();
			}
		});

		if(jQuery(get_object).val() != ''){
		
			jQuery('#evt_data_set').fadeTo('fast', 0.0, function() {
				jQuery('#evt_data_set').html('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'images/loader.gif">');
				jQuery('#'+char_div).html('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'images/loader.gif">');
				
				evt_global_dataRows = [];
				evt_global_Column = [];
				jQuery('#evt_data_set').fadeTo('fast', 1.0, function() {
					_url = EASY_VISUALIZATION_TOOLS_CHART_URL+'frames/frame.load_post_data.php';	
					var value = jQuery("#evt_loading_data input[@name=evt_type_of_loaded_data]:checked").val();
					jQuery.post(_url,{post_id:post_id,type:jQuery(get_object).val()},function(data){
					if(data.R == 'OK'){
						jQuery('#evt_data_set').fadeTo('fast', 0.0, function() {
							jQuery('#evt_data_set').html(data.DATA_SET);
							jQuery('#evt_data_set').fadeTo('fast', 1.0);
			
							evt_chart_type = data.CHART_TYPE; 
							evt_chart_core = data.CHART_CORE;
							
							evt_call_js_file = data.CALLJSFILE;
							evt_call_js_func = data.CALLJSFUNC;
							evt_call_php_file = data.CALLPHPFILE;
							evt_call_php_func = data.CALLPHPFUNC;
								

							evt_global_test_dataRows = data.TEST_ROW; 
							evt_global_test_Column = data.TEST_COL;	
								
							jQuery('#evt_hidden_packages').val(data.CHART_CORE)
							activate_farbtastic();
							evt_save_resize_value = 0;
							evt_resize_metaboxes();
							evt_getData_load(get_object);
						});
					} else {
						jQuery('#evt_data_set').fadeTo('fast', 0.0, function() {
							jQuery('#evt_data_set').html(' ');
							jQuery('#'+char_div).html(no_graph);				
						});
						alert(data.MSG);
					}

				},'json');	
				});
			});
		} else { 
			jQuery('#evt_data_set').fadeTo('fast', 0.0, function() {
				jQuery('#evt_data_set').html(' ');				
			});
		}
	});
}


function evt_getData_load(get_object){
var value = jQuery("#evt_loading_data input[@name=evt_type_of_loaded_data]:checked").val();
					var _url_excel;
					var _url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/excel_converter_to_data.php';
					var google_a_email = jQuery("#evt_analytics_email").val();
					var google_a_code = jQuery("#evt_analytics_code").val();					
					var google_a_profile_id = jQuery("#evt_analytics_profile_id").val();
					var google_a_metrics_show = [];
					var google_a_dimensions  = jQuery("#evt_analytics_dimensions").val();
					var google_a_dimensions_max  = jQuery("#evt_analytics_dimensions_max").val();
					var google_a_dimensions_show = jQuery("#evt_analytics_dimensions_show").val();
					var google_a_date_show = 0;
					var google_a_date_to = jQuery("#evt_analytics_date_to").val();
					var google_a_date_from = jQuery("#evt_analytics_date_from").val();
					var google_a_dimensions_show_dir = jQuery('#evt_analytics_dimensions_show_dir').val();
					var google_a_piechart = false;	
	
					if(value == 0){
						_url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/load_manualt_data.php';
					} else if(value == 1){
						_url_excel = jQuery("#evt_mediefile").val();
					} else if(value == 2){
						if(evt_check_filetype(jQuery("#evt_get_url_data").val()) == 'php'){
							_url = jQuery("#evt_get_url_data").val();
						} else {
							_url_excel = jQuery("#evt_get_url_data").val();
						}
					} else if(value == 3){
						_url = EASY_VISUALIZATION_TOOLS_CHART_URL + '/frames/get_google_analytics.php';
						jQuery(".evt_analytics_metrics_show").each(function(i,o) {
							if(jQuery(this).attr('checked')){
								google_a_metrics_show.push(jQuery(this).val()); 
							}
						})
						if(jQuery("#evt_analytics_date_show").attr('checked')){
							google_a_date_show = 1;
						}
						
						if(jQuery('#evt_flag option:selected').val() == 'BarChart' || jQuery('#evt_flag option:selected').val() == 'ColumnChart'){
							google_a_piechart = true;
						}
					}

					jQuery.post(_url,{_url_excel:_url_excel,post_id:post_id,evt_analytics_email:google_a_email,evt_analytics_code:google_a_code,evt_analytics_profile_id:google_a_profile_id,evt_analytics_metrics_show:google_a_metrics_show,evt_analytics_dimensions:google_a_dimensions,evt_analytics_dimensions_show:google_a_dimensions_show,evt_analytics_date_show:google_a_date_show,evt_analytics_date_to:google_a_date_to,evt_analytics_date_from:google_a_date_from,evt_analytics_dimensions_show_dir:google_a_dimensions_show_dir,evt_analytics_dimensions_max:google_a_dimensions_max,evt_analytics_piechart:google_a_piechart},function(data){
						if(data){
						
							if(value == 0){
								if(evt_manaul_change== false){
									if(data.R == 'OK'){
										if(data.ROW){
											evt_global_dataRows = data.ROW;
											evt_manaul_change=true;
										}
					
										if(data.COL){
											evt_global_Column = data.COL;
										}	
									}
								}	
								
							} else {
								if(data.R == 'OK'){
									if(data.ROW){
										evt_global_dataRows = data.ROW;
										evt_manaul_change=true;
									}
					
									if(data.COL){
										evt_global_Column = data.COL;
									}	
								}
							}	
							
						}
						evt_create_table(true);
						evt_previewDrawChart();
						
					},'json').error(function() { alert("Error No data found"); })		
}



function evt_previewDrawChart(){
	jQuery(document).ready(function($){
		if(document.getElementById(char_div)){
			
			if(typeof( evt_google_list ) != 'undefined'){
				evt_google_list = '';
				evt_google_list = [];
			}

			if(evt_global_Column){
				dataColumn = evt_global_Column;
			}
			if(evt_global_dataRows){
				dataRows = evt_global_dataRows;
			}
			evt_chartSettings = new Object();
		
			jQuery('#evt_data_set input[type=radio]:checked').each(function(i,o){
				if(jQuery(this).attr('name') && jQuery(this).val()){
					evt_change_string_to_object_by_dot(jQuery(this).attr('name'),jQuery(this).val());
				}
			});	
			
			jQuery('#evt_data_set input[type=checkbox]:checked').each(function(i,o){
				if(jQuery(this).attr('name') && jQuery(this).val()){
					evt_change_string_to_object_by_dot(jQuery(this).attr('name'),jQuery(this).val());
				}
			});	
		
			jQuery('#evt_data_set input[type=text]').each(function(i,o){
				if(jQuery(this).attr('name') && jQuery(this).val() && jQuery(this).val() != '#'){
					if(jQuery(this).attr('name') == 'evt_backgroundColor'){
						if(typeof(evt_chartSettings['backgroundColor']) !== 'undefined' && typeof(evt_chartSettings['backgroundColor']['fill']) !== 'undefined'){}else{
							evt_change_string_to_object_by_dot(jQuery(this).attr('name')+'__fill',jQuery(this).val());
						}
					} else {
					evt_change_string_to_object_by_dot(jQuery(this).attr('name'),jQuery(this).val());
					}
				}
			});	
		
			jQuery('#evt_data_set select').each(function(i,o){
				if(jQuery(this).attr('name') && jQuery(this).val()){
					evt_change_string_to_object_by_dot(jQuery(this).attr('name'),jQuery(this).val());
				}
			});	
		
			jQuery('#evt_data_set textarea').each(function(i,o){
				if(jQuery(this).attr('name') && jQuery(this).val()){
					evt_change_string_to_object_by_dot(jQuery(this).attr('name'),jQuery(this).val());
				}
			});	
			
			if(!evt_chartSettings['width']){
				evt_chartSettings['width'] = 500;
			}
			if(!evt_chartSettings['height']){
				evt_chartSettings['height'] = 300;
			}
			if(evt_chartSettings['show_title']){		
				evt_chartSettings['title'] = jQuery('#title').val();
			}
			
			
			jQuery('#evt_hidden_settings').val(encodeURI(JSON.stringify(evt_chartSettings, null, 2)));
			
			if(evt_call_js_func != ''){
				window[evt_call_js_func](evt_chart_core,evt_chart_type,char_div,dataColumn,dataRows,evt_chartSettings,'true');
			} else {

				jQuery.post(evt_call_php_file,{COL:dataColumn,ROW:dataRows,SETTINGS:evt_chartSettings},function(data){
					var evt_preview_text1 = 'The chart is show in a new windows. Close the windows to show chart here';
					var evt_preview_text2 = '';
					
					if(data && data.PREV){	
						evt_preview_text2 = data.PREV;
					} else {
						evt_preview_text1 = data.MSG;
						evt_preview_text2 = data.MSG;
					}
						
					if(typeof( evt_popup ) != 'undefined' && evt_popup.document){
						evt_popup.document.getElementById('preview').innerHTML = evt_preview_text2;
						document.getElementById(char_div).innerHTML = evt_preview_text1;
						document.getElementById(char_div).style.width = '100%';
						document.getElementById(char_div).style.height = '30px';
						evt_popup.window.resizeTo(400,400)
					} else {
						document.getElementById(char_div).innerHTML = evt_preview_text2;
						document.getElementById(char_div).style.width = '';
						document.getElementById(char_div).style.height = '';
					}
				},'json');
			}
		}
	});
}


// string settings tools -----------------------------------------------------
// clear up name
function clearUp_name_data(_tmp_name){
	var tmp_name;
	tmp_name = _tmp_name.replace('evt_','');
	tmp_name = tmp_name.replace(/__/g,'.');
	
	return tmp_name;
}

//check value
function clearUp_value_data(tmp_value){
	return isnumber_data(tmp_value);
}

// check if number
function isnumber_data(tmp_value){
	if(isNaN(tmp_value)){
		if(tmp_value.split('[').length > 1){
			return evt_string_to_array_value(tmp_value);
		} else if(tmp_value.split('{').length > 1){
			return evt_string_to_object_value(tmp_value);
		} else if(tmp_value == "true") {	
			return true;
		} else if(tmp_value == "false") {	
			return false;	
		} else {
			return tmp_value;
		}
	} else {
		return parseFloat(tmp_value);
	}
}

// create object from string
function evt_change_string_to_object_by_dot(_tmp_name,_tmp_val){
	var tmp_name = clearUp_name_data(_tmp_name);
	var tmp_name_array = tmp_name.split('.');
	
	if(tmp_name_array.length == 2){
		if(!evt_chartSettings[tmp_name_array[0]]){
			evt_chartSettings[tmp_name_array[0]] = new Object();
		}
		evt_chartSettings[tmp_name_array[0]][tmp_name_array[1]] = clearUp_value_data(_tmp_val);
	} else if(tmp_name_array.length == 3){
		if(!evt_chartSettings[tmp_name_array[0]]){
			evt_chartSettings[tmp_name_array[0]] = new Object();
		}
		
		if(!evt_chartSettings[tmp_name_array[0]][tmp_name_array[1]]){
			evt_chartSettings[tmp_name_array[0]][tmp_name_array[1]] = new Object();
		}		
		
		evt_chartSettings[tmp_name_array[0]][tmp_name_array[1]][tmp_name_array[2]] = clearUp_value_data(_tmp_val);
	} else {
		if(tmp_name == 'region'){
			evt_chartSettings[tmp_name_array[0]] = _tmp_val;
		} else {
			evt_chartSettings[tmp_name_array[0]] = clearUp_value_data(_tmp_val);
		}
		
	}
}
// string to array
function evt_string_to_array_value(_tmp_value){
	var tmp_value_array_comma = new Array(); 
	_tmp_value = _tmp_value.replace('[','');
	_tmp_value = _tmp_value.replace(']','');
	
	var tmp_value_array = _tmp_value.split(',');
	return tmp_value_array;
}

// string to object
function evt_string_to_object_value(_tmp_value){
	var tmp_value_array_comma = new Array(); 
	var tmp_value_array = _tmp_value.split(',');
	var temp_object = new Object();
	var tmp_string = '';
	var first_time = true;
	var tmp_begin_object = false;
	var tmp_end_object = false;
	
	var array_level = new Array();

	for (x in tmp_value_array)
	{
		tmp_string = '';
		tmp_string = tmp_value_array[x];
		
		tmp_begin_object = false;
		tmp_end_object = false;
		
		for (i=0;i<=tmp_string.length ;i++)
		{
			if(tmp_string.charAt(i) == '{'){
				if(!tmp_begin_object){
					tmp_begin_object = true
				} else {
					first_time = false;
				}
			}
		
			if(tmp_string.charAt(i) == '}'){
				tmp_end_object = true
			}
		}
		
		tmp_string = tmp_string.replace('}','');
		tmp_string = tmp_string.replace('{','');
		
		tmp_value_array_comma = tmp_string.split(':');
		
		if(tmp_begin_object && !first_time){
			array_level.push(tmp_value_array_comma[0]);
			
			tmp_value_array_comma[0] = tmp_value_array_comma[1];
			tmp_value_array_comma[1] = tmp_value_array_comma[2];
			
		}
		first_time = false;
		

		tmp_value_array_comma[0] = tmp_value_array_comma[0].replace('{','');
		tmp_value_array_comma[1] = tmp_value_array_comma[1].replace('}','');		
		
		switch(array_level.length)
		{
			case 1:
				if(!temp_object[array_level[0]]){
  					temp_object[array_level[0]] = new Object();
  				}
  					
  				temp_object[array_level[0]][tmp_value_array_comma[0]] = tmp_value_array_comma[1];
  				break;
			case 2:
				if(!temp_object[array_level[0]][array_level[1]]){
  					temp_object[array_level[0]][array_level[1]] = new Object();
  				}

  				temp_object[array_level[0]][array_level[1]][tmp_value_array_comma[0]] = tmp_value_array_comma[1];
  				break;
			case 3:
				if(!temp_object[array_level[0]][array_level[1]][array_level[2]])
  					temp_object[array_level[0]][array_level[1]][array_level[2]] = new Object();
  					
  				temp_object[array_level[0]][array_level[1]][array_level[2]][tmp_value_array_comma[0]] = tmp_value_array_comma[1];			
  				break;	
			case 4:
				if(!temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]])
  					temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]] = new Object();
  					
  				temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]][tmp_value_array_comma[0]] = tmp_value_array_comma[1];			
  				break;				
			case 5:
				if(temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]][array_level[4]])
  					temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]][array_level[4]] = new object(); 
  					
  				temp_object[array_level[0]][array_level[1]][array_level[2]][array_level[3]][array_level[4]][tmp_value_array_comma[0]] = tmp_value_array_comma[1];			
  				break;		
			default:
  				temp_object[tmp_value_array_comma[0]] = tmp_value_array_comma[1];
  				break;	
		}	
		
		if(tmp_end_object){
			array_level.pop();
		}
	}
	return temp_object;
}


// aktivste color wheel
function activate_farbtastic(){
	jQuery(document).ready(function($){
		$('.pop-farbtastic').each(function(i,o){
			$(this).farbtastic($(this).attr('rel')).hide();
		});	
		$('.evt_post_color').click(function(e){
			var helper = $(this).parent().find('.pop-farbtastic');
			if(helper.is(':visible')){
				helper.slideUp();
				$(this).addClass('show-colorpicker').removeClass('hide-colorpicker');
				evt_previewDrawChart();
			}else{
				helper.slideDown();
				$(this).addClass('hide-colorpicker').removeClass('show-colorpicker');
			}
		});
		
		$('.evt_post_color').mousedown(function(e){jQuery(this).parent().find('input').trigger('focus');});
	});
}

//check numbers
function numbersonly(myfield, e, dec)
{
	var key;
	var keychar;

	if (window.event)
  		key = window.event.keyCode;
	else if (e)
   		key = e.which;
	else
   		return true;
	keychar = String.fromCharCode(key);

	// control keys
	if ((key==null) || (key==0) || (key==8) || 
    	(key==9) || (key==13) || (key==27) )
   		return true;

	// numbers
	else if (((".-0123456789").indexOf(keychar) > -1))
   		return true;

	// decimal point jump
	else if (dec && (keychar == "."))
   	{
   		myfield.form.elements[dec].focus();
   		return false;
   	}
	else
   		return false;
}

// fade ud help
function evt_hide_help(evt_object){
	jQuery(document).ready(function($){
		if(evt_timer_chekker){
			clearTimeout(evt_timer_chekker);
		}
		
		jQuery('#referent_pointer_'+jQuery(evt_object).attr('name')).parent().parent().fadeTo('slow', 0 , function(){
			jQuery(this).hide();
		});
	});
}

// fade in help
function evt_activate_help(evt_object,evt_title,evt_txt){
	jQuery(document).ready(function($){
		var content = '';
		if(evt_txt && evt_title){
			content += '<span class="evt_help_h3">'+evt_title+'</span>';
			content += '<p>'+evt_txt+'</p><div id="referent_pointer_'+jQuery(evt_object).attr('name')+'" style="display:none"></div>';
			$('.wp-pointer').fadeTo('slow', 0).hide();
			evt_timer_chekker = setTimeout(function() {
           		$(evt_object).pointer({
   			    	content: content,
        			position: {
        				edge:'left',
						my: 'left top',
						at: 'right top',
						offset: '1 -55px'
        			}
      			}).pointer('open');
      			
				jQuery('#referent_pointer_'+jQuery(evt_object).attr('name')).parent().parent().css({ opacity: 0 });
      			jQuery('.wp-pointer-buttons').hide();
      			jQuery('.wp-pointer-arrow').hide();
      			
      			jQuery('.wp-pointer-arrow').css({ 'top': '66px' });
      			jQuery('#referent_pointer_'+jQuery(evt_object).attr('name')).parent().parent().fadeTo('slow', 1);
    		},300);
		}
	});
}


// table controles ---------------------------------------
function evt_create_table(first_aktivated){
	jQuery(document).ready(function($){
		var evt_col_string = '';
		var evt_table = '<table cellpadding="0" cellspacing="0" border="0" class="display" id="evt_manual_table"><thead><tr>';
		var value = jQuery("#evt_loading_data input[@name=evt_type_of_loaded_data]:checked").val();
		if(evt_manaul_change == 'KeyOverWrite'){
		
		} else if(evt_manaul_change == false){
			evt_global_dataRows =  evt_global_test_dataRows;
			evt_global_Column = evt_global_test_Column;
		} else {
			if(value == 0){
				if(typeof( oTable ) != 'undefined'){
					evt_global_dataRows = oTable.fnGetData();
				}
			}
		}
		
		if(value == 0){
			evt_empty_array = [];
			evt_empty_array = new Array();
		
			if(jQuery("#evt_manualt_col").val() && evt_manaul_change == true){
				evt_global_Column = [];
				evt_global_Column = new Array();
				var evt_global_Column_tmp = jQuery("#evt_manualt_col").val().split(';');
				if(evt_global_Column_tmp){
					for (var column_key = 0; column_key<evt_global_Column_tmp.length ;column_key++)
  					{
  						if(evt_col_string){
  							evt_col_string += ';'
  						}
  					
  						evt_empty_array[column_key] = ' ';
  						evt_global_Column[column_key] = new Array('',evt_global_Column_tmp[column_key]);
  						evt_col_string += evt_global_Column_tmp[column_key];
  						evt_table += '<th>'+evt_global_Column_tmp[column_key]+'</th>';
  					}
  				}
			} else {
				for (column_key in evt_global_Column)
  				{
  					if(evt_col_string){
  						evt_col_string += ';'
  					}
  					evt_empty_array[column_key] = ' ';
  				
  					evt_col_string += evt_global_Column[column_key][1];
  					evt_table += '<th>'+evt_global_Column[column_key][1]+'</th>';
  				}
			}
		
			evt_table += '</tr></thead><tbody>';
			if(evt_global_dataRows){
				var evt_global_dataRows_tmp = evt_global_dataRows;
				evt_global_dataRows = [];
				evt_global_dataRows = new Array();
		
				for (var row_key = 0; row_key<evt_global_dataRows_tmp.length; row_key++)
  				{
  					evt_table += '<tr>';
  					evt_global_dataRows[row_key] = new Array();
					for (var row_col_key = 0; row_col_key<evt_global_Column.length;row_col_key++)
  					{
  						if(evt_global_Column[row_col_key][0] == 'string' || evt_global_Column[row_col_key][0] == 'date' || evt_global_Column[row_col_key][0] == 'boolean' || evt_global_dataRows_tmp[row_key][row_col_key] == '' || isNaN(evt_global_dataRows_tmp[row_key][row_col_key])){
  							if(evt_global_Column[row_col_key][0] == 'string' || (evt_global_dataRows_tmp[row_key][row_col_key] != true && evt_global_dataRows_tmp[row_key][row_col_key] != false)){
  								var my_date=new Date(evt_global_dataRows_tmp[row_key][row_col_key]);
  								if(my_date != 'Invalid Date' && evt_global_Column[row_col_key][0] != 'string'){
  									evt_global_Column[row_col_key][0] = 'date';
  								} else {
  									evt_global_Column[row_col_key][0] = 'string';
  								}
  							} else {
  								evt_global_Column[row_col_key][0] = 'boolean';
  							}
  						} else {
  							evt_global_Column[row_col_key][0] = 'number';
  						}
  						
						if(evt_global_dataRows_tmp[row_key][row_col_key] != undefined){
							evt_table += '<td>'+evt_global_dataRows_tmp[row_key][row_col_key]+'</td>';
							evt_global_dataRows[row_key][row_col_key] =  evt_global_dataRows_tmp[row_key][row_col_key];
						} else {
							evt_global_dataRows[row_key][row_col_key] =  '';
							evt_table += '<td></td>';
						}
  				
  					}
  					evt_table += '</tr>';	
  				}
  			}
  				
			evt_table += '</tbody></table>';
			jQuery("#evt_manual_table_data_div").html(''); 
			jQuery("#evt_manual_table_data_div").html(evt_table);
			jQuery('#evt_hidden_rowdata').val(encodeURI(JSON.stringify(evt_global_dataRows, null, 2)));
			jQuery('#evt_hidden_collumdata').val(encodeURI(JSON.stringify(evt_global_Column, null, 2)));
	
			oTable = jQuery('#evt_manual_table').dataTable({"bJQueryUI":true,"bProcessing":true,"sPaginationType":"full_numbers","bSort": false}).makeEditable({sUpdateURL: function(value, settings){evt_manaul_change=true;return(value);}});
	
			jQuery('.dataTables_filter').remove();
			
			jQuery('#evt_manual_table_length').html('<button onClick="evt_manaul_change=true;evt_table_add_action();return false;" id="evt_btnAddRow" class="add_row">Add row</button><button onClick="evt_manaul_change=true;evt_table_delete_action();return false;" id="evt_btnDeleteRow" class="delete_row" disabled="disabled" style="margin-right: 30px;">Delete row</button><input type="text" id="evt_manualt_col" value="'+evt_col_string+'" style="width: 200px;"><button onClick="evt_manaul_change=true;evt_create_table(false);return false;" id="evt_preview_submit" style="margin-right: 30px;" class="delete_row">Save</button><button onClick="evt_manaul_change=false;evt_create_table();return false;" id="evt_btnAddRow" class="add_row">Reset to test data</button>');	
								
			if(!first_aktivated){
				evt_previewDrawChart();	
			}	
	
  			jQuery("#evt_manual_table tbody").click(function(event) {
				jQuery(oTable.fnSettings().aoData).each(function (){
					jQuery(this.nr).removeClass('row_selected');
				});
				$(event.target.parentNode).addClass('row_selected');
				jQuery("#evt_btnDeleteRow").removeAttr("disabled");
			});
		}
	});				

}

function evt_table_delete_action(){
	var anSelected = fnGetSelected( oTable );
	oTable.fnDeleteRow( anSelected[0] );
	jQuery("#evt_btnDeleteRow").attr('disabled','disabled');
	evt_create_table(false);
}

function evt_table_add_action(){
   oTable.fnAddData( evt_empty_array );
   evt_create_table(false);
}


function fnGetSelected( oTableLocal )
{
	var aReturn = new Array();
	var aTrs = oTableLocal.fnGetNodes();
	
	for ( var i=0 ; i<aTrs.length ; i++ )
	{
		if ( jQuery(aTrs[i]).hasClass('row_selected') )
		{
			aReturn.push( aTrs[i] );
		}
	}
	return aReturn;
}


function evt_add_data_list(tmp_selectede_pos,tmp_list_pos,tmp_save_pos){

	var tmp_content_data = '<li class="evt_form_list_data_item clear">';
	var dontshow_data = true;


	jQuery(tmp_selectede_pos + ' select').each(function(i,o){

		if(jQuery(this).find('option:selected').val() != ''){
			dontshow_data = false;
		}
		
		tmp_content_data += '<span id="'+jQuery(this).attr('id')+'">'+jQuery(this).attr('id')+ ': '+jQuery(this).find('option:selected').val()+'</span>';
	});
	
	tmp_content_data += '<span><a href="#" onclick="evt_remove_data_list(this,\''+tmp_list_pos+'\',\''+tmp_save_pos+'\');return false;">(remove)</a></span></li>';
	
	
	if(!dontshow_data){
		jQuery(tmp_list_pos).html(jQuery(tmp_list_pos).html()+tmp_content_data);
	} else {
		alert('Select data first');
		return false;
	}

	var temp_save = '';

	jQuery(tmp_list_pos + ' li').each(function(i,o){
		var temp_save_tmp = '';
		
		jQuery(this).find('span').each(function(i,o){
			var temp_array2 = jQuery(this).text().split(": ");
			
			if(temp_save_tmp != '' && temp_array2[1] != '' &&  temp_array2[1] != 'undefined' && temp_array2[1] != undefined){
				temp_save_tmp += ',';
			}
			
			if(temp_array2[1] != '' && temp_array2[1] != 'undefined' && temp_array2[1] != undefined){
				temp_save_tmp += jQuery(this).attr('id')+':'+temp_array2[1];
			}
		});
		
		if(temp_save != ''){
			temp_save += ',';
		}
		
		temp_save += i+':{' +temp_save_tmp +'}';
	});

	jQuery(tmp_save_pos).val('{'+temp_save+'}');
	evt_previewDrawChart();
 return false;
}

function evt_remove_data_list(tmp_this,tmp_list_pos,tmp_save_pos){

	jQuery(tmp_this).parent().parent().remove();
	
	var temp_save = '';

	jQuery(tmp_list_pos + ' li').each(function(i,o){
		var temp_save_tmp = '';
		
		jQuery(this).find('span').each(function(i,o){
			var temp_array2 = jQuery(this).text().split(": ");
			
			if(temp_save_tmp != '' && temp_array2[1] != '' &&  temp_array2[1] != 'undefined' && temp_array2[1] != undefined){
				temp_save_tmp += ',';
			}
			
			if(temp_array2[1] != '' && temp_array2[1] != 'undefined' && temp_array2[1] != undefined){
				temp_save_tmp += jQuery(this).attr('id')+':'+temp_array2[1];
			}
		});
		
		if(temp_save != ''){
			temp_save += ',';
		}
		
		temp_save += i+':{' +temp_save_tmp +'}';
	});
	if(temp_save != ''){
		jQuery(tmp_save_pos).val('{'+temp_save+'}');
	} else {
		jQuery(tmp_save_pos).val('');
	}
	evt_previewDrawChart();
	return false;
}


function evt_add_colors(tmp_selectede_pos,tmp_list_pos,tmp_save_pos){
	var newColor = jQuery(tmp_selectede_pos).val();
	
	if(newColor == '' || newColor == '#'){
		alert('Select a color first');
		return false;
	}
	
	jQuery(tmp_list_pos).html(jQuery(tmp_list_pos).html()+'<div class="clear"><div class="evt_post_colors_list_image" style="background-color: '+newColor+';"></div><span style="float:left;min-width:45px">'+newColor+'</span><div style="float:left"><a href="#" onclick="evt_remove_colors(this,\''+tmp_list_pos+'\',\''+tmp_save_pos+'\');return false;">(remove)</a></div></div>');
	
	var tmp_create_save = '';
	jQuery(tmp_list_pos + ' span').each(function(i,o){
		if(jQuery(this).html() != ''){
		
			if(tmp_create_save != ''){
				tmp_create_save += ',';
			}
		}
		tmp_create_save += jQuery(this).html();
	});

	tmp_create_save =  '['+tmp_create_save+']';
	jQuery(tmp_save_pos).val(tmp_create_save);
	


	evt_previewDrawChart();
	return false;

}

function evt_remove_colors(tmp_this,tmp_list_pos,tmp_save_pos){

	jQuery(tmp_this).parent().parent().remove();

	var tmp_create_save = '';
	jQuery(tmp_list_pos + ' span').each(function(i,o){
		if(jQuery(this).html() != ''){
			if(tmp_create_save != ''){
				tmp_create_save += ',';
			}
		}
		tmp_create_save += jQuery(this).html();
	});
	
	if(tmp_create_save != ''){
		tmp_create_save =  '['+tmp_create_save+']';
	}
	
	jQuery(tmp_save_pos).val(tmp_create_save);
	evt_previewDrawChart();
	return false;

}

function evt_dubblicate_object(tmp_this,tmp_id){
	var _url = EASY_VISUALIZATION_TOOLS_CHART_URL + 'frames/duplicate_post.php';

	var imagetmp = jQuery(tmp_this).parent().html(); 

	jQuery(tmp_this).parent().html('<img src="'+EASY_VISUALIZATION_TOOLS_CHART_URL+'images/wpspin_light.gif">'); 
	
	jQuery.post(_url,{post_id:tmp_id},function(data){
		alert(data.MSG);
		
		if(data.R == 'OK'){
			location.reload(true);
		}
		
		return false;								
	},'json').error(function() { alert("Error No data found");return false; })	
	return false;
}



