<?php 
ob_start();
Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
$content = ob_get_contents();
ob_end_clean();

wp_register_script( 'googlechar', 'https://www.google.com/jsapi?key='.$evt_google_key);
wp_enqueue_script( 'googlechar' ); 

echo '<link rel="stylesheet" type="text/css" href="'.EASY_VISUALIZATION_TOOLS_CHART_URL.'css/flip.css" />';

echo '<div id="preview"></div>';
?>