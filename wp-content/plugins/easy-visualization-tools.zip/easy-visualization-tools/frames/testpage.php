<?php

$COL_tmp[] = array('string','Computers');
$COL_tmp[] = array('number','Count');
$COL_tmp[] = array('boolean','Windows');


$ROW_tmp[] = array('Acer',43,true);
$ROW_tmp[] = array('Apple',4342,false);
$ROW_tmp[] = array('Printer',2,true);
$ROW_tmp[] = array('Mouse',232,false);

$response = array(
    'R'	=> 'OK',
    'ROW' => $ROW_tmp,
    'COL' => $COL_tmp
);
	
die(json_encode($response));
	
?>