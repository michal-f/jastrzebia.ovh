<?php
ob_start();
Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'inc/formsettings.php');

$content = ob_get_contents();
ob_end_clean();
$content_data = "";
global $wpdb,$evt_class_run;

function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','evt'));
}



if(isset($_POST["loading"])){
	$_POST["evt_analytics_email"] = get_post_meta($_POST["post_id"], "evt_analytics_email",true);
	$_POST["evt_analytics_code"] = get_post_meta($_POST["post_id"], "evt_analytics_code",true);
  	$_POST["evt_analytics_profile_id"] = get_post_meta($_POST["post_id"], "evt_analytics_profile_id",true);
  	$_POST["evt_analytics_dimensions"] = get_post_meta($_POST["post_id"], "evt_analytics_dimensions",true);
  	$_POST["evt_analytics_dimensions_max"] = get_post_meta($_POST["post_id"], "evt_analytics_dimensions_max",true);
  	$_POST["evt_analytics_dimensions_show"] = get_post_meta($_POST["post_id"], "evt_analytics_dimensions_show",true);
  	$_POST["evt_analytics_date_show"] = get_post_meta($_POST["post_id"], "evt_analytics_date_show",true);
  	$_POST["evt_analytics_date_to"] = get_post_meta($_POST["post_id"], "evt_analytics_date_to",true);
  	$_POST["evt_analytics_date_from"] = get_post_meta($_POST["post_id"], "evt_analytics_date_from",true);
  	$_POST["evt_analytics_metrics_show"] = get_post_meta($_POST["post_id"], "evt_analytics_metrics_show",true);
  	$_POST["evt_analytics_dimensions_show_dir"] = get_post_meta($_POST["post_id"], "evt_analytics_dimensions_show_dir",true);
  	$_POST["evt_analytics_piechart"] = get_post_meta($_POST["post_id"], "evt_flag",true);
  	
  	if($_POST["evt_analytics_piechart"] == 'BarChart' || $_POST["evt_analytics_piechart"] == 'ColumnChart'){
  		$_POST["evt_analytics_piechart"] = true;
  	} else {
  	  	$_POST["evt_analytics_piechart"] = false;
  	}
  	
} else {
	if(empty($_POST['evt_analytics_email'])){
		send_error_die(__('No email are received','evt'));
	}

	if(empty($_POST['evt_analytics_code'])){
		send_error_die(__('No code are received','evt'));
	}

	if(empty($_POST['evt_analytics_profile_id'])){
		send_error_die(__('No property id are received','evt'));
	}
}



$msg = $evt_class_run->get_google_analytics($_POST['evt_analytics_email'],$_POST['evt_analytics_code'],$_POST['evt_analytics_profile_id'],$_POST['evt_analytics_dimensions'],$_POST['evt_analytics_dimensions_max'],$_POST['evt_analytics_dimensions_show'],$_POST['evt_analytics_dimensions_show_dir'],$_POST['evt_analytics_metrics_show'],$_POST['evt_analytics_date_show'],$_POST['evt_analytics_date_from'],$_POST['evt_analytics_date_to'],$_POST["evt_analytics_piechart"]);
 
$response = array(
    'R'	=> 'OK',
    'COL' => $msg['COL'],
    'ROW' => $msg['ROW'],
    'TITLE' => $msg['TITLE'],
    'MSG' => $msg
);

die(json_encode($response));
?>