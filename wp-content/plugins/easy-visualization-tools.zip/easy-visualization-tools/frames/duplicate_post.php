<?php
ob_start();
Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'inc/formsettings.php');

$content = ob_get_contents();
ob_end_clean();
$content_data = "";
global $wpdb,$evt_class_run;

function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','evt'));
}

if(!isset($_POST['post_id'])){
	send_error_die(__('No post id are received','evt'));
}

$msg = $evt_class_run->duplicate_post_create_duplicate($_POST['post_id']);
 
$response = array(
    'R'	=> 'OK',
    'MSG' => $msg
);

die(json_encode($response));
?>