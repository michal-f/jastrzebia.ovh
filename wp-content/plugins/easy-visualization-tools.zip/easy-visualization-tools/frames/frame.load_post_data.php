<?php
ob_start();
Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'inc/formsettings.php');

$content = ob_get_contents();
ob_end_clean();
$content_data = "";
global $wpdb,$easy_visualization_tools_display;

function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','evt'));
}

if(!isset($_POST['post_id'])){
	send_error_die(__('No post id are received','evt'));
}

if(!isset($_POST['type'])){
	send_error_die(__('No types are received','evt'));
}

$post_data_set = '';
$post_custom = '';
$post_custom_data = '';
$post_option_data = '';
$post_eximg_data = '';


$call_js_file = '';
$call_js_func= '';
$call_php_file = '';
$call_php_func = '';

if(!empty($easy_visualization_tools_display)){
	$easy_visualization_tools_display_check = $easy_visualization_tools_display[$_POST['type']];
	if(!empty($easy_visualization_tools_display_check) and $easy_visualization_tools_display_check['type'] == $_POST['type']){
		if(!empty($easy_visualization_tools_display_check['call_js_file'])){
			$call_js_file = $easy_visualization_tools_display_check['call_js_file'];
		}
		if(!empty($easy_visualization_tools_display_check['call_js_func'])){
			$call_js_func = $easy_visualization_tools_display_check['call_js_func'];
		}
		
		if(!empty($easy_visualization_tools_display_check['call_php_file'])){
			$call_php_file = $easy_visualization_tools_display_check['call_php_file'];
		}
			
		if(!empty($easy_visualization_tools_display_check['call_php_func'])){
			$call_php_func = $easy_visualization_tools_display_check['call_php_func'];
		}
			
		if(!empty($easy_visualization_tools_display_check['option'])){
			$post_option_data = $easy_visualization_tools_display_check['option'];
		}
		if(!empty($easy_visualization_tools_display_check['packages'])){
			$post_packages = $easy_visualization_tools_display_check['packages'];
		}
			
		if(!empty($easy_visualization_tools_display_check['test_col'])){
			$test_col = $easy_visualization_tools_display_check['test_col'];
		}
			
		if(!empty($easy_visualization_tools_display_check['test_row'])){
			$test_row = $easy_visualization_tools_display_check['test_row'];
		}	
	}
}





$post_custom = get_post_custom($_POST['post_id']);
$post_custom = json_decode($post_custom['evt_data'][0],true);
if(!empty($post_option_data)){
	foreach($post_option_data as $key => $tmps){
		$tmp_data_save1 = '';
		if($tmps['type'] == 'latlng'){
			$tmp_data_save1 = $post_custom[$tmps['name'].'_lat'];
			$tmp_data_save2 = $post_custom[$tmps['name'].'_lng'];
		} else {
			$tmp_data_save1 = $post_custom[$tmps['name']];
	
		}
		$post_data_set .= evt_create_form($tmps,$key,$tmp_data_save1,$tmp_data_save2);
	}
}

if(!empty($post_custom["evt_flag"])){
  	$custom_flag = $post_custom["evt_flag"][0];
} else {
  	$custom_flag = '';
}

 
$response = array(
    'R'	=> 'OK',
    'DATA_SET' => $post_data_set,
    'CHART_TYPE' => $_POST['type'],
    'CHART_CORE' => $post_packages,
    'TEST_ROW' => $test_row, 
    'TEST_COL' => $test_col,
    'CALLJSFILE' =>$call_js_file,
    'CALLJSFUNC' => $call_js_func,
    'CALLPHPFILE' => $call_php_file,
    'CALLPHPFUNC' => $call_php_func
);

die(json_encode($response));
?>