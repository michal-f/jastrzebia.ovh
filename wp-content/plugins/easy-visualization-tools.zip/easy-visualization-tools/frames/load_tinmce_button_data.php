<?php
ob_start();

Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
$content = ob_get_contents();
ob_end_clean();



function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','act'));
}

if(!isset($_POST['post_id']) && $_POST['post_id']>0){
	send_error_die(__('No post id pleas contact support.','act'));
}

$comments = get_post_meta($_POST['post_id'], 'evt_comments', true);
$evt_flag = get_post_meta($_POST['post_id'], 'evt_flag', true);
$evt_packages = get_post_meta($_POST['post_id'], 'evt_packages', true);
$evt_rowdata = get_post_meta($_POST['post_id'], 'evt_rowdata', true);
$evt_collumdata = get_post_meta($_POST['post_id'], 'evt_collumdata', true);
$evt_settings = get_post_meta($_POST['post_id'], 'evt_settings', true);


$evt_mediefile = get_post_meta($_POST['post_id'], 'evt_mediefile', true);
$evt_get_url_data = get_post_meta($_POST['post_id'], 'evt_get_url_data', true);
$evt_type_of_loaded_data = get_post_meta($_POST['post_id'], 'evt_type_of_loaded_data', true);


$call_js_file = '';
$call_js_func= '';
$call_php_file = '';
$call_php_func = '';

if(!empty($easy_visualization_tools_display)){
	$easy_visualization_tools_display_check = $easy_visualization_tools_display[$evt_flag];
	if(!empty($easy_visualization_tools_display_check) and $easy_visualization_tools_display_check['type'] == $evt_flag){
		if(!empty($easy_visualization_tools_display_check['call_js_file'])){
			$call_js_file = $easy_visualization_tools_display_check['call_js_file'];
		}
		if(!empty($easy_visualization_tools_display_check['call_js_func'])){
			$call_js_func = $easy_visualization_tools_display_check['call_js_func'];
		}
		
		if(!empty($easy_visualization_tools_display_check['call_php_file'])){
			$call_php_file = $easy_visualization_tools_display_check['call_php_file'];
		}
			
		if(!empty($easy_visualization_tools_display_check['call_php_func'])){
			$call_php_func = $easy_visualization_tools_display_check['call_php_func'];
		}
	}
}




if(empty($comments)){
	$comments = __('No comments','act');
}

$response = array(
    'R'	=> 'OK',
    'SHORTCODE' => evt_globalt_shorcode_generator($_POST['post_id']),
    'COMMENTS' =>$comments,
    'FLAG' =>$evt_flag,
    'PACKAGES' =>$evt_packages,
    'ROW' =>$evt_rowdata,
    'COL' =>$evt_collumdata,
    'SETTINGS' => $evt_settings,
    'MEDIAFILE' => $evt_mediefile,
    'URLDATA' => $evt_get_url_data,    
    'TYPEDATA' => $evt_type_of_loaded_data ,
    'CALLJSFILE' =>$call_js_file,
    'CALLJSFUNC' => $call_js_func,
    'CALLPHPFILE' => $call_php_file,
    'CALLPHPFUNC' => $call_php_func
);

die(json_encode($response));
?>