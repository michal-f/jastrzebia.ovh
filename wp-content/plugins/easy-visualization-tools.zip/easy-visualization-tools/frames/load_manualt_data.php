<?php
ob_start();

Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
$content = ob_get_contents();
ob_end_clean();

function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','act'));
}

if(!isset($_POST['post_id']) && $_POST['post_id']>0){
	send_error_die(__('No post id pleas contact support.','act'));
}

$response = array(
    'R'	=> 'OK',
    'ROW' =>json_decode(urldecode(get_post_meta($_POST['post_id'], 'evt_rowdata', true))),
    'COL' =>$_col_data = json_decode(urldecode(get_post_meta($_POST['post_id'], 'evt_collumdata', true)))
);

die(json_encode($response));
?>