<?php
ob_start();
Header('Cache-Control: no-cache');
Header('Pragma: no-cache');
require_once('../../../../wp-load.php');
$content = ob_get_contents();
ob_end_clean();

function send_error_die($msg){
	die(json_encode(array('R'=>'ERR','MSG'=>$msg)));
}

if(!is_user_logged_in()){
	send_error_die(__('You are not logged in.','evt'));
}

$data_tmp = $evt_class_run->load_excel_data($_POST['_url_excel']);

if(is_array($data_tmp) && !empty($data_tmp)){
	$response = array(
    	'R'	=> 'OK',
    	'TITLE' => $data_tmp[0],
    	'ROW' => $data_tmp[2],
    	'COL' => $data_tmp[1]
	);
	
	die(json_encode($response));
	
} else {
	send_error_die($data_tmp);
}
?>