<?php

$get_started_url = EASY_VISUALIZATION_TOOLS_CHART_URL.'images/getstarted/';

echo '<div class="wrap evt-about-wrap">';
echo 	'<h1>'.__( 'Welcome to Easy Visualization Tools','evt').'</h1>';

echo 	'<div class="evt-about-text">'.__( 'Thank you for installing this plugin! Using Easy Visualization Tools will provide a perfect way to visualize data on your WordPress powered website' ).'</div>';

echo 	'<div class="wp-evt-badge"></div>';

echo 	'<div class="changelog">';
echo    	'<h3>'. __( 'Easy Visualization Tools for WordPress' ).'</h3>';

echo 		'<div class="feature-section images-stagger-right">';
echo			'<div class="feature-images">';
echo				'<img src="'.$get_started_url.'chart-preview.png" width="265" class="angled-right" />';
echo				'<img src="'.$get_started_url.'load-data.png" width="265" class="angled-left" />';
echo 			'</div>';
 
echo			'<div class="left-feature">';
echo				'<h4>'.__( 'Display live data on your WordPress website' ).'</h4>';
echo				'<p>'.__( 'This plugin provide you with a perfect way to visualize all kinds of different data on your website. From simple line charts to complex combo charts, the plugin provides a large number of well-designed chart types all from the Google Chart Tools API.' ).'</p>';
echo				'<p>'.__( 'Whether you choose to populate your data manually in the wp-admin or using the dynamic data option you will be able to create amazing looking charts in no time. We have also created additional add-ons, which will give you entirely new chart options and new exciting features.' ).'</p>';
echo				'<p>'._e( 'Follow these Easy Steps to Get Started.' ).'</p>';

echo				'<ol>';
echo					'<li>'.__( 'Select the <a href="/wp-admin/post-new.php?post_type=evt-tools">Add New Tools</a> menu under EVT Settnigs in the left menu.' ).'</li>';
echo					'<li>'.__( 'Enter a title and choose data source: manually, data file from media library or data from a URL. Next choose Chart Type and start configuring the settings. When done click Publish.' ).'</li>';
echo					'<li>'.__( 'Insert your new Chart Tool in Posts or Pages by clicking the "V" icon above the visual editor.' ).'</li>';
echo				'</ol>';			
			
echo				'<div class="feature-images">';
echo					'<img src="'.$get_started_url.'advanced-settings.png" width="265" class="angled-right" />';
echo				'</div>';

echo				'<h4>'.__( 'Chart Library' ).'</h4>';
echo				'<p>' .__( 'Charts are exposed as JavaScript classes. Google Chart Tools provides many chart types for you to use. Even though we have provided you with a default appearance, which is best for most situations, you can easily customize a chart to fit the look and feel of your website. We have provided you with an extensive amount of features to customize, but we have tried our best to keep it user friendly.').'</p>';
echo				'<p>'.__('Charts are highly interactive and expose events that enable you to connect them to create complex dashboards or other experiences integraed with your website. Charts are rendered using HTML5/SVG technology to provide cross-browser compatibility (including VML for older versions of Internet Explorer) and cross platform portability to iPhones, iPads and Android. No need for installing plugins.' ).'</p>';
echo			'</div>';
echo		'</div>';
echo	'</div>';






echo	'<div class="changelog">';
echo		'<h3>'.__( 'Some of the features' ).'</h3>';

echo		'<div class="feature-section text-features">';
echo			'<h4>'.__( 'Rich Gallery' ).'</h4>';
echo			'<p>'. __( 'Choose from a variety of charts. From simple line charts to complex combo charts. Choose between Area Charts, Annotated Time Line Charts, Bar Charts, Column Charts, Combo Charts, Gauge Charts, Geo Charts, Intensity Maps, Line Charts, Pie Chats, Real Maps, Scatter Maps and Table Charts.' ).'</p>';
echo		'<div>';

echo			'<h4>'.__( 'Customizable'  ).'</h4>';
echo			'<p>'.__( 'Make the charts your own. Configure an extensive set of options to perfectly match the look and feel of your website. We have made it very easy to tweak all available settings.').'</p>';
echo		'</div>';
echo 	'</div>';




echo	'<div class="feature-section screenshot-features">';
echo		'<div class="angled-left">';
echo			'<img src="'.$get_started_url.'rich-gallery.png" />';
echo			'<h4>'. __( 'HTML5/SVG' ).'</h4>';
echo			'<p>' .__( 'Cross-browser compatibility (adopting VML for older version of IE) and croos platform portability to iOS (iPhone and iPad) and new Android releases. There is no need for plugins!' ).'</p>';
echo		'</div>';
echo		'<div class="angled-right">';
echo			'<img src="'.$get_started_url.'insert-tool.png" />';
echo			'<h4>'.__( 'Dynamic Data' ).'</h4>';
echo			'<p>'. __( 'Connect to your data in real time using our build in support for external data files or data files in your Media Library. We have also inclued samples that show you how to use it.' ).'</p>';
echo			'<h4>'.__( 'Add new features with add-ons' ).'</h4>';
echo			'<p>'. __( 'Install our Flip Numbers and Google Maps add-on for the plugin and get new cool features.' ).'</p>';

echo		'</div>';
echo	'</div>';
echo '</div>';


echo '<div class="return-to-dashboard">';

if ( current_user_can( 'update_core' ) && isset( $_GET['updated'] ) ){
	echo '<a href="'.esc_url( network_admin_url( 'update-core.php' ) ).'">';
		echo (is_multisite() ? _e( 'Return to Updates' ) : _e( 'Return to Dashboard &rarr; Updates' ));
	echo '</a> |';


}
	echo '<a href="<?php echo esc_url( admin_url() ); ?>">'._e( 'Go to Dashboard &rarr; Home' ).'</a>';
	echo '</div>';     
echo '</div>';   
 
?>