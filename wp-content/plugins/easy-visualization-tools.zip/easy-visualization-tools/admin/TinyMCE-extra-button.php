<?php
class evt_tinymce_extra_button {
	var $post;
	
	function evt_tinymce_extra_button ($args=array()){
		add_action("admin_head-post.php",array(&$this,'insert_tool_head'));
		add_action("admin_head-post-new.php",array(&$this,'insert_tool_head'));				
		add_action('media_buttons_context',array(&$this,'media_buttons_context'));
		//add_action('wp_ajax_mce_list_fields', array(&$this,'mce_list_fields'));
	}
	
	function insert_tool_head(){

    		
    	// add creation of statistics
		wp_register_style( 'evt-insert-tool', EASY_VISUALIZATION_TOOLS_CHART_URL.'css/insert_tool.css', array(),'1.0.0');
		wp_print_styles('evt-insert-tool');
		wp_register_script( 'evt-insert-tool', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/insert_tool.js', array(),'1.0.0');
		wp_print_scripts('evt-insert-tool');
 		echo '<script>
 				var EASY_VISUALIZATION_TOOLS_CHART_URL = "'.EASY_VISUALIZATION_TOOLS_CHART_URL.'";
 		</script> '; 		
		
		add_action('admin_footer',array(&$this,'shortcode_dialog'),1);
	}
	
	function shortcode_dialog(){
		$args = array( 'post_type' => 'evt-tools', 'numberposts' => -1); 
		$evt_stalastics = get_posts( $args );
?>
<div id="evt-insert-tool" class="evt-dialog-cont">
	<div class="evt-dialog-overlay"></div>
	<div class="evt-dialog">
		<div class="evt-dialog-head">
			<div class="evt-dialog-head-text"><?php _e("Add Easy Visualization Tools", 'evt')?></div>
			<div class="evt-close-icon">
				<a class="evt-close-icon-a" title="Close" href="javascript:void(0);" alt="Close"><img src="<?php echo EASY_VISUALIZATION_TOOLS_CHART_URL?>images/tb-close.png" /></a>			
			</div>
		</div>	
		<div class="evt-dialog-body" style="width:400px;">
        	<div id="insert_evt">
				<label class="evt-mce-label"><?php _e("Settings", 'evt')?></label>
				<div class="evt-mce-input">
					<select style="width:350px" id="evt_chart_selected">
						<option value=""><?php _e("-- Select Tool to Insert --", 'evt')?></option>
						<?php 
						if ($evt_stalastics) {
							foreach ( $evt_stalastics as $post ) {
								if(empty($post->post_title))
									$post->post_title = __("(no title)", 'evt');	
								 		
								echo '<option value="'.$post->ID.'">'.$post->post_title.'</option>';
							}
						}
						?>
					</select>
				</div> 
			</div>
			<div id="data_loaded_evt" style="display:none">
				<label class="evt-mce-label"><?php _e("CSS Class", 'evt')?></label>
				<div class="evt-mce-input"><input style="width:350px;" type="text" id="evt_class"></div>
				<label class="evt-mce-label"><?php _e("Style", 'evt')?></label>
				<div class="evt-mce-input"><input style="width:350px;" type="text" id="evt_style"></div>

				<label class="evt-mce-label"><?php _e("CSS properties", 'evt')?></label>
				<div class="evt-mce-input" style="margin-top: 3px;">
					<label for="border">Border</label>
					<input type="text" onKeyUp="evt_input_change_value()" value="" style="width: 30px; margin-right: 10px;" name="evt_border" id="evt_border" maxlength="5">

					<label for="vspace">Vertical space</label>
					<input type="text" onKeyUp="evt_input_change_value()" value="" style="width: 30px; margin-right: 10px;" name="evt_vspace" id="evt_vspace" maxlength="5">

					<label for="hspace">Horizontal space</label>
					<input type="text" onKeyUp="evt_input_change_value()" value="" style="width: 30px; margin-right: 10px;" name="evt_hspace" id="evt_hspace" maxlength="5">
				</div>
				
				<label class="evt-mce-label"><?php _e("Alignment", 'evt')?></label>
				<div class="evt-mce-input" style="margin-top: 3px;" id="evt_radio_list">
						<input type="radio" value="alignnone" checked="checked"id="evt_alignnone" name="evt_align">
						<label class="evt-image-align-label evt-image-align-none-label" for="alignnone">None</label>
						<input type="radio" value="alignleft" id="evt_alignleft" name="evt_align">
						<label class="evt-image-align-label evt-image-align-left-label" for="alignleft">Left</label>
						<input type="radio" value="aligncenter" id="evt_aligncenter" name="evt_align">
						<label class="evt-image-align-label evt-image-align-center-label" for="aligncenter">Center</label>
						<input type="radio" value="alignright" id="evt_alignright" name="evt_align">
						<label class="evt-image-align-label evt-image-align-right-label" for="alignright">Right</label>
				</div>

				
				
				<div id="evt_shortcode" class="evt-mce-input" style="display:none;"></div>
				<label class="evt-mce-label"><?php _e("Comments", 'evt')?></label>
				<div id="evt_comments" class="evt-mce-input"></div>
				<div class="evt-mce-buttons">
						<input type="button" OnClick="javascript:insert_evt_shortcode();" class="button-primary" value="<?php _e("Insert Chart", 'evt')?>" />
				</div>
				
			</div>     
		</div>
		
		<div class="evt-dialog-body">
        	<div id="preview_evt">
        		<label class="evt-mce-label"><?php _e("Preview (lock height/width)", 'evt')?></label>
				<div id="preview_chart_evt" class="evt-mce-input"></div>
        	</div>
        </div>
	</div>
</div>
<?php	
	}
	
	
	
	
	function media_buttons_context($context){
        $out = '<a id="evt-insert-tool-trigger" href="javascript:void(0);" title="'. __("Add Easy visualization tools", 'evt').'"><img src="'.EASY_VISUALIZATION_TOOLS_CHART_URL."/images/evt.png".'" alt="'. __("Add Easy visualization tool", 'evt') . '" /></a>';
        return $context . $out;
	}
}
?>