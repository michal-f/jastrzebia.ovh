<?php

class evt_options {
	var $screen_title = 'Options';
	var $screen_menu = 'Options';    
	var $plugin_id;
	var $tdom = 'evt';
	
	function evt_options($parent_id){
		$this->plugin_id = $parent_id.'-opt';
		add_filter("pop-options_{$this->plugin_id}",array(&$this,'options'),10,1);		
	} 

    
	function options($t){
        global $wpdb;

		$i = count($t);
		//-------------------------	General Settings	
		$i++;
		$t[$i]->id 			= 'General-settings'; 
		$t[$i]->label 		= __('General Settings','evt');//title on tab
		$t[$i]->right_label	= __('API Key','etm');//title on tab
		$t[$i]->page_title	= __('General Settings','evt');//title on content
		$t[$i]->theme_option = true;
		$t[$i]->plugin_option = true;
		
		$temp = array();

		$temp[] = (object)array(
				'id'	=> 'evt_google_code',
				'type'	=> 'text',
				'label'	=> __('Google API Key','evt'),
				'description' => '<span style="color:red;">'.__('Warning: ','act') . '</span>' . __('You need your own API Key in order to use some Google APIs. You can get your key','act') .' <a href="https://developers.google.com/maps/documentation/javascript/tutorial#api_key" target="_blank">'.__('here','act').'</a>',
				'el_properties'=>array('style'=>'width:250px;'),
				'save_option'=>true,
				'load_option'=>true
			);
		$temp[] = (object)array(
				'type'	=> 'submit',
				'label'	=> __('Save','etm'),
				'class' => 'button-primary',
				'save_option'=>false,
				'load_option'=>false
			);			
			
		$t[$i]->options = $temp;
		
		return $t;
	}
}
?>