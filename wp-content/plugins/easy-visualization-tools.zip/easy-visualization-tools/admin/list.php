<?php

class admin_evt_admin_list { 
	var $parent_id;
	var $parent_menu_id;
	var $plugin_page;
	var $post_type = 'tools';
	var $chart_div = 'chart_div';
	var $google_key = '';
	
    // Start up functions
	function admin_evt_admin_list($parent_id){
		// set up varibles
        $this->parent_id = $parent_id; 
        $this->parent_menu_id = $parent_id.'-start';      
        
        // set start action
		add_action($parent_id.'-options-menu', array(&$this,'admin_menu'), 50, 0);
		add_action( 'init', array(&$this,'create_post_type') );
		add_action("admin_init", array(&$this,'admin_init'));
	}
	
	// create post types
function create_post_type() {
		// create defualt post type
		register_post_type($this->parent_id.'-'.$this->post_type, array(
			'label' => __('EVT Settings','evt'),
			'labels' => array(
				'name' 				=> __('EVT Settings','evt'),
				'singular_name' 	=> __('Statistics','evt'),
				'add_new' 			=> __('Add New Visualization Tool','evt'),
				'edit_item' 		=> __('Edit Visualization Tool','evt'),
				'new_item' 			=> __('New Visualization Tool','evt'),
				'view_item'			=> __('View Visualization Tool','evt'),
				'search_items'		=> __('Search Visualization Tool','evt'),
				'not_found'			=> __('No Visualization Tool Found','evt'),
				'not_found_in_trash'=> __('No Visualization Tool Found In Trash','evt'),
				'add_new_item'		=> __('Add New Visualization Tool','evt')
			),
			
			
			'public' => false,
			'publicly_queryable'  => false,
            'show_ui'             => $this->parent_menu_id,
            'show_in_menu'        => false,
            'show_in_nav_menus'   => false,
			'capability_type' => 'post',
			'hierarchical' => false,
			'rewrite' => true,
			'query_var' => false,
			'supports' => array('title'),	
			'exclude_from_search' => false,
		));
	}

	
	// save and and meta_box
	function admin_init(){
		global $evt_google_key;
  			// set filter to controle rows
  			add_filter('manage_edit-'.$this->parent_id.'-'.$this->post_type.'_columns', array(&$this,'add_new_columns'));
  			add_action('manage_'.$this->parent_id.'-'.$this->post_type.'_posts_custom_column', array(&$this,'manage_columns'), 10, 2);
  			
  			// set action to save post
			add_action('save_post', array(&$this,'save_details'));
			
			// set action up metaboxes
			
  			add_meta_box("evt-settings-meta", __("Advanced Settings","evt"), array(&$this,'meta_load_settings'), $this->parent_id.'-'.$this->post_type, "advanced", "core");
			
  				add_meta_box("evt-settings-docs", __("Comments","evt"), array(&$this,'meta_load_comments'), $this->parent_id.'-'.$this->post_type, "side", "low");
  				add_meta_box("evt-settings-data_loaded", __("Load data","evt"), array(&$this,'meta_load_data'), $this->parent_id.'-'.$this->post_type, "advanced", "high");  	
  				add_meta_box("evt-settings-preview", __("Preview","evt"), array(&$this,'meta_load_preview'), $this->parent_id.'-'.$this->post_type, "normal", "high");
	}
	
	//create menu 
	function admin_menu(){

		if(is_admin() && (current_user_can($tmp_tag_view) or current_user_can($tmp_tag_translate) or current_user_can('manage_options'))){
				$this->plugin_page = add_submenu_page($this->parent_menu_id,__("List Tools",'evt'),__("List tools",'evt'),'manage_options', 'edit.php?post_type='.$this->parent_id.'-'.$this->post_type);
				$this->plugin_page = '';
				$this->plugin_page = add_submenu_page($this->parent_menu_id,__("Add New Tools",'evt'),__("Add New Tools",'evt'),'manage_options', 'post-new.php?post_type='.$this->parent_id.'-'.$this->post_type);		
							
            	add_action( 'admin_head-post-new.php', array(&$this,'create_header'));
            	add_action( 'admin_head-post.php', array(&$this,'create_header'));
            	add_action( 'admin_head-edit.php', array(&$this,'create_header'));
        }
   
	}

	// create header 
	function create_header(){
		global $evt_google_key;

		if($this->is_post_type()){
			// farbtastic
			wp_print_styles( 'farbtastic' );
			wp_print_scripts( 'farbtastic' );
		
			// add wp-pointer
    		wp_enqueue_style( 'wp-pointer' );
    		wp_enqueue_script( 'wp-pointer' );
    			
    		wp_enqueue_style( 'jquery-ui-datepicker' , EASY_VISUALIZATION_TOOLS_CHART_URL.'css/wordpress/jquery-ui-1.8.16.custom.css');
    		wp_enqueue_script( 'jquery-ui-datepicker');			
    			
    			
    			
    			
    		// table
    		wp_register_script( 'dataTable_min_js', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/jquery.dataTables.min.js');
    		wp_enqueue_script( 'dataTable_min_js' );			
  			wp_register_script( 'jedittable_js', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/jquery.jeditable.js');
    		wp_enqueue_script( 'jedittable_js' );	
  			wp_register_script( 'jquery_dataTables_editable_js', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/jquery.dataTables.editable.js');
    		wp_enqueue_script( 'jquery_dataTables_editable_js' );	    			
     		wp_register_style( 'post_table_css', EASY_VISUALIZATION_TOOLS_CHART_URL.'css/post_table.css');
			wp_enqueue_style( 'post_table_css');
    			
    		// add creation of statistics
    		wp_register_script( 'evt_create_statistics', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/evt_create_statistics.js');
    		wp_enqueue_script( 'evt_create_statistics' ); 
    	 
    		// add new post settings
    		echo '<script>  
    			var EASY_VISUALIZATION_TOOLS_CHART_URL = "'.EASY_VISUALIZATION_TOOLS_CHART_URL.'";
    			var no_graph = "'.__('No graph has been selected','evt').'";
    			var char_div = "'.$this->chart_div.'";
    		</script>';
    		
    	echo '<style>';
    	echo '#icon-edit, #icon-evt-start { background: url(\''.EASY_VISUALIZATION_TOOLS_CHART_URL . 'images/evt32.png\') no-repeat transparent !important;';	
    	echo '</style>';
    		
    		wp_register_script( 'evt_post_page', EASY_VISUALIZATION_TOOLS_CHART_URL.'js/post_page.js');
    		wp_enqueue_script( 'evt_post_page' ); 
    		wp_register_style( 'evt_post_css', EASY_VISUALIZATION_TOOLS_CHART_URL.'css/evt_post.css');
			wp_enqueue_style( 'evt_post_css');
		}
	}
	
	// Controle list columns.
	function add_new_columns($default_columns) {
		$new_columns['cb'] = '<input type="checkbox" />';
		$new_columns['id'] = _x('ID', 'evt');
		$new_columns['title'] = _x('Title', 'evt');
		$new_columns['comm'] = _x('Comments', 'evt');
		$new_columns['shortcode'] = _x('Shortcode', 'evt');
		$new_columns['author'] = __('Author','dog');
		$new_columns['date'] = _x('Date', 'evt');
		$new_columns['tools'] = _x('Tools', 'evt');
		return $new_columns;
	}
	
	// Controles data input in rows
	function manage_columns($column_name, $id) {
		switch ($column_name) {
		case 'id':
			echo $id;
		    break;
		case 'shortcode':
			echo evt_globalt_shorcode_generator($id);
			break;
			
		case 'comm':
  			$custom = get_post_custom($id);
  			if(!empty($custom["evt_comments"])){
  				$comments = $custom["evt_comments"][0];
  				if(strlen($comments) > 200){
  					$comments = substr($comments,0,200).'…';
  				}
  			}
  			echo $comments;
  			break;
		case 'tools':
			echo '<input type="submit" class="button-secondary" value="Duplicate" onClick="evt_dubblicate_object(this,'.$id.');return false;">';
			break;
		default:
			break;
		} // end switch
	}

	// Create Meta Box the input comments
	function meta_load_comments(){
  		global $post;

		echo '<p><textarea style="width:100%" name="evt_comments">'.get_post_meta($post->ID, 'evt_comments', true).'</textarea></p>';
	}
	
function meta_load_data(){
		global $post;
			$attachments = get_posts(array('post_type' => 'attachment','numberposts' => -1,'post_status' => null,'orderby' => 'title'));

  			$tmp_array = '';
  			$tmp_array['title'] = 'Select media file';		
  			$tmp_array['extra_lable']['style'] = 'width:400px';  		
  		  	
  		  	$chek_array = array('application/vnd.ms-excel','text/csv');
			
			$tmp = '<select id="evt_mediefile" name="evt_mediefile" style="max-width:400px" class="evt_post_dropdown">';
  			$evt_mediefile = get_post_meta($post->ID, 'evt_mediefile', true);
  			
  			
  			$tmp 	.='<option value="">'.__('-- Select media file --').'</option>';
			foreach($attachments as $list_tmp){
				if(in_array($list_tmp->post_mime_type,$chek_array)){
					$tmp 	.='<option value="'.$list_tmp->guid.'" ';
					if($list_tmp->guid == $evt_mediefile){
						$tmp 	.= ' selected="selected" ';
					}
					$tmp 	.='>'.$list_tmp->post_title.'</option>';
				}
			}
			$tmp .='</select>';

			$evt_type_of_loaded_data = get_post_meta($post->ID, 'evt_type_of_loaded_data', true);


		echo '<div id="evt_loading_data">';
			echo '<div class="evt_loading_data_lable"><input type="radio" '.(empty($evt_type_of_loaded_data) == true ? 'checked="checked"' : '' ).' name="evt_type_of_loaded_data" value="0"> ' . __('Add manuel data').'</div>';
			echo '<div class="evt_loading_data_block" id="evt_loading_data0" style="height: auto;display:overflow: hidden;'.(empty($evt_type_of_loaded_data) == true ? 'block' : 'none' ).'">';
				echo '<div id="evt_manual_table_data_div"></div>';	
			echo '</div>';
			
			echo '<div class="evt_loading_data_lable"><input type="radio" '.($evt_type_of_loaded_data == 1 ? 'checked="checked"' : '' ).' name="evt_type_of_loaded_data" value="1"> ' . __('Add data from media library').'</div>';
			echo '<div class="evt_loading_data_block" id="evt_loading_data1" style="display:'.($evt_type_of_loaded_data == 1 ? 'block' : 'none' ).'">';	
				echo '<div>'.$tmp.' <input id="evt_preview_submit" type="submit" value="Preview" onClick="return false" class="button-primary evt_submit_button"><div class="evt_loading_div"></div></div>';	
			echo '</div>';
			echo '<div class="evt_loading_data_lable"><input type="radio" '.($evt_type_of_loaded_data == 2 ? 'checked="checked"' : '' ).' name="evt_type_of_loaded_data" value="2"> ' . __('Add data from url.').'</div>';
			echo '<div class="evt_loading_data_block" id="evt_loading_data2" style="display:'.($evt_type_of_loaded_data == 2 ? 'block' : 'none' ).'">';
				echo '<div><input type="text" style="width: 400px; float: left; margin-top: 2px;" id="evt_get_url_data" name="evt_get_url_data" value="'.get_post_meta($post->ID, 'evt_get_url_data', true).'"> <input onClick="return false" type="submit" class="button-primary evt_submit_button" id="evt_preview_submit" value="Preview"><div class="evt_loading_div"></div></div>';	
			echo '</div>';

			echo '<div class="evt_loading_data_lable"><input type="radio" '.($evt_type_of_loaded_data == 3 ? 'checked="checked"' : '' ).' name="evt_type_of_loaded_data" value="3"> ' . __('Get data from Google Analytics.').'</div>';
			echo '<div class="evt_loading_data_block" id="evt_loading_data3" style="display:'.($evt_type_of_loaded_data == 3 ? 'block' : 'none' ).'">';
				echo '<div style="width:100%"><span style="display: block; float: left; min-width: 80px; margin-top: 4px;">Email: </span><input type="text" style="width: 300px;margin-top: 2px;" id="evt_analytics_email" name="evt_analytics_email" value="'.get_post_meta($post->ID, 'evt_analytics_email', true).'"></div><div style="width:100%"><span style="display: block; float: left; min-width: 80px; margin-top: 4px;">Password: </span><input type="password" style="width: 300px;margin-top: 2px;" id="evt_analytics_code" name="evt_analytics_code" value="'.get_post_meta($post->ID, 'evt_analytics_code', true).'"></div><div style="width:100%;float:left"><span  style="display: block; float: left; min-width: 80px; margin-top: 4px;">Profile ID: </span><input type="text" style="width: 300px;margin-top: 2px;" id="evt_analytics_profile_id" name="evt_analytics_profile_id" value="'.get_post_meta($post->ID, 'evt_analytics_profile_id', true).'"></div>';
				
				
			$evt_analytics_dimensions = get_post_meta($post->ID, 'evt_analytics_dimensions', true);
			$evt_analytics_dimensions_array['visitorType'] = 'Visitors';						
			$evt_analytics_dimensions_array['browser'] = 'Browser';
			$evt_analytics_dimensions_array['operatingSystem'] = 'Operating System';			
			$evt_analytics_dimensions_array['isMobile'] = 'Is Mobile';				
			$evt_analytics_dimensions_array['language'] = 'Language';	
			$evt_analytics_dimensions_array['screenColors'] = 'ScreenColors';			
			$evt_analytics_dimensions_array['screenResolution'] = 'Screen Resolution';					
			$evt_analytics_dimensions_array['continent'] = 'Continent';						
			$evt_analytics_dimensions_array['country'] = 'Country';	
			$evt_analytics_dimensions_array['region'] = 'Region';			
			$evt_analytics_dimensions_array['city'] = 'City';									
				
				
			$evt_analytics_dimensions_max = get_post_meta($post->ID, 'evt_analytics_dimensions_max', true);
			$evt_analytics_dimensions_max_array[''] = 'All';
			$evt_analytics_dimensions_max_array['1'] = 'Show Top 1';
			$evt_analytics_dimensions_max_array['2'] = 'Show Top 2';
			$evt_analytics_dimensions_max_array['3'] = 'Show Top 3';
			$evt_analytics_dimensions_max_array['4'] = 'Show Top 4';
			$evt_analytics_dimensions_max_array['5'] = 'Show Top 5';
			$evt_analytics_dimensions_max_array['10'] = 'Show Top 10';			
			$evt_analytics_dimensions_max_array['15'] = 'Show Top 15';			
			$evt_analytics_dimensions_max_array['20'] = 'Show Top 20';
			$evt_analytics_dimensions_max_array['25'] = 'Show Top 25';			
			$evt_analytics_dimensions_max_array['50'] = 'Show Top 50';
							
			$evt_analytics_dimensions_show = get_post_meta($post->ID, 'evt_analytics_dimensions_show', true);
			$evt_analytics_dimensions_show_array[''] = 'Today';			
			$evt_analytics_dimensions_show_array['hour'] = 'Hour';		
			$evt_analytics_dimensions_show_array['day'] = 'Day';	
			$evt_analytics_dimensions_show_array['week'] = 'Week';	
			$evt_analytics_dimensions_show_array['month'] = 'Month';	
			$evt_analytics_dimensions_show_array['year'] = 'Year';			
			$evt_analytics_dimensions_show_array['dayOfWeek'] = 'Day Of Week';	
			$evt_analytics_dimensions_show_array['total'] = 'All Data';	
				
				
			$evt_analytics_metrics_show = get_post_meta($post->ID, 'evt_analytics_metrics_show', true);
			
			$evt_analytics_metrics_show_array['visits'] = 'Visitors';
			$evt_analytics_metrics_show_array['pageviews'] = 'Page Views';
			$evt_analytics_metrics_show_array['visitBounceRate'] = 'Visitors Bounce Rate';	
			$evt_analytics_metrics_show_array['avgTimeOnSite'] = 'Average Time On Site';	
			$evt_analytics_metrics_show_array['percentNewVisits'] = 'Percent New Visits';	
				
			$evt_analytics_date_show = get_post_meta($post->ID, 'evt_analytics_date_show', true);			
			$evt_analytics_date_from = get_post_meta($post->ID, 'evt_analytics_date_from', true);
			$evt_analytics_date_to = get_post_meta($post->ID, 'evt_analytics_date_to', true);				
				
			$evt_analytics_dimensions_show_dir = get_post_meta($post->ID, 'evt_analytics_dimensions_show_dir', true);		
			$evt_analytics_dimensions_show_dir_array['asc'] = '&uarr; Ascending';
			$evt_analytics_dimensions_show_dir_array['decs'] = '&darr; Descending';
				
			echo '<div style="width:400px"><span style="display: block; float: left; min-width: 80px; margin-top: 4px;">Dimensions: </span><select id="evt_analytics_dimensions" name="evt_analytics_dimensions" style="width:200px">';
			
			foreach($evt_analytics_dimensions_array as $tmp_key1 => $tmp_data1){
				echo '<option value="'.$tmp_key1.'" ';
				if($evt_analytics_dimensions == $tmp_key1){
					echo 'selected="selected" ';
				}
				echo '>'.$tmp_data1.'</option>';
			}
			echo '</select><select id="evt_analytics_dimensions_max" name="evt_analytics_dimensions_max" style="width:100px;clear:both">';
			
			foreach($evt_analytics_dimensions_max_array as $tmp_key1 => $tmp_data1){
				echo '<option value="'.$tmp_key1.'" ';
				if($evt_analytics_dimensions_max == $tmp_key1){
					echo 'selected="selected" ';
				}
				echo '>'.$tmp_data1.'</option>';
			}
			
			echo '</select>';
				
			echo '<span style="display: block; float: left; min-width: 80px; margin-top: 4px;">Show by: </span><select id="evt_analytics_dimensions_show" name="evt_analytics_dimensions_show" style="width:200px;float:left">';
			
			foreach($evt_analytics_dimensions_show_array as $tmp_key2 => $tmp_data2){
				echo '<option value="'.$tmp_key2.'" ';
				if($evt_analytics_dimensions_show == $tmp_key2){
					echo 'selected="selected" ';
				}
				echo '>'.$tmp_data2.'</option>';
			}
			echo '</select><select id="evt_analytics_dimensions_show_dir" name="evt_analytics_dimensions_show_dir" style="width:100px;clear:both">';
			
			foreach($evt_analytics_dimensions_show_dir_array as $tmp_key3 => $tmp_data3){
				echo '<option value="'.$tmp_key3.'" ';
				if($evt_analytics_dimensions_show_dir == $tmp_key3){
					echo 'selected="selected" ';
				}
				echo '>'.$tmp_data3.'</option>';
			}
			echo '</select></div>';
			
				
			echo '<span style="display: block; float: left; min-width: 80px;margin-top: 4px;">Show Date: </span><div>';
			echo '<input type="checkbox" id="evt_analytics_date_show" name="evt_analytics_date_show" value="1" ';
				if($evt_analytics_date_show == 1){
					echo 'checked="checked" ';
				}
			echo '>';
	
			
			echo '<label for="from">From</label>';
			echo '<input type="text" style="margin-right: 15px;width: 114px;" value="'.$evt_analytics_date_from.'" id="evt_analytics_date_from" name="evt_analytics_date_from"/>';
			echo '<label for="to">To</label>';
			echo '<input type="text" style="width: 114px;" value="'.$evt_analytics_date_to.'" id="evt_analytics_date_to" name="evt_analytics_date_to"/>';
			echo '</div>';
				
				
			echo '<span style="display: block; float: left; min-width: 80px;height: 80px;margin-top: 4px;">Show Data: </span><div>';
			
			foreach($evt_analytics_metrics_show_array as $tmp_key3 => $tmp_data3){
				echo '<input type="checkbox" class="evt_analytics_metrics_show" name="evt_analytics_metrics_show[]" value="'.$tmp_key3.'" ';
				if(in_array($tmp_key3, $evt_analytics_metrics_show) && count($evt_analytics_metrics_show)>0 && !empty($tmp_key3)){
					echo 'checked="checked" ';
				}
				echo ' >'.$tmp_data3.'<br>';
			}
			echo '</div>';			
				
			echo '<input style="margin-top:10px;margin-left:0px" onClick="return false" type="submit" class="button-primary evt_submit_button" id="evt_preview_submit" value="Preview"><div class="evt_loading_div"></div>';	
			echo '</div>';
			
			
		echo '</div>';
		echo '<div class="evt_post_div_clear"></div>';
	}

	
	// Create a preview MetaBox
	function meta_load_preview(){
		global $evt_class_run;
		echo '<div id="'.$this->chart_div.'">'.__('No graph has been selected','evt').'</div>';
	}
		
	// Creating the setup border
	function meta_load_settings(){
  		global $post,$easy_visualization_tools_display,$evt_google_key;
  				
  			require_once(EASY_VISUALIZATION_TOOLS_CHART_PATH.'inc/formsettings.php');
 
 			echo '<script>
 					var post_id = '.$post->ID.';
 				  </script> '; 

  			$custom_flag = get_post_meta($post->ID, 'evt_flag', true);

  			$tmp_array = '';
  			$tmp_array['title'] = 'Select statistics type';
   			$tmp_array['name'] = 'flag'; 		
  			$tmp_array['type'] = 'dropdown';
  			$tmp_array['extra']['onChange'] = 'evt_getData(this);';
  			$tmp_array['extra']['id'] = 'evt_flag';
  			$tmp_array['extra']['style'] = 'max-width:200px';
  			$tmp_array['extra_lable']['style'] = 'width:150px';  		
  			foreach($easy_visualization_tools_display as $tmp){
  				$tmp_array['list'][$tmp['type']] = $tmp['title'];
  			}
  		
			echo '<div>'.evt_create_form($tmp_array,0,$custom_flag).'</div>';
			echo '<input type="hidden" value="'.get_post_meta($post->ID, 'evt_packages', true).'" id="evt_hidden_packages" name="evt_hidden_packages">';
			echo '<input type="hidden" value="'.get_post_meta($post->ID, 'evt_rowdata', true).'" id="evt_hidden_rowdata" name="evt_hidden_rowdata">';
			echo '<input type="hidden" value="'.get_post_meta($post->ID, 'evt_collumdata', true).'" id="evt_hidden_collumdata" name="evt_hidden_collumdata">';
			echo '<input type="hidden" value="'.get_post_meta($post->ID, 'evt_settings', true).'" id="evt_hidden_settings" name="evt_hidden_settings">';
			echo '<div id="evt_data_set"></div>';
	}

	// saves all data into the post meta
	function save_details(){
  		global $post;
  		
  		if(isset($_POST["evt_get_url_data"])){
  			update_post_meta($post->ID, "evt_get_url_data", $_POST["evt_get_url_data"]);
  		}	
  		
  		if(isset($_POST["evt_mediefile"])){
  			update_post_meta($post->ID, "evt_mediefile", $_POST["evt_mediefile"]);
  		}
  		
  		if(isset($_POST["evt_type_of_loaded_data"])){
  			update_post_meta($post->ID, "evt_type_of_loaded_data", $_POST["evt_type_of_loaded_data"]);
  		}	
  		
  		if(isset($_POST["evt_type_of_loaded_data"])){
			update_post_meta($post->ID, "evt_type_of_loaded_data", $_POST["evt_type_of_loaded_data"]);
  		}		
  		
 		if(isset($_POST["evt_hidden_settings"])){
			update_post_meta($post->ID, "evt_settings", $_POST["evt_hidden_settings"]);
  		}
  		
    	if(isset($_POST["evt_hidden_packages"])){
			update_post_meta($post->ID, "evt_packages", $_POST["evt_hidden_packages"]);
  		}	
  		
   		if(isset($_POST["evt_hidden_rowdata"])){
			update_post_meta($post->ID, "evt_rowdata", $_POST["evt_hidden_rowdata"]);
  		}	
  		
  		if(isset($_POST["evt_hidden_collumdata"])){
			update_post_meta($post->ID, "evt_collumdata", $_POST["evt_hidden_collumdata"]);
  		}
  		
   		if(isset($_POST["evt_comments"])){
			update_post_meta($post->ID, "evt_comments", $_POST["evt_comments"]);
  		} 		
  		
   		if(isset($_POST["evt_analytics_email"])){
			update_post_meta($post->ID, "evt_analytics_email", $_POST["evt_analytics_email"]);
  		} 	 		
  		
   		if(isset($_POST["evt_analytics_code"])){
			update_post_meta($post->ID, "evt_analytics_code", $_POST["evt_analytics_code"]);
  		} 	
  		
   		if(isset($_POST["evt_analytics_profile_id"])){
			update_post_meta($post->ID, "evt_analytics_profile_id", $_POST["evt_analytics_profile_id"]);
  		} 
  		
   		if(isset($_POST["evt_analytics_dimensions"])){
			update_post_meta($post->ID, "evt_analytics_dimensions", $_POST["evt_analytics_dimensions"]);
  		} 	
   		if(isset($_POST["evt_analytics_dimensions_max"])){
			update_post_meta($post->ID, "evt_analytics_dimensions_max", $_POST["evt_analytics_dimensions_max"]);
  		} 
  		
  			
   		if(isset($_POST["evt_analytics_dimensions_show"])){
			update_post_meta($post->ID, "evt_analytics_dimensions_show", $_POST["evt_analytics_dimensions_show"]);
  		} 	
  		
   		if(isset($_POST["evt_analytics_date_show"])){
			update_post_meta($post->ID, "evt_analytics_date_show", $_POST["evt_analytics_date_show"]);
  		} else {
  			update_post_meta($post->ID, "evt_analytics_date_show", '');
  		}

   		if(isset($_POST["evt_analytics_date_to"])){
			update_post_meta($post->ID, "evt_analytics_date_to", $_POST["evt_analytics_date_to"]);
  		} 
  		
    	if(isset($_POST["evt_analytics_date_from"])){
			update_post_meta($post->ID, "evt_analytics_date_from", $_POST["evt_analytics_date_from"]);
  		} 
  		
   		if(isset($_POST["evt_analytics_metrics_show"])){
			update_post_meta($post->ID, "evt_analytics_metrics_show", $_POST["evt_analytics_metrics_show"]);
  		} else {
  			update_post_meta($post->ID, "evt_analytics_metrics_show", '');
  		}
  		
   		if(isset($_POST["evt_analytics_dimensions_show_dir"])){
			update_post_meta($post->ID, "evt_analytics_dimensions_show_dir", $_POST["evt_analytics_dimensions_show_dir"]);
  		} 		
  		
  		
  		if(isset($_POST["evt_flag"])){
			update_post_meta($post->ID, "evt_flag", $_POST["evt_flag"]);
			
			$tmp_array = '';
			
			foreach($_POST as $key => $data_tmp){
				if(substr($key, 0, 4) == 'evt_' && $key != "evt_flag" && $key != "evt_comments" && !empty($data_tmp)){
					$key = str_replace("evt_", "",$key);
					$tmp_array[$key] = $data_tmp;
					
				}
			}
			
			update_post_meta($post->ID, "evt_data", json_encode($tmp_array));
  		} 		
	}
	
	// checks if it is the right post type
	function is_post_type(){
		global $post;
		
		if($_GET['post_type'] == $this->parent_id.'-'.$this->post_type || $post->post_type == $this->parent_id.'-'.$this->post_type){
			return true;
		} else if($_POST['post_type'] == $this->parent_id.'-'.$this->post_type){
			return true;
		} else {
			return false;
		}
	}	
}
?>