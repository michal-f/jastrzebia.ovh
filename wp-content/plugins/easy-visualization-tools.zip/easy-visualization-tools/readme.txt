=== Easy Visualization Tools for Wordpress (Google Chart Tools Edition) ===
Author: RightHere LLC
Author URL: http://plugins.righthere.com/easy-visualization-tools/
Tags: WordPress, WordPress Multisite, Google Chart Tools, Google Analytics, HTML5, SVG, Pie Charts, Scatter Charts, Gauge Charts, Table Charts, Combo Charts, Line Charts, Bar Charts, Column Charts, Area Charts, Annotated Time Line Charts, Geo Charts, Real Map Charts, Intensity Map Charts. 
Requires at least: 3.0
Tested up to: 3.3.2
Stable tag: 1.1.0 rev24176

======== CHANGELOG ========
Version 1.1.0 rev24176 - April 24, 2012
* Update: Improved interface for multiple charts
* New Feature: Added support for easy selecting of colors and multi size
* New Feature: Replaced fields for "array of objects" with easy drop downs for selecting settings
* New Feature: Added support for transparent background on charts
* New Feature: Added support for Data from Google Analytics
* Updated sort of setting list
* Updated sort of tools list

Version 1.0.0 rev23709 - March 25, 2012
* First release.


======== DESCRIPTION ========
Easy Visualization Tools for WordPress is a powerful suite of plugins enabling you to easily create Charts, Maps, Graphs and Infographics. This is the main plugin which is based on the Google Chart Tools API.

== INSTALLATION ==

1. Upload the 'easy-visualization-tools' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. In the menu you will find Site Tour.

== FREQUENTLY ASKED QUESTIONS ==
If you have any questions or trouble using this plugin you are welcome to contact me through my profile on Codecanyon (http://codecanyon.net/user/RightHere)

Or visit our Support site at http://support.righthere.com


== SOURCES - CREDITS & LICENSES ==

We have used the following open source projects, graphics, fonts, API's or other files as listed. Thanks to the author for the creative work they made.

1) Google Chart Tools - http://code.google.com/apis/chart/

